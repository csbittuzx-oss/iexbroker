# **App Name**: IEX

## Core Features:

- Secure User Authentication: Robust user registration with country/age validation and withdrawal PIN setup, login, and secure password recovery mechanisms, integrating with Firebase Authentication.
- Profile & Account Management: Users can view and edit personal data (excluding country), manage a unique UID, upload profile pictures, and control trade sound settings, with data stored via Firebase.
- Dynamic Real-time Trading Charts: Integration of professional TradingView charts for Crypto and Forex pairs, offering dynamic timeframe selection, extensive drawing tools with universal interactions, and fluid responsiveness across devices using live market data (Binance, Real Market API).
- Trade Execution Module: Intuitive interface for selecting trading pairs, defining trade duration and amount, and executing UP/DOWN trades with real-time payout calculations and API integration for perfect price matching.
- Fund Deposit & Withdrawal Flows: Streamlined multi-step process for depositing funds via various payment methods (Crypto, UPI) with detailed instructions, address/QR code display, amount selection, and transaction ID verification. Secure withdrawal with 6-digit PIN and Firebase for processing statuses.
- Comprehensive User History & Analytics: Access to detailed trade history (including pair, prices, amounts, profit/loss), transaction history (ID, date, status, amount), and a dedicated analytics view showing overall trading performance using data managed by Firebase.
- AI-Powered Trade Assistant: An AI tool that generates a concise analysis and provides actionable insights for completed trades, drawing upon market conditions and trade outcomes to inform the user's trading strategy and potentially incorporate relevant data.

## Style Guidelines:

- Primary brand color: A professional deep royal blue (#3E42DF) that evokes trustworthiness and innovation for interactive elements, buttons, and key informational accents. This color balances vibrancy with a serious, sleek feel for a dark theme.
- Background color: A very dark, subtle bluish-gray (#14141A) serving as the strict dark theme base, chosen for its heavy desaturation from the primary hue and low brightness to ensure maximum focus on trading data without causing eye strain or distraction.
- Accent color: A crisp, light sky blue (#8ED6F7) used sparingly for highlights, active states, important notifications, and calls to action, providing clear contrast and navigational cues against the dark background while avoiding any neon appearance.
- Body and headline font: 'Inter', a grotesque-style sans-serif selected for its modern, neutral, and objective appearance, ensuring excellent readability for all data, chart labels, and text across diverse screen sizes.
- Utilize clean, line-based, and minimalist vector icons for all functionalities. The iconography will be abstracted and system-style, reflecting a sleek, modern, and professional design aesthetic devoid of heavy ornamentation or skeuomorphism.
- Highly adaptive and responsive layouts meticulously optimized for distinct user experiences on phone, tablet, and PC screens. This includes flexible grid systems for charts and trading panels, dynamic navigation patterns (e.g., mobile bottom nav), and distinct element placement as specified in the brief.
- Subtle, performant, and professional animations will be used for UI transitions, loading indicators, button feedback, and crucial chart interactions. This includes smooth movement, snapping behaviors, and anchor point handling for drawing tools, enhancing usability without distracting the user.