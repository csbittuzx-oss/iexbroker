
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UserProfile {
  uid: string;
  email: string;
  nickname: string;
  firstName: string;
  lastName: string;
  birthday: string;
  country: string;
  withdrawalPin: string;
  isAdmin?: boolean;
  status?: string;
  balance?: number;
  profilePic?: string;
  namesEdited?: boolean;
}

export interface Trade {
  id: string;
  pairName: string;
  openingPrice: number;
  closingPrice: number;
  tradeAmount: number;
  profitAmount: number;
  outcome: 'profit' | 'loss' | 'breakeven' | 'pending';
  duration: string;
  date: string;
  expiryDate: string;
  entryType: 'UP' | 'DOWN';
}

export interface SupportTicket {
  id: string;
  email: string;
  message: string;
  status: 'pending' | 'resolved';
  date: string;
  adminReply?: string;
}

export interface Asset {
  symbol: string;
  name: string;
  type: 'crypto' | 'forex';
  payout: number;
}

interface TradingState {
  _hasHydrated: boolean;
  user: UserProfile | null;
  balance: number;
  currency: 'USD' | 'INR';
  isLoggedIn: boolean;
  isMuted: boolean;
  isOnline: boolean;
  activePair: string;
  activeDuration: string;
  chartTimeframe: string;
  tradeAmount: number;
  payoutPercent: number;
  trades: Trade[];
  tickets: SupportTicket[];
  favorites: string[];
  hasDeposited: boolean;
  wrongPinAttempts: number;
  withdrawalBlockUntil: number | null;
  profileView: 'menu' | 'history' | 'transactions' | 'analytics';
  activeTab: 'trade' | 'support' | 'profile';
  
  setHasHydrated: (state: boolean) => void;
  setUser: (user: UserProfile | null) => void;
  setBalance: (balance: number | ((prev: number) => number)) => void;
  setCurrency: (currency: 'USD' | 'INR') => void;
  setLoggedIn: (status: boolean) => void;
  setIsOnline: (status: boolean) => void;
  toggleMuted: () => void;
  setActivePair: (pair: string) => void;
  setActiveDuration: (duration: string) => void;
  setChartTimeframe: (timeframe: string) => void;
  setTradeAmount: (amount: number) => void;
  setPayoutPercent: (percent: number) => void;
  addTrade: (trade: Trade) => void;
  updateTradeOutcome: (id: string, outcome: 'profit' | 'loss' | 'breakeven', profit: number, closingPrice: number) => void;
  addTicket: (ticket: SupportTicket) => void;
  toggleFavorite: (symbol: string) => void;
  setHasDeposited: (status: boolean) => void;
  incrementPinAttempts: () => void;
  resetPinAttempts: () => void;
  blockWithdrawal: (until: number) => void;
  setProfileView: (view: 'menu' | 'history' | 'transactions' | 'analytics') => void;
  setActiveTab: (tab: 'trade' | 'support' | 'profile') => void;
  clearSession: () => void;
}

export const useStore = create<TradingState>()(
  persist(
    (set) => ({
      _hasHydrated: false,
      user: null,
      balance: 0.00,
      currency: 'USD',
      isLoggedIn: false,
      isMuted: false,
      isOnline: true,
      activePair: 'SOLUSDT',
      activeDuration: '01:00',
      chartTimeframe: '1m',
      tradeAmount: 10,
      payoutPercent: 82,
      trades: [],
      tickets: [],
      favorites: [],
      hasDeposited: false,
      wrongPinAttempts: 0,
      withdrawalBlockUntil: null,
      profileView: 'menu',
      activeTab: 'trade',

      setHasHydrated: (state) => set({ _hasHydrated: state }),
      setUser: (user) => set({ 
        user, 
        balance: user?.balance ?? 0 
      }),
      setBalance: (balance) => set((state) => ({ 
        balance: typeof balance === 'function' ? balance(state.balance) : balance 
      })),
      setCurrency: (currency) => set({ currency }),
      setLoggedIn: (isLoggedIn) => set({ isLoggedIn }),
      setIsOnline: (isOnline) => set({ isOnline }),
      toggleMuted: () => set((state) => ({ isMuted: !state.isMuted })),
      setActivePair: (activePair) => set({ activePair }),
      setActiveDuration: (activeDuration) => set({ activeDuration }),
      setChartTimeframe: (chartTimeframe) => set({ chartTimeframe }),
      setTradeAmount: (tradeAmount) => set({ tradeAmount }),
      setPayoutPercent: (payoutPercent) => set({ payoutPercent }),
      addTrade: (trade) => set((state) => ({ trades: [trade, ...state.trades] })),
      updateTradeOutcome: (id, outcome, profit, closingPrice) => set((state) => ({
        trades: state.trades.map(t => t.id === id ? { ...t, outcome, profitAmount: profit, closingPrice } : t)
      })),
      addTicket: (ticket) => set((state) => ({ tickets: [ticket, ...state.tickets] })),
      toggleFavorite: (symbol) => set((state) => ({
        favorites: state.favorites.includes(symbol)
          ? state.favorites.filter(s => s !== symbol)
          : [...state.favorites, symbol]
      })),
      setHasDeposited: (hasDeposited) => set({ hasDeposited }),
      incrementPinAttempts: () => set((state) => ({ wrongPinAttempts: state.wrongPinAttempts + 1 })),
      resetPinAttempts: () => set({ wrongPinAttempts: 0 }),
      blockWithdrawal: (until) => set({ withdrawalBlockUntil: until }),
      setProfileView: (view) => set({ profileView: view }),
      setActiveTab: (tab) => set({ activeTab: tab }),
      clearSession: () => set({
        user: null,
        balance: 0.00,
        isLoggedIn: false,
        trades: [],
        tickets: [],
        hasDeposited: false,
        wrongPinAttempts: 0,
        withdrawalBlockUntil: null,
        profileView: 'menu',
        activeTab: 'trade'
      })
    }),
    {
      name: 'iex-storage',
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    }
  )
);
