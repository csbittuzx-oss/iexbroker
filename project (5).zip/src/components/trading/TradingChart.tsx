
"use client"

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { createChart, ColorType, ISeriesApi, CandlestickData, Time, IChartApi, DeepPartial, ChartOptions } from 'lightweight-charts';
import { useStore } from '@/store/useStore';
import { Loader2, Clock, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { doc, updateDoc, increment } from 'firebase/firestore';
import { useFirestore } from '@/firebase';

const BINANCE_REST_NODES = [
  'https://api.binance.com/api/v3',
  'https://api1.binance.com/api/v3',
  'https://api2.binance.com/api/v3',
  'https://api3.binance.com/api/v3'
];
const BINANCE_WS_URL = 'wss://stream.binance.com:9443/ws';

const SYMBOL_MAP: Record<string, string> = {
  'BTCUSDT': 'BTCUSDT',
  'XAUUSDT.P': 'PAXGUSDT',
  'ICPUSDT': 'ICPUSDT',
  'DASHUSDT': 'DASHUSDT',
  'KITEUSDT': 'KITEUSDT',
  'INJUSDT': 'INJUSDT',
  'CRVUSDT': 'CRVUSDT',
  'EURUSD': 'EURUSDT',
  'GBPUSD': 'GBPUSDT',
  'USDJPY': 'USDJPY',
  'AUDUSD': 'AUDUSDT',
  'NZDUSD': 'NZDUSDT',
  'SOLUSDT': 'SOLUSDT',
  'ETHUSDT': 'ETHUSDT',
  'BNBUSDT': 'BNBUSDT',
  'XRPUSDT': 'XRPUSDT',
  'DOGEUSDT': 'DOGEUSDT',
  'SUIUSDT': 'SUIUSDT',
  'TONUSDT': 'TONUSDT'
};

const TIMEFRAME_OPTIONS = ["1m", "3m", "5m", "15m", "30m", "1h"];

const BINANCE_INTERVALS: Record<string, string> = {
  '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h'
};

const getTimeframeSeconds = (tf: string) => {
  if (tf.endsWith('m')) return parseInt(tf) * 60;
  if (tf.endsWith('h')) return parseInt(tf) * 3600;
  return 60;
};

const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

export default function TradingChart() {
  const { 
    activePair, trades, updateTradeOutcome, setBalance, 
    payoutPercent, chartTimeframe, setChartTimeframe, isOnline, user
  } = useStore();
  
  const db = useFirestore();
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const markersOverlayRef = useRef<SVGSVGElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const resolvedRef = useRef<Set<string>>(new Set());
  
  const [isLoading, setIsLoading] = useState(true);
  const [errorNode, setErrorNode] = useState<string | null>(null);
  const countdownRef = useRef('00:00');
  const [isTfPopoverOpen, setIsTfPopoverOpen] = useState(false);
  const { toast } = useToast();

  const candleStateRef = useRef({
    target: null as any,
    display: null as any,
    animating: false,
    startTime: 0,
    startPrice: 0,
    duration: 180,
  });

  const tradesRef = useRef(trades);
  useEffect(() => { tradesRef.current = trades; }, [trades]);

  const activePairRef = useRef(activePair);
  useEffect(() => { activePairRef.current = activePair; }, [activePair]);

  const chartTimeframeRef = useRef(chartTimeframe);
  useEffect(() => { chartTimeframeRef.current = chartTimeframe; }, [chartTimeframe]);

  const payoutPercentRef = useRef(payoutPercent);
  useEffect(() => { payoutPercentRef.current = payoutPercent; }, [payoutPercent]);

  const userRef = useRef(user);
  useEffect(() => { userRef.current = user; }, [user]);

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const tfSeconds = getTimeframeSeconds(chartTimeframe);
      const remaining = tfSeconds - (Math.floor(now.getTime() / 1000) % tfSeconds);
      
      const h = Math.floor(remaining / 3600);
      const m = Math.floor((remaining % 3600) / 60);
      const s = remaining % 60;
      
      if (h > 0) {
        countdownRef.current = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
      } else {
        countdownRef.current = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
      }
    };
    
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [chartTimeframe]);

  useEffect(() => {
    if (!chartContainerRef.current || !isOnline) return;
    let isMounted = true;
    let ws: WebSocket | null = null;
    setErrorNode(null);

    const chart = createChart(chartContainerRef.current, {
      layout: { 
        background: { type: ColorType.Solid, color: 'transparent' }, 
        textColor: '#A0A0A0', 
        fontSize: 11, 
        fontFamily: 'Inter' 
      },
      grid: { 
        vertLines: { visible: false }, 
        horzLines: { color: 'rgba(255, 255, 255, 0.02)' } 
      },
      crosshair: { 
        mode: 1, 
        vertLine: { color: '#3E42DF', style: 2, labelBackgroundColor: '#3E42DF' }, 
        horzLine: { color: '#3E42DF', style: 2, labelBackgroundColor: '#3E42DF' } 
      },
      timeScale: { 
        borderColor: 'rgba(255, 255, 255, 0.05)', 
        timeVisible: true, 
        secondsVisible: false,
        shiftVisibleRangeOnNewBar: true,
        rightOffset: 12,
        barSpacing: 6,
        minBarSpacing: 1,
      },
      rightPriceScale: { 
        borderColor: 'rgba(255, 255, 255, 0.05)',
        autoScale: true,
        scaleMargins: { top: 0.1, bottom: 0.1 },
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
    } as DeepPartial<ChartOptions>);

    const candlestickSeries = chart.addCandlestickSeries({
      upColor: '#35CB01', 
      downColor: '#DB4635', 
      borderVisible: false, 
      wickUpColor: '#35CB01', 
      wickDownColor: '#DB4635',
      priceLineVisible: false,
    });

    chartRef.current = chart;
    seriesRef.current = candlestickSeries;

    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({ 
          width: chartContainerRef.current.clientWidth, 
          height: chartContainerRef.current.clientHeight 
        });
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    const processTradeResolutions = (price: number) => {
      const now = Date.now();
      const currentTrades = tradesRef.current;
      
      currentTrades.forEach(trade => {
        if (trade.outcome === 'pending' && trade.pairName === activePairRef.current) {
          const expiryTime = new Date(trade.expiryDate).getTime();
          if (now >= expiryTime && !resolvedRef.current.has(trade.id)) {
            resolvedRef.current.add(trade.id);
            
            const isWin = trade.entryType === 'UP' ? price > trade.openingPrice : price < trade.openingPrice;
            const isTie = price === trade.openingPrice;
            
            let outcome: 'profit' | 'loss' | 'breakeven' = isWin ? 'profit' : (isTie ? 'breakeven' : 'loss');
            let profit = isWin ? trade.tradeAmount * (payoutPercentRef.current / 100) : (isTie ? 0 : -trade.tradeAmount);
            let totalReturn = isWin ? trade.tradeAmount + profit : (isTie ? trade.tradeAmount : 0);

            if (isWin) {
              toast({
                title: `${trade.pairName} | SUCCESS`,
                description: `+$${totalReturn.toFixed(2)} [${trade.duration}]`,
                className: "border-emerald-500/50 bg-emerald-500/10 text-emerald-500",
              });
              setBalance(prev => prev + totalReturn);
              if (userRef.current?.uid) {
                updateDoc(doc(db, 'users', userRef.current.uid), { balance: increment(totalReturn) })
                  .catch(e => console.error("Balance sync failed", e));
              }
            } else if (isTie) {
              toast({
                title: `${trade.pairName} | BREAKEVEN`,
                description: `Price unchanged. $${trade.tradeAmount.toFixed(2)} refunded.`,
                className: "border-blue-500/50 bg-blue-500/10 text-blue-400",
              });
              setBalance(prev => prev + totalReturn);
              if (userRef.current?.uid) {
                updateDoc(doc(db, 'users', userRef.current.uid), { balance: increment(totalReturn) })
                  .catch(e => console.error("Balance sync failed", e));
              }
            } else {
              toast({
                variant: "destructive",
                title: `${trade.pairName} | LOSS`,
                description: `-$${Math.abs(trade.tradeAmount).toFixed(2)} [${trade.duration}]`,
              });
            }

            updateTradeOutcome(trade.id, outcome, profit, price);
          }
        }
      });
    };

    const fetchHistory = async () => {
      if (!isMounted) return;
      setIsLoading(true);
      const cleanSymbol = activePair.replace('/', '');
      const binanceSymbol = SYMBOL_MAP[cleanSymbol] || cleanSymbol;
      const apiInterval = BINANCE_INTERVALS[chartTimeframe] || '1m';
      
      let success = false;
      for (const baseUrl of BINANCE_REST_NODES) {
        if (!isMounted) break;
        try {
          const response = await fetch(`${baseUrl}/klines?symbol=${binanceSymbol}&interval=${apiInterval}&limit=1000`);
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          const data = await response.json();
          if (isMounted && Array.isArray(data)) {
            const formattedData: CandlestickData[] = data.map((d: any) => ({
              time: (d[0] / 1000) as Time, 
              open: parseFloat(d[1]), 
              high: parseFloat(d[2]), 
              low: parseFloat(d[3]), 
              close: parseFloat(d[4]),
            }));
            candlestickSeries.setData(formattedData);
            if (formattedData.length > 0) {
              const last = formattedData[formattedData.length - 1];
              candleStateRef.current.target = last;
              candleStateRef.current.display = { ...last };
              (window as any).lastPrice = last.close;
              processTradeResolutions(last.close);
            }
            success = true;
            break;
          }
        } catch (err: any) {
          console.warn(`Node connection failed:`, err.message);
        }
      }
      if (!success && isMounted) setErrorNode("Institutional Data Hub Unreachable");
      if (isMounted) setIsLoading(false);
    };
    fetchHistory();

    const cleanSymbol = activePair.replace('/', '');
    const binanceSymbol = (SYMBOL_MAP[cleanSymbol] || cleanSymbol).toLowerCase();
    const wsInterval = BINANCE_INTERVALS[chartTimeframe] || '1m';
    
    try {
      ws = new WebSocket(`${BINANCE_WS_URL}/${binanceSymbol}@kline_${wsInterval}`);
      ws.onmessage = (event) => {
        if (!isMounted) return;
        const msg = JSON.parse(event.data);
        if (msg.k) {
          const k = msg.k;
          const time = (k.t / 1000) as Time;
          const targetClose = parseFloat(k.c);
          if (candleStateRef.current.target && candleStateRef.current.target.time !== time) {
            candlestickSeries.update(candleStateRef.current.target);
            candleStateRef.current.display = { time, open: parseFloat(k.o), high: parseFloat(k.h), low: parseFloat(k.l), close: parseFloat(k.o) };
          }
          candleStateRef.current.target = { time, open: parseFloat(k.o), high: parseFloat(k.h), low: parseFloat(k.l), close: targetClose };
          candleStateRef.current.startTime = performance.now();
          candleStateRef.current.startPrice = candleStateRef.current.display ? candleStateRef.current.display.close : targetClose;
          candleStateRef.current.animating = true;
          processTradeResolutions(targetClose);
        }
      };
      ws.onerror = () => { if (isMounted) setErrorNode("Live Stream Interrupted"); };
    } catch (err) { console.error("WebSocket setup failed:", err); }

    const updateLoop = (now: number) => {
      if (!isMounted) return;
      const overlay = markersOverlayRef.current;
      if (!overlay || !chartRef.current || !seriesRef.current) { requestAnimationFrame(updateLoop); return; }

      const currentPrice = (window as any).lastPrice || 0;
      if (currentPrice > 0) processTradeResolutions(currentPrice);

      if (candleStateRef.current.animating && candleStateRef.current.target) {
        const elapsed = now - candleStateRef.current.startTime;
        const progress = Math.min(elapsed / candleStateRef.current.duration, 1);
        const t = easeOutCubic(progress);
        const currentClose = candleStateRef.current.startPrice + (candleStateRef.current.target.close - candleStateRef.current.startPrice) * t;
        candleStateRef.current.display = { ...candleStateRef.current.target, close: currentClose, high: Math.max(candleStateRef.current.target.high, currentClose), low: Math.min(candleStateRef.current.target.low, currentClose) };
        seriesRef.current.update(candleStateRef.current.display);
        (window as any).lastPrice = currentClose;
        if (progress >= 1) candleStateRef.current.animating = false;
      }

      const timeScale = chartRef.current.timeScale();
      const series = seriesRef.current;
      const tfSec = getTimeframeSeconds(chartTimeframeRef.current);
      const currentActivePair = activePairRef.current;
      const currentTrades = tradesRef.current;
      const width = chartContainerRef.current?.clientWidth || 0;
      const priceAreaMargin = 60;

      while (overlay.firstChild) { overlay.removeChild(overlay.firstChild); }
      const priceY = series.priceToCoordinate(currentPrice);

      if (priceY !== null) {
        const gPrice = document.createElementNS("http://www.w3.org/2000/svg", "g");
        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("x1", "0"); line.setAttribute("y1", priceY.toString());
        line.setAttribute("x2", (width - 50).toString()); line.setAttribute("y2", priceY.toString());
        line.setAttribute("stroke", "white"); line.setAttribute("stroke-width", "1");
        line.setAttribute("stroke-dasharray", "5,5"); line.setAttribute("opacity", "0.6");
        gPrice.appendChild(line);

        const countdownBoxWidth = 42; const countdownBoxHeight = 18;
        const countdownX = width - 105; const countdownY = priceY - 9;
        const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        rect.setAttribute("x", countdownX.toString()); rect.setAttribute("y", countdownY.toString());
        rect.setAttribute("width", countdownBoxWidth.toString()); rect.setAttribute("height", countdownBoxHeight.toString());
        rect.setAttribute("rx", "6"); rect.setAttribute("fill", "rgba(30, 33, 45, 0.9)");
        rect.setAttribute("stroke", "rgba(255, 255, 255, 0.1)");
        gPrice.appendChild(rect);

        const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        text.setAttribute("x", (countdownX + countdownBoxWidth / 2).toString()); text.setAttribute("y", (countdownY + 13).toString());
        text.setAttribute("text-anchor", "middle"); text.setAttribute("fill", "white");
        text.setAttribute("font-size", "9"); text.setAttribute("font-weight", "600");
        text.setAttribute("style", "font-family: Inter;"); text.textContent = countdownRef.current;
        gPrice.appendChild(text);
        overlay.appendChild(gPrice);
      }

      currentTrades.forEach(trade => {
        if (trade.pairName !== currentActivePair || trade.outcome !== 'pending') return;
        const rawTime = Math.floor(new Date(trade.date).getTime() / 1000);
        const snappedTime = Math.floor(rawTime / tfSec) * tfSec;
        const x = timeScale.timeToCoordinate(snappedTime as any);
        const y = series.priceToCoordinate(trade.openingPrice);
        if (x === null || y === null) return;
        const isUp = trade.entryType === 'UP';
        const color = isUp ? '#35CB01' : '#DB4635';
        const lineLength = timeScale.options().barSpacing * 1.5;
        const x2 = Math.min(x + lineLength, width - priceAreaMargin);
        const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
        const lineTrade = document.createElementNS("http://www.w3.org/2000/svg", "line");
        lineTrade.setAttribute("x1", x.toString()); lineTrade.setAttribute("y1", y.toString());
        lineTrade.setAttribute("x2", x2.toString()); lineTrade.setAttribute("y2", y.toString());
        lineTrade.setAttribute("stroke", color); lineTrade.setAttribute("stroke-width", "1.5");
        lineTrade.setAttribute("stroke-dasharray", "3,3"); lineTrade.setAttribute("opacity", "0.6");
        g.appendChild(lineTrade);
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", x.toString()); circle.setAttribute("cy", y.toString());
        circle.setAttribute("r", "3"); circle.setAttribute("fill", color);
        circle.setAttribute("filter", "url(#glow)");
        g.appendChild(circle);
        const labelGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
        labelGroup.setAttribute("transform", `translate(${x2 + 4}, ${y - 12})`);
        const rectLabel = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        rectLabel.setAttribute("width", "42"); rectLabel.setAttribute("height", "22");
        rectLabel.setAttribute("rx", "11"); rectLabel.setAttribute("fill", color);
        labelGroup.appendChild(rectLabel);
        const textLabel = document.createElementNS("http://www.w3.org/2000/svg", "text");
        textLabel.setAttribute("x", "18"); textLabel.setAttribute("y", "15");
        textLabel.setAttribute("fill", "white"); textLabel.setAttribute("font-size", "9");
        textLabel.setAttribute("font-weight", "900"); textLabel.setAttribute("style", "font-family: Inter;");
        textLabel.textContent = `$${trade.tradeAmount}`;
        labelGroup.appendChild(textLabel);
        const icon = document.createElementNS("http://www.w3.org/2000/svg", "path");
        if (isUp) { icon.setAttribute("d", "M4 0L8 6H0L4 0Z"); icon.setAttribute("transform", "translate(6, 8)"); }
        else { icon.setAttribute("d", "M4 6L0 0H8L4 6Z"); icon.setAttribute("transform", "translate(6, 8)"); }
        icon.setAttribute("fill", "white"); labelGroup.appendChild(icon);
        g.appendChild(labelGroup); overlay.appendChild(g);
      });
      requestAnimationFrame(updateLoop);
    };
    const animId = requestAnimationFrame(updateLoop);
    return () => { isMounted = false; if (ws) ws.close(); cancelAnimationFrame(animId); window.removeEventListener('resize', handleResize); chart.remove(); };
  }, [activePair, chartTimeframe, updateTradeOutcome, setBalance, toast, isOnline, db]);

  return (
    <div className="relative w-full h-full bg-background overflow-hidden flex flex-col no-scrollbar">
      {isLoading && (
        <div className="absolute inset-0 z-[100] flex flex-col items-center justify-center bg-background">
          <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Synchronizing Terminal...</p>
        </div>
      )}
      {errorNode && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-[100] bg-rose-500/10 border border-rose-500/20 px-4 py-2 rounded-full flex items-center gap-2 animate-in slide-in-from-top-4">
          <AlertTriangle className="h-3.5 w-3.5 text-rose-500" />
          <span className="text-[10px] font-black uppercase tracking-widest text-rose-200">{errorNode}</span>
        </div>
      )}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-[0.03] z-0">
        <Image src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" alt="Watermark" width={450} height={140} className="grayscale" />
      </div>
      <div className="absolute bottom-8 left-2 z-50">
        <Popover open={isTfPopoverOpen} onOpenChange={setIsTfPopoverOpen}>
          <PopoverTrigger asChild>
            <button className="w-[42px] h-[42px] bg-[#0B0E14] border border-white/10 rounded-full flex items-center justify-center shadow-2xl hover:bg-primary transition-all active:scale-90 group outline-none">
              <span className="text-[10px] font-black uppercase text-white group-hover:scale-110 transition-transform">{chartTimeframe}</span>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-[80px] p-0 bg-background/95 border-white/5 backdrop-blur-xl shadow-2xl rounded-xl overflow-hidden" align="start">
            <ScrollArea className="h-[200px]">
              <div className="p-1.5 space-y-0.5">
                {TIMEFRAME_OPTIONS.map((time) => (
                  <button key={time} onClick={() => { setChartTimeframe(time); setIsTfPopoverOpen(false); }} className={cn("w-full flex items-center justify-center py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all", chartTimeframe === time ? "bg-primary text-white" : "text-muted-foreground hover:bg-white/5")}>{time}</button>
                ))}
              </div>
            </ScrollArea>
          </PopoverContent>
        </Popover>
      </div>
      <div className="flex-1 relative overflow-hidden">
        <div ref={chartContainerRef} className="absolute inset-0 z-10 chart-container" />
        <svg ref={markersOverlayRef} className="absolute inset-0 z-20 pointer-events-none w-full h-full">
          <defs>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}
