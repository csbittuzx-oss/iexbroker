"use client"

import React, { useState } from 'react';
import { useStore } from '@/store/useStore';
import { Clock, ChevronDown, Check } from 'lucide-react';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

const DURATIONS = [
  "00:30", "01:00", "02:00", "05:00", "10:00", 
  "15:00", "30:00", "01:00:00", "02:00:00", "05:00:00"
];

interface DurationSelectorProps {
  variant?: 'default' | 'minimal';
}

export default function DurationSelector({ variant = 'default' }: DurationSelectorProps) {
  const { activeDuration, setActiveDuration } = useStore();
  const [open, setOpen] = useState(false);

  const handleSelect = (duration: string) => {
    setActiveDuration(duration);
    setOpen(false);
  };

  if (variant === 'minimal') {
    return (
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button className="w-full h-full flex items-center justify-center font-mono font-bold text-base outline-none">
            {activeDuration.length <= 5 ? `00:${activeDuration}` : activeDuration}
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-[140px] p-0 bg-card border shadow-2xl z-[60]" align="center">
          <ScrollArea className="h-[200px]">
            <div className="p-1.5 space-y-0.5">
              {DURATIONS.map((d) => (
                <div 
                  key={d}
                  className={cn(
                    "flex items-center justify-between px-2 py-1.5 rounded-md hover:bg-secondary/40 cursor-pointer transition-colors group",
                    activeDuration === d && "bg-primary/10 text-primary"
                  )}
                  onClick={() => handleSelect(d)}
                >
                  <span className="text-[11px] font-bold font-mono">{d}</span>
                  {activeDuration === d && <Check className="h-3 w-3" />}
                </div>
              ))}
            </div>
          </ScrollArea>
        </PopoverContent>
      </Popover>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button className="flex items-center gap-2 px-3 py-1.5 bg-secondary/30 hover:bg-secondary/50 border rounded-lg transition-all group w-full text-left">
          <div className="w-6 h-6 rounded bg-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
            <Clock className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold truncate">{activeDuration}</span>
              <ChevronDown className={cn("h-3 w-3 text-muted-foreground transition-transform", open && "rotate-180")} />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-muted-foreground uppercase font-bold tracking-tight">Time</span>
            </div>
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[140px] p-0 bg-card border shadow-2xl animate-in zoom-in-95 duration-200" align="start">
        <ScrollArea className="h-[200px]">
          <div className="p-1.5 space-y-0.5">
            {DURATIONS.map((d) => (
              <div 
                key={d}
                className={cn(
                  "flex items-center justify-between px-2 py-1.5 rounded-md hover:bg-secondary/40 cursor-pointer transition-colors group",
                  activeDuration === d && "bg-primary/10 text-primary"
                )}
                onClick={() => handleSelect(d)}
              >
                <span className="text-[11px] font-bold font-mono">{d}</span>
                {activeDuration === d && <Check className="h-3 w-3" />}
              </div>
            ))}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
