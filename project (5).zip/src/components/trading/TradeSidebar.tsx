
"use client"

import React, { useState, useEffect } from 'react';
import { useStore, type Trade } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TrendingUp, TrendingDown, History, Plus, Minus, Clock, ArrowUp, ArrowDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import AssetSelector, { getSynchronizedPayout } from './AssetSelector';
import DurationSelector from './DurationSelector';
import { doc, updateDoc, increment } from 'firebase/firestore';
import { useFirestore } from '@/firebase';

function TradeTimer({ expiryDate }: { expiryDate: string }) {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const update = () => {
      const now = Date.now();
      const exp = new Date(expiryDate).getTime();
      setTimeLeft(Math.max(0, Math.floor((exp - now) / 1000)));
    };
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [expiryDate]);

  const m = Math.floor(timeLeft / 60);
  const s = timeLeft % 60;
  return <span>{m.toString().padStart(2, '0')}:{s.toString().padStart(2, '0')}s</span>;
}

export default function TradeSidebar() {
  const { 
    activePair, 
    activeDuration, 
    tradeAmount, 
    setTradeAmount, 
    payoutPercent, 
    setPayoutPercent,
    balance, 
    setBalance,
    addTrade,
    trades,
    user
  } = useStore();
  const { toast } = useToast();
  const db = useFirestore();
  const [isProcessing, setIsProcessing] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const updatePayout = () => {
      const currentSync = getSynchronizedPayout(activePair);
      if (payoutPercent !== currentSync) {
        setPayoutPercent(currentSync);
      }
    };
    updatePayout();
    const interval = setInterval(updatePayout, 10000);
    return () => clearInterval(interval);
  }, [activePair, payoutPercent, setPayoutPercent]);

  useEffect(() => {
    setMounted(true);
  }, []);

  const returnAmount = tradeAmount * (1 + payoutPercent / 100);

  const adjustAmount = (val: number) => {
    const newAmount = Math.max(1, tradeAmount + val);
    setTradeAmount(newAmount);
  };

  const parseDurationSeconds = (d: string) => {
    const parts = d.split(':').map(Number);
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return parts[0] * 60;
  };

  const handleTrade = async (type: 'UP' | 'DOWN') => {
    if (tradeAmount > balance) {
      toast({
        variant: "destructive",
        title: "Insufficient Balance",
        description: "Please deposit more funds to place this trade."
      });
      return;
    }

    setIsProcessing(true);
    
    setTimeout(() => {
      setIsProcessing(false);
      
      const durationSec = parseDurationSeconds(activeDuration);
      const entryDate = new Date();
      const expiryDate = new Date(entryDate.getTime() + durationSec * 1000);
      const currentPrice = (window as any).lastPrice || 2500; 

      const newTrade: Trade = {
        id: Math.random().toString(36).substring(2, 10).toUpperCase(),
        pairName: activePair,
        openingPrice: currentPrice, 
        closingPrice: 0,
        tradeAmount,
        profitAmount: 0,
        outcome: 'pending',
        duration: activeDuration,
        date: entryDate.toISOString(),
        expiryDate: expiryDate.toISOString(),
        entryType: type
      };
      
      setBalance(prev => prev - tradeAmount);
      if (user?.uid) {
        updateDoc(doc(db, 'users', user.uid), { balance: increment(-tradeAmount) })
          .catch(e => console.error("Order persistence failed", e));
      }
      addTrade(newTrade);

      const { dismiss } = toast({
        title: "Order Placed",
        description: "Execution audit synced.",
      });
      setTimeout(dismiss, 1000);
    }, 50);
  };

  if (!mounted) return null;

  return (
    <div className="flex flex-col h-full bg-card">
      <div className="p-3 border-b flex flex-col gap-3">
        <div className="bg-white/[0.03] border border-white/5 rounded-xl p-3.5 space-y-4 shadow-2xl">
          <AssetSelector />
          <DurationSelector />
          <div className="space-y-1.5">
            <div className="flex items-center justify-between px-1">
              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">Investment</label>
              <span className="text-[10px] text-muted-foreground uppercase font-black tracking-widest opacity-40">MIN $1</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Button variant="outline" size="icon" className="h-9 w-9 shrink-0 border-white/5 bg-white/[0.03] hover:bg-white/[0.08] rounded-lg" onClick={() => adjustAmount(-1)}>
                <Minus className="h-3 w-3" />
              </Button>
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs font-bold">$</span>
                <Input type="number" value={tradeAmount} onChange={(e) => setTradeAmount(Number(e.target.value))} className="pl-6 pr-2 h-9 bg-white/[0.03] border-white/5 rounded-lg text-xs font-mono font-black text-center focus-visible:ring-primary/40" />
              </div>
              <Button variant="outline" size="icon" className="h-9 w-9 shrink-0 border-white/5 bg-white/[0.03] hover:bg-white/[0.08] rounded-lg" onClick={() => adjustAmount(1)}>
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2.5 pt-0.5">
            <Button onClick={() => handleTrade('UP')} disabled={isProcessing} className="flex-1 h-12 bg-[#35CB01] hover:bg-[#35CB01]/90 rounded-xl flex items-center justify-between px-3.5 font-bold text-base shadow-lg shadow-[#35CB01]/20 border-none transition-transform active:scale-95">
              <span className="tracking-tight uppercase text-[11px] font-black">Up</span>
              <div className="w-7 h-7 bg-white/20 rounded-lg flex items-center justify-center"><ArrowUp className="h-4 w-4" /></div>
            </Button>
            <Button onClick={() => handleTrade('DOWN')} disabled={isProcessing} className="flex-1 h-12 bg-[#DB4635] hover:bg-[#DB4635]/90 rounded-xl flex items-center justify-between px-3.5 font-bold text-base shadow-lg shadow-[#DB4635]/20 border-none transition-transform active:scale-95">
              <span className="tracking-tight uppercase text-[11px] font-black">Down</span>
              <div className="w-7 h-7 bg-white/20 rounded-lg flex items-center justify-center"><ArrowDown className="h-4 w-4" /></div>
            </Button>
          </div>
          <div className="bg-black/20 rounded-lg p-3 space-y-2 border border-white/[0.02]">
            <div className="flex justify-between items-center">
              <span className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Profit ({payoutPercent}%)</span>
              <span className="font-mono text-sm font-black text-[#35CB01]">+${(tradeAmount * (payoutPercent / 100)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between items-center border-t border-white/[0.05] pt-2">
              <span className="text-[9px] font-black uppercase tracking-widest text-foreground">Total Return</span>
              <span className="font-mono text-sm font-black text-[#35CB01]">${returnAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="flex-1 flex flex-col min-h-0 bg-background">
        <div className="px-5 pt-5 pb-3 flex items-center gap-3">
          <History className="h-4 w-4 text-primary" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Recent Trades</h3>
        </div>
        <ScrollArea className="flex-1">
          <div className="px-4 pb-10 space-y-2">
            {trades.slice(0, 15).map((t) => (
              <div key={t.id} className="flex justify-between items-center p-3 rounded-xl bg-white/[0.02] border border-white/[0.02] hover:border-primary/20 transition-all group">
                <div className="flex flex-col gap-0.5">
                  <span className="font-black tracking-tight text-[11px] uppercase group-hover:text-primary transition-colors">{t.pairName}</span>
                  <span className="text-[7px] text-muted-foreground uppercase font-bold tracking-tighter opacity-60">{t.duration} • {new Date(t.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</span>
                </div>
                <div className={cn("font-mono font-black text-[11px] flex items-center gap-1.5", t.outcome === 'profit' ? 'text-[#35CB01]' : t.outcome === 'loss' ? 'text-[#DB4635]' : 'text-amber-400')}>
                  {t.outcome === 'pending' ? (<><Clock className="h-3 w-3 animate-pulse" /><TradeTimer expiryDate={t.expiryDate} /></>) : (`${t.outcome === 'profit' ? '+' : ''}${t.profitAmount.toFixed(2)}$`)}
                </div>
              </div>
            ))}
            {trades.length === 0 && (
              <div className="text-center py-16 border-2 border-dashed rounded-2xl bg-white/[0.01] border-white/5 mx-2">
                <p className="text-[9px] text-muted-foreground uppercase font-black tracking-[0.2em] opacity-30">Execution Log Empty</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
