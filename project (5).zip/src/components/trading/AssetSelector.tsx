"use client"

import React, { useState, useMemo, useEffect } from 'react';
import { useStore, type Asset } from '@/store/useStore';
import { 
  Search, 
  Star, 
  ChevronDown, 
  TrendingUp,
  Lock
} from 'lucide-react';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

const ASSETS: Asset[] = [
  { symbol: 'BTCUSDT', name: 'Bitcoin / USDT', type: 'crypto', payout: 88 },
  { symbol: 'XAUUSDT.P', name: 'Gold / USDT Perpetual', type: 'crypto', payout: 90 },
  { symbol: 'ICPUSDT', name: 'Internet Computer', type: 'crypto', payout: 80 },
  { symbol: 'DASHUSDT', name: 'Dash / USDT', type: 'crypto', payout: 78 },
  { symbol: 'KITEUSDT', name: 'Kite / USDT', type: 'crypto', payout: 82 },
  { symbol: 'INJUSDT', name: 'Injective / USDT', type: 'crypto', payout: 85 },
  { symbol: 'CRVUSDT', name: 'Curve / USDT', type: 'crypto', payout: 75 },
  { symbol: 'SOLUSDT', name: 'Solana / USDT', type: 'crypto', payout: 82 },
  { symbol: 'ETHUSDT', name: 'Ethereum / USDT', type: 'crypto', payout: 80 },
  { symbol: 'BNBUSDT', name: 'Binance Coin / USDT', type: 'crypto', payout: 78 },
  { symbol: 'XRPUSDT', name: 'Ripple / USDT', type: 'crypto', payout: 75 },
  { symbol: 'DOGEUSDT', name: 'Dogecoin / USDT', type: 'crypto', payout: 70 },
  { symbol: 'ZECUSDT', name: 'Zcash / USDT', type: 'crypto', payout: 72 },
  { symbol: 'SUIUSDT', name: 'Sui / USDT', type: 'crypto', payout: 85 },
  { symbol: 'TAOUSDT', name: 'Bittensor / USDT', type: 'crypto', payout: 88 },
  { symbol: 'TONUSDT', name: 'Toncoin / USDT', type: 'crypto', payout: 84 },
  { symbol: 'AAVEUSDT', name: 'Aave / USDT', type: 'crypto', payout: 82 },
  { symbol: 'EURUSD', name: 'EUR / USD', type: 'forex', payout: 92 },
  { symbol: 'GBPUSD', name: 'GBP / USD', type: 'forex', payout: 90 },
  { symbol: 'USDJPY', name: 'USD / JPY', type: 'forex', payout: 88 },
  { symbol: 'AUDUSD', name: 'AUD / USD', type: 'forex', payout: 85 },
  { symbol: 'USDCAD', name: 'USD / CAD', type: 'forex', payout: 87 },
  { symbol: 'GBPJPY', name: 'GBP / JPY', type: 'forex', payout: 89 },
  { symbol: 'USDCHF', name: 'USD / CHF', type: 'forex', payout: 86 },
  { symbol: 'NZDUSD', name: 'NZD / USD', type: 'forex', payout: 84 },
  { symbol: 'EURJPY', name: 'EUR / JPY', type: 'forex', payout: 88 },
  { symbol: 'EURAUD', name: 'EUR / AUD', type: 'forex', payout: 85 },
  { symbol: 'AUDCAD', name: 'AUD / CAD', type: 'forex', payout: 83 },
  { symbol: 'EURGBP', name: 'EUR / GBP', type: 'forex', payout: 91 },
  { symbol: 'GBPCAD', name: 'GBP / CAD', type: 'forex', payout: 87 },
  { symbol: 'AUDCHF', name: 'AUD / CHF', type: 'forex', payout: 84 },
  { symbol: 'CADJPY', name: 'CAD / JPY', type: 'forex', payout: 86 },
];

/**
 * Calculates a synchronized payout percentage based on UTC time.
 * Changes every 30 minutes and varies by asset groups.
 */
export const getSynchronizedPayout = (symbol: string) => {
  const now = new Date();
  const bucket = Math.floor((now.getUTCHours() * 60 + now.getUTCMinutes()) / 30);
  
  let hash = 0;
  for (let i = 0; i < symbol.length; i++) {
    hash = ((hash << 5) - hash) + symbol.charCodeAt(i);
  }
  const groupId = Math.abs(hash) % 8; 

  const seed = (bucket * 0.1337) + (groupId * 0.5432);
  const val = 75 + (Math.abs(Math.sin(seed * 42.42)) * 17);
  return Math.floor(val);
};

interface AssetSelectorProps {
  variant?: 'default' | 'minimal';
}

export default function AssetSelector({ variant = 'default' }: AssetSelectorProps) {
  const { activePair, setActivePair, payoutPercent, setPayoutPercent, favorites, toggleFavorite } = useStore();
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<'crypto' | 'forex'>('crypto');
  const [search, setSearch] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const update = () => {
      const syncVal = getSynchronizedPayout(activePair);
      if (payoutPercent !== syncVal) {
        setPayoutPercent(syncVal);
      }
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, [activePair, payoutPercent, setPayoutPercent]);

  const filteredAssets = useMemo(() => {
    return ASSETS.filter(a => 
      a.type === type && 
      (a.symbol.toLowerCase().includes(search.toLowerCase()) || 
       a.name.toLowerCase().includes(search.toLowerCase()))
    ).sort((a, b) => {
      const aFav = favorites.includes(a.symbol) ? 0 : 1;
      const bFav = favorites.includes(b.symbol) ? 0 : 1;
      return aFav - bFav;
    });
  }, [type, search, favorites]);

  const currentAsset = ASSETS.find(a => a.symbol === activePair) || ASSETS[0];

  const handleSelect = (asset: Asset) => {
    if (asset.type === 'forex') {
      toast({
        title: "Market Locked",
        description: "Forex pairs are currently undergoing maintenance. Coming soon.",
      });
      return;
    }
    setActivePair(asset.symbol);
    setPayoutPercent(getSynchronizedPayout(asset.symbol));
    setOpen(false);
  };

  const renderAssetItem = (asset: Asset) => {
    const isForex = asset.type === 'forex';
    const isActive = activePair === asset.symbol;
    const itemPayout = getSynchronizedPayout(asset.symbol);
    const displayPayout = isForex ? "COMMISSION SOON" : `+${itemPayout}%`;

    return (
      <div 
        key={asset.symbol}
        className={cn(
          "flex items-center gap-3 p-3 rounded-lg transition-all group relative",
          isForex ? "opacity-40 cursor-not-allowed grayscale-[0.5]" : "hover:bg-secondary/40 cursor-pointer",
          isActive && !isForex && "bg-primary/10 border-l-2 border-primary"
        )}
        onClick={() => handleSelect(asset)}
      >
        <button 
          onClick={(e) => {
            e.stopPropagation();
            if (!isForex) toggleFavorite(asset.symbol);
          }}
          className={cn("shrink-0", isForex && "pointer-events-none")}
        >
          <Star 
            className={cn(
              "h-4 w-4 transition-colors", 
              favorites.includes(asset.symbol) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground hover:text-yellow-400"
            )} 
          />
        </button>
        
        <div className="flex-1 overflow-hidden">
          <div className="text-sm font-bold flex items-center justify-between">
            <span className="flex items-center gap-2">
              {asset.symbol}
              {isForex && <Lock className="h-2.5 w-2.5 opacity-50" />}
            </span>
            <span className={cn(
              "font-mono text-xs font-black",
              isForex ? "text-muted-foreground" : "text-emerald-400"
            )}>
              {displayPayout}
            </span>
          </div>
        </div>

        {isActive && !isForex && (
          <TrendingUp className="h-4 w-4 text-primary absolute right-3" />
        )}
      </div>
    );
  };

  if (variant === 'minimal') {
    return (
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button className="flex items-center gap-1.5 group outline-none">
            <span className="text-sm font-bold tracking-tight">{currentAsset.symbol}</span>
            <span className="text-sm font-bold text-orange-400">{getSynchronizedPayout(activePair)}%</span>
            <ChevronDown className={cn("h-3 w-3 text-muted-foreground transition-transform ml-0.5", open && "rotate-180")} />
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-[320px] p-0 bg-card border-none shadow-2xl z-[60]" align="center">
          <div className="p-4 border-b space-y-4">
            <Tabs value={type} onValueChange={(v) => setType(v as any)} className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-secondary/50">
                <TabsTrigger value="crypto" className="text-xs font-bold">CRYPTO</TabsTrigger>
                <TabsTrigger value="forex" className="text-xs font-bold">FOREX</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search pairs..." 
                className="pl-9 h-10 bg-secondary/30 border-none rounded-lg text-sm"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          <ScrollArea className="h-[350px]">
            <div className="p-2 space-y-1">
              {filteredAssets.map(asset => renderAssetItem(asset))}
            </div>
          </ScrollArea>
        </PopoverContent>
      </Popover>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button className="flex items-center gap-3 px-3 py-2 bg-secondary/30 hover:bg-secondary/50 border rounded-lg transition-all group w-full text-left">
          <div className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold truncate">{currentAsset.symbol}</span>
              <ChevronDown className={cn("h-3 w-3 text-muted-foreground transition-transform", open && "rotate-180")} />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-muted-foreground uppercase font-bold truncate">{currentAsset.name}</span>
              <span className="text-[9px] text-emerald-400 font-bold">+{getSynchronizedPayout(activePair)}%</span>
            </div>
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[320px] p-0 bg-card border-none shadow-2xl animate-in slide-in-from-top-4 duration-300" align="start">
        <div className="p-4 border-b space-y-4">
          <Tabs value={type} onValueChange={(v) => setType(v as any)} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-secondary/50">
              <TabsTrigger value="crypto" className="text-xs font-bold">CRYPTO</TabsTrigger>
              <TabsTrigger value="forex" className="text-xs font-bold">FOREX</TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search pairs..." 
              className="pl-9 h-10 bg-secondary/30 border-none rounded-lg text-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <ScrollArea className="h-[350px]">
          <div className="p-2 space-y-1">
            {filteredAssets.map(asset => renderAssetItem(asset))}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
