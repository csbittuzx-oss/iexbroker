
"use client"

import React, { useState, useEffect } from 'react';
import { useStore, type Trade } from '@/store/useStore';
import { 
  History, 
  Activity, 
  ArrowUpRight, 
  ArrowDownLeft,
  Clock,
  X
} from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

function TradeTimer({ expiryDate }: { expiryDate: string }) {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const update = () => {
      const now = Date.now();
      const exp = new Date(expiryDate).getTime();
      setTimeLeft(Math.max(0, Math.floor((exp - now) / 1000)));
    };
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [expiryDate]);

  const m = Math.floor(timeLeft / 60);
  const s = timeLeft % 60;
  return <span>{m.toString().padStart(2, '0')}:{s.toString().padStart(2, '0')}s</span>;
}

function TradeItem({ trade }: { trade: Trade }) {
  const isPending = trade.outcome === 'pending';
  const isProfit = trade.outcome === 'profit';
  
  return (
    <div className="flex items-center justify-between p-4 bg-[#14141A] rounded-2xl border border-white/[0.03] shadow-sm transition-all active:scale-[0.98]">
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
          isPending 
            ? (trade.entryType === 'UP' ? "bg-[#35CB01]/10 text-[#35CB01]" : "bg-[#DB4635]/10 text-[#DB4635]")
            : (isProfit ? "bg-[#35CB01]/10 text-[#35CB01]" : "bg-[#DB4635]/10 text-[#DB4635]")
        )}>
          {trade.entryType === 'UP' ? (
            <ArrowUpRight className="h-5 w-5 stroke-[2.5px]" />
          ) : (
            <ArrowDownLeft className="h-5 w-5 stroke-[2.5px]" />
          )}
        </div>

        <div className="flex flex-col gap-0.5">
          <span className="text-sm font-black tracking-tight text-white uppercase">{trade.pairName}</span>
          <span className="text-[10px] text-muted-foreground font-bold tracking-tight opacity-50 uppercase">
            {trade.duration} • {new Date(trade.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
          </span>
        </div>
      </div>

      <div className="text-right">
        {isPending ? (
          <div className="flex flex-col items-end">
            <div className="text-sm font-mono font-black text-amber-400">
              <TradeTimer expiryDate={trade.expiryDate} />
            </div>
            <div className="text-[8px] text-muted-foreground uppercase font-black tracking-widest mt-0.5 opacity-60">
              RUNNING
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-end">
            <div className={cn(
              "text-[15px] font-mono font-black tracking-tight",
              isProfit ? "text-[#35CB01]" : "text-[#DB4635]"
            )}>
              {isProfit ? '+' : '-'}{Math.abs(trade.profitAmount).toFixed(2)}$
            </div>
            <div className={cn(
               "text-[9px] font-black uppercase tracking-widest mt-0.5",
               isProfit ? "text-[#35CB01]" : "text-[#DB4635]"
            )}>
              {isProfit ? 'PROFIT' : 'LOSS'}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function HistoryPopup({ onClose }: { onClose: () => void }) {
  const { trades } = useStore();
  
  // Sort by date newest first to ensure top-down populating
  const sortedTrades = [...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const runningTrades = sortedTrades.filter(t => t.outcome === 'pending');
  const pastTrades = sortedTrades.filter(t => t.outcome !== 'pending');

  return (
    <div className="flex flex-col h-full bg-[#0B0B0F] overflow-hidden">
      {/* Institutional Header */}
      <div className="flex items-center justify-between px-6 py-5 shrink-0 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="text-[#3E42DF]">
            <History className="h-5 w-5 stroke-[2.5px]" />
          </div>
          <h3 className="font-black uppercase tracking-[0.1em] text-[15px] text-white">TRADE ACTIVITIES</h3>
        </div>
        <button 
          onClick={onClose}
          className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
        >
          <X className="h-5 w-5 text-white opacity-60" />
        </button>
      </div>

      {/* Pill Styled Status Bar */}
      <div className="px-5 py-3 shrink-0">
        <div className="bg-[#14141A] h-12 flex items-center justify-center rounded-full border border-white/[0.03]">
           <span className="text-[10px] font-black uppercase tracking-widest text-white flex items-center gap-2">
             <Activity className="h-3.5 w-3.5 text-primary" /> RECENT TRADES
           </span>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-4 px-5 pb-24 pt-1">
          {/* Running Trades Section */}
          {runningTrades.length > 0 && (
            <div className="space-y-2">
              <div className="text-[9px] font-black uppercase text-muted-foreground tracking-widest px-1">Running ({runningTrades.length})</div>
              {runningTrades.map((trade) => (
                <TradeItem key={trade.id} trade={trade} />
              ))}
            </div>
          )}

          {/* Past History Section */}
          {pastTrades.length > 0 && (
            <div className="space-y-2">
              <div className="text-[9px] font-black uppercase text-muted-foreground tracking-widest px-1">History</div>
              {pastTrades.map((trade) => (
                <TradeItem key={trade.id} trade={trade} />
              ))}
            </div>
          )}

          {trades.length === 0 && (
            <div className="py-24 text-center flex flex-col items-center justify-center gap-4 opacity-40">
              <div className="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center">
                <Clock className="h-7 w-7 text-muted-foreground" />
              </div>
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Log is currently empty</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
