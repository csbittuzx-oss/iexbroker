"use client"

import React from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowUpRight, ArrowDownRight, Hash, Clock, FileText } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface TradeHistoryViewProps {
  onBack: () => void;
}

export default function TradeHistoryView({ onBack }: TradeHistoryViewProps) {
  const { trades } = useStore();
  const sortedTrades = [...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="flex flex-col h-full animate-in slide-in-from-right duration-500 bg-[#0B0B0F]">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/5 px-4 lg:px-6 pt-4">
        <div className="flex items-center gap-3 lg:gap-4">
          <Button variant="ghost" size="sm" onClick={onBack} className="gap-1.5 lg:gap-2 font-black uppercase tracking-widest text-[8px] lg:text-[9px] h-8 hover:bg-white/5">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </Button>
          <div className="h-5 w-px bg-white/10" />
          <div className="flex items-center gap-2 text-primary">
            <FileText className="h-3.5 w-3.5 lg:h-4 lg:w-4" />
            <h3 className="text-[10px] lg:text-[11px] font-black uppercase tracking-[0.2em]">Trading Audit</h3>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-[#35CB01] rounded-full animate-pulse" />
          <span className="text-[8px] font-black uppercase tracking-widest text-[#35CB01]">Live Audit active</span>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="space-y-2.5 max-w-6xl mx-auto px-4 lg:px-6 pb-20">
          {sortedTrades.length > 0 ? (
            sortedTrades.map((trade) => (
              <div 
                key={trade.id} 
                className="bg-[#14141A] border border-white/5 rounded-xl p-4 hover:border-primary/40 hover:bg-white/[0.03] transition-all group relative overflow-hidden"
              >
                <div className="absolute right-0 top-0 p-4 opacity-[0.02] pointer-events-none group-hover:opacity-[0.04] transition-opacity">
                  {trade.outcome === 'profit' ? <ArrowUpRight className="h-12 lg:h-16 w-12 lg:w-16" /> : <ArrowDownRight className="h-12 lg:h-16 w-12 lg:w-16" />}
                </div>

                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
                  <div className="flex items-center gap-4 min-w-[180px] lg:min-w-[200px]">
                    <div className={cn(
                      "w-9 h-9 lg:w-10 lg:h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-105 duration-300",
                      trade.outcome === 'profit' ? "bg-[#35CB01]/10 text-[#35CB01]" : trade.outcome === 'pending' ? "bg-amber-500/10 text-amber-500" : "bg-[#DB4635]/10 text-[#DB4635]"
                    )}>
                      {trade.outcome === 'profit' ? <ArrowUpRight className="h-4 w-4 lg:h-5 lg:w-5" /> : trade.outcome === 'pending' ? <Clock className="h-4 w-4 lg:h-5 lg:w-5 animate-pulse" /> : <ArrowDownRight className="h-4 w-4 lg:h-5 lg:w-5" />}
                    </div>
                    <div>
                      <h4 className="text-xs lg:text-sm font-black tracking-tight group-hover:text-primary transition-colors uppercase truncate max-w-[140px] lg:max-w-none">{trade.pairName}</h4>
                      <div className="flex items-center gap-2 lg:gap-3 mt-1">
                        <span className="flex items-center gap-1 text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground truncate max-w-[80px]">
                          <Hash className="h-2 w-2 lg:h-2.5 lg:w-2.5" /> {trade.id}
                        </span>
                        <span className="flex items-center gap-1 text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground whitespace-nowrap">
                          <Clock className="h-2 w-2 lg:h-2.5 lg:w-2.5" /> {new Date(trade.date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 lg:gap-x-8 gap-y-2 flex-1 px-0 md:px-4 lg:px-8 border-t md:border-t-0 md:border-l border-dashed border-white/10 pt-4 md:pt-0">
                    <div className="space-y-0.5">
                      <p className="text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground tracking-widest leading-none">Opening</p>
                      <p className="text-[10px] lg:text-xs font-mono font-bold text-foreground leading-none">{trade.openingPrice.toFixed(trade.pairName.includes('JPY') ? 3 : 5)}</p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground tracking-widest leading-none">Closing</p>
                      <p className={cn(
                        "text-[10px] lg:text-xs font-mono font-bold leading-none",
                        trade.outcome === 'pending' ? "text-muted-foreground italic" : "text-foreground"
                      )}>
                        {trade.outcome === 'pending' ? "Live..." : trade.closingPrice.toFixed(trade.pairName.includes('JPY') ? 3 : 5)}
                      </p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground tracking-widest leading-none">Investment</p>
                      <p className="text-[10px] lg:text-xs font-mono font-bold text-accent leading-none">${trade.tradeAmount.toFixed(2)}</p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground tracking-widest leading-none">Entry</p>
                      <p className={cn(
                        "text-[9px] lg:text-[10px] font-black uppercase tracking-tighter leading-none",
                        trade.entryType === 'UP' ? "text-[#35CB01]" : "text-[#DB4635]"
                      )}>{trade.entryType}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 min-w-[100px] lg:min-w-[120px] border-t md:border-t-0 pt-3 md:pt-0 border-white/5 flex md:flex-col items-center md:items-end justify-between md:justify-center">
                    <div className={cn(
                      "text-base lg:text-lg font-mono font-black tracking-tighter",
                      trade.outcome === 'profit' ? "text-[#35CB01]" : trade.outcome === 'pending' ? "text-amber-400 animate-pulse" : "text-[#DB4635]"
                    )}>
                      {trade.outcome === 'pending' ? "AUDITING" : `${trade.outcome === 'profit' ? '+' : ''}${trade.profitAmount.toFixed(2)}$`}
                    </div>
                    <div className="text-[7px] lg:text-[8px] font-black uppercase tracking-widest text-muted-foreground mt-0.5">
                      {trade.outcome === 'profit' ? 'Realized' : trade.outcome === 'pending' ? 'Active' : 'Loss'}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-32 border-2 border-dashed rounded-3xl bg-white/[0.01] border-white/5">
              <div className="p-4 bg-white/5 rounded-full mb-4">
                <FileText className="h-8 w-8 text-muted-foreground/30" />
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Audit Empty</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
