
"use client"

import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  History, 
  Headphones, 
  LogOut, 
  User,
  ArrowLeftRight,
  ArrowDownToLine,
  ShieldCheck,
  LayoutDashboard,
  Copy,
  Check,
  Briefcase,
  Activity,
  Lock,
  ChevronRight,
  Menu,
  ArrowLeft,
  X,
  Plus,
  PieChart
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import PayoutModal from '@/components/payout/PayoutModal';
import TradeHistoryView from './TradeHistoryView';
import TransactionHistoryView from './TransactionHistoryView';
import AccountAnalyticsView from './AccountAnalyticsView';
import SupportModal from '@/components/support/SupportModal';
import ProfileHero from './ProfileHero';
import ActivityTimeline from './ActivityTimeline';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { useFirestore } from '@/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

interface ProfileViewProps {
  onDeposit?: () => void;
  onWithdraw?: () => void;
  onClose?: () => void;
  initialView?: 'menu' | 'history' | 'transactions' | 'analytics';
}

const USD_TO_INR = 83.42;

export default function ProfileView({ onDeposit, onWithdraw, onClose, initialView = 'menu' }: ProfileViewProps) {
  const { user, balance, currency, setLoggedIn, profileView, setProfileView, setUser } = useStore();
  
  const [tempNickname, setTempNickname] = useState(user?.nickname || '');
  const [tempAddress, setTempAddress] = useState(user?.country || '');
  const [tempFirstName, setTempFirstName] = useState(user?.firstName || '');
  const [tempLastName, setTempLastName] = useState(user?.lastName || '');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [hasCopied, setHasCopied] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const router = useRouter();
  const { toast } = useToast();
  const db = useFirestore();

  useEffect(() => {
    if (initialView) setProfileView(initialView);
  }, [initialView, setProfileView]);

  if (!user) return null;

  const handleCopyUid = () => {
    navigator.clipboard.writeText(user.uid);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
    toast({ title: "UID Copied", description: "Identity node reference saved to clipboard." });
  };

  const handleSaveChanges = () => {
    if (isSaving) return;
    setIsSaving(true);

    const updateData: any = {
      nickname: tempNickname,
      country: tempAddress
    };

    if (!user.namesEdited) {
      updateData.firstName = tempFirstName;
      updateData.lastName = tempLastName;
      updateData.namesEdited = true;
    }

    const userRef = doc(db, 'users', user.uid);
    updateDoc(userRef, updateData)
      .then(() => {
        setUser({ ...user, ...updateData });
        toast({ title: "Identity Synchronized", description: "Institutional profile updated successfully." });
      })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: userRef.path,
          operation: 'update',
          requestResourceData: updateData,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setTimeout(() => setIsSaving(false), 1000);
      });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast({ variant: "destructive", title: "Asset Size Alert", description: "Identity media must be under 2MB." });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setUser({ ...user, profilePic: base64String });
        const userRef = doc(db, 'users', user.uid);
        updateDoc(userRef, { profilePic: base64String })
          .catch(async (e) => {
            const permissionError = new FirestorePermissionError({
              path: userRef.path,
              operation: 'update',
              requestResourceData: { profilePic: 'BASE64_DATA' },
            } satisfies SecurityRuleContext);
            errorEmitter.emit('permission-error', permissionError);
          });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWithdrawalRequest = () => {
    if (onWithdraw) {
      onWithdraw();
    } else {
      setShowPayoutModal(true);
    }
  };

  const displayBalance = currency === 'INR' ? balance * USD_TO_INR : balance;
  const currencySymbol = currency === 'INR' ? '₹' : '$';

  if (profileView === 'history') return <TradeHistoryView onBack={() => setProfileView('menu')} />;
  if (profileView === 'transactions') return <TransactionHistoryView onBack={() => setProfileView('menu')} />;
  if (profileView === 'analytics') return <AccountAnalyticsView onBack={() => setProfileView('menu')} />;

  return (
    <div className="h-full flex flex-col w-full bg-[#07080B] text-foreground overflow-hidden relative font-body selection:bg-primary/30">
      {/* Reduced animation complexity on small screens */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px] pointer-events-none sm:animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="flex flex-1 overflow-hidden relative z-10">
        
        {/* SIDEBAR */}
        <aside className={cn(
          "fixed inset-y-0 left-0 z-[60] w-72 bg-[#0F1116]/95 backdrop-blur-3xl border-r border-white/5 flex flex-col transition-transform duration-500 lg:relative lg:translate-x-0 lg:z-50",
          mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <div className="p-8 shrink-0 flex flex-col gap-10">
             <div className="flex items-center justify-between">
                <Image src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" alt="Logo" width={100} height={32} className="h-6 w-auto" />
                <button onClick={() => setMobileMenuOpen(false)} className="lg:hidden p-2 hover:bg-white/5 rounded-xl"><X className="h-5 w-5" /></button>
             </div>

             <nav className="flex flex-col gap-1">
                <NavButton icon={<LayoutDashboard />} label="Dashboard" active={profileView === 'menu'} onClick={() => { setProfileView('menu'); setMobileMenuOpen(false); }} />
                <NavButton icon={<Briefcase />} label="Portfolio" active={profileView === 'analytics'} onClick={() => { setProfileView('analytics'); setMobileMenuOpen(false); }} />
                <NavButton icon={<History />} label="Trade Audit" active={profileView === 'history'} onClick={() => { setProfileView('history'); setMobileMenuOpen(false); }} />
                <NavButton icon={<PieChart />} label="Trading Analytics" active={profileView === 'analytics'} onClick={() => { setProfileView('analytics'); setMobileMenuOpen(false); }} />
                <NavButton icon={<ArrowLeftRight />} label="Transactions" active={profileView === 'transactions'} onClick={() => { setProfileView('transactions'); setMobileMenuOpen(false); }} />
                <NavButton icon={<Headphones />} label="Support Desk" onClick={() => { setShowSupportModal(true); setMobileMenuOpen(false); }} />
             </nav>
          </div>

          <div className="mt-auto p-8 border-t border-white/5">
             <button 
               onClick={() => { setLoggedIn(false); router.push('/auth'); }}
               className="flex items-center gap-4 w-full p-4 rounded-2xl text-muted-foreground hover:bg-rose-500/10 hover:text-rose-500 transition-all font-black uppercase text-[10px] tracking-[0.2em]"
             >
               <LogOut className="h-4 w-4" /> Sign Out Matrix
             </button>
          </div>
        </aside>

        {/* MAIN CONTENT */}
        <main className="flex-1 flex flex-col overflow-hidden relative">
          
          <header className="h-14 lg:h-20 shrink-0 border-b border-white/5 bg-[#07080B]/50 sm:backdrop-blur-xl flex items-center justify-between px-4 lg:px-10">
             <div className="flex items-center gap-3 lg:gap-6">
                <button onClick={() => setMobileMenuOpen(true)} className="p-2 bg-white/5 rounded-xl"><Menu className="h-4 w-4" /></button>
                
                {onClose && (
                  <Button 
                    variant="ghost" 
                    onClick={onClose}
                    className="hidden sm:flex items-center gap-2 px-3 lg:px-5 h-9 lg:h-11 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-[8px] lg:text-[10px] font-black uppercase tracking-widest transition-all group"
                  >
                    <ArrowLeft className="h-3.5 w-3.5 lg:h-4 lg:w-4 transition-transform group-hover:-translate-x-1" />
                    <span>Back to Terminal</span>
                  </Button>
                )}

                <div className="hidden md:flex items-center gap-3">
                  <Button 
                    onClick={onDeposit} 
                    className="h-10 px-6 bg-primary hover:bg-primary/90 text-white rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg shadow-primary/20"
                  >
                    <Plus className="h-3 w-3 mr-2" /> Deposit
                  </Button>
                  <Button 
                    onClick={handleWithdrawalRequest} 
                    variant="outline"
                    className="h-10 px-6 border-white/10 hover:bg-white/5 rounded-xl font-black uppercase text-[10px] tracking-widest"
                  >
                    <ArrowDownToLine className="h-3 w-3 mr-2" /> Withdraw
                  </Button>
                </div>
             </div>

             <div className="flex items-center gap-2 lg:gap-4">
                <div className="flex items-center gap-2 lg:gap-3">
                   <div className="text-right hidden sm:block">
                      <p className="text-[10px] font-black uppercase tracking-widest">{user.nickname}</p>
                      <p className="text-[9px] font-bold text-muted-foreground uppercase opacity-60">Gold Member</p>
                   </div>
                   <div className="w-8 h-8 lg:w-10 lg:h-10 rounded-full border-2 border-primary/20 bg-primary/10 overflow-hidden relative">
                      {user.profilePic ? <Image src={user.profilePic} alt="Avatar" fill className="object-cover" /> : <User className="h-4 w-4 lg:h-6 lg:w-6 m-auto absolute inset-0 text-primary" />}
                   </div>
                </div>
             </div>
          </header>

          {/* Performance Optimized Native Scroll Layer */}
          <div className="flex-1 overflow-y-auto no-scrollbar overscroll-contain will-change-transform">
            <div className="p-4 lg:p-10 space-y-8 lg:space-y-10 max-w-[1600px] mx-auto pb-32">
               
               <ProfileHero 
                 user={user} 
                 balance={displayBalance} 
                 currencySymbol={currencySymbol} 
                 onAvatarClick={() => fileInputRef.current?.click()}
                 onDeposit={onDeposit}
                 onWithdraw={handleWithdrawalRequest}
               />

               <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 lg:gap-8">
                  <section className="xl:col-span-8 space-y-6 lg:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                     <div className="bg-[#0F1116]/60 sm:backdrop-blur-2xl border border-white/5 rounded-[2rem] p-6 lg:p-10 shadow-2xl relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-10 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity">
                           <ShieldCheck className="h-32 lg:h-48 w-32 lg:w-48 text-primary" />
                        </div>

                        <div className="flex items-center justify-between mb-8 lg:mb-10 relative z-10">
                           <div>
                              <h3 className="text-lg lg:text-xl font-black uppercase tracking-tight">Institutional Profile</h3>
                              <p className="text-[9px] lg:text-[10px] text-muted-foreground uppercase font-bold tracking-widest opacity-60 mt-1">Verified Identity Node</p>
                           </div>
                           <div className="px-2 lg:px-3 py-1 lg:py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center gap-1.5 lg:gap-2">
                              <Check className="h-3 w-3 text-emerald-500" />
                              <span className="text-[8px] lg:text-[9px] font-black uppercase text-emerald-500 tracking-widest">Verified</span>
                           </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 relative z-10">
                           <ProfileField label="Trading Nickname" value={tempNickname} onChange={setTempNickname} placeholder="Enter nickname..." />
                           <ProfileField label="First Name" value={tempFirstName} onChange={setTempFirstName} locked={user.namesEdited} />
                           <ProfileField label="Last Name" value={tempLastName} onChange={setTempLastName} locked={user.namesEdited} />
                           <ProfileField label="Registered Email" value={user.email} locked />
                           <ProfileField label="Country / Address" value={tempAddress} onChange={setTempAddress} placeholder="Enter location..." />
                           
                           <div className="md:col-span-2 space-y-2">
                              <Label className="text-[9px] lg:text-[10px] uppercase font-black tracking-[0.2em] text-muted-foreground ml-1">Permanent UID Identifier</Label>
                              <div className="relative group">
                                 <Input 
                                   value={user.uid} 
                                   readOnly 
                                   className="h-12 lg:h-14 bg-white/[0.02] border-white/5 rounded-2xl font-mono text-[10px] lg:text-xs text-primary/60 tracking-wider pl-4 lg:pl-5 pr-12 lg:pr-14" 
                                 />
                                 <button 
                                   onClick={handleCopyUid}
                                   className="absolute right-3 lg:right-4 top-1/2 -translate-y-1/2 p-2 hover:bg-primary/10 rounded-xl transition-all text-muted-foreground hover:text-primary"
                                 >
                                    {hasCopied ? <Check className="h-3.5 w-3.5 lg:h-4 lg:w-4 text-emerald-500" /> : <Copy className="h-3.5 w-3.5 lg:h-4 lg:w-4" />}
                                 </button>
                              </div>
                           </div>
                        </div>

                        <div className="mt-10 lg:mt-12 flex flex-col sm:flex-row items-center gap-4 relative z-10">
                           <Button 
                             onClick={handleSaveChanges} 
                             disabled={isSaving}
                             className="w-full sm:w-auto px-10 lg:px-12 h-12 lg:h-14 bg-primary hover:bg-primary/90 text-white rounded-2xl font-black text-[10px] lg:text-[11px] uppercase tracking-[0.2em] shadow-xl shadow-primary/20"
                           >
                              {isSaving ? "Syncing..." : "Save Identity Changes"}
                           </Button>
                           <p className="text-[8px] lg:text-[9px] font-bold text-muted-foreground uppercase opacity-40 max-w-[280px] leading-relaxed text-center sm:text-left">
                              Identity changes are updated across all operational nodes instantly.
                           </p>
                        </div>
                     </div>

                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <ActionCard 
                          icon={<Headphones className="text-orange-400" />} 
                          title="Technical Desk" 
                          label="Open Ticket" 
                          onClick={() => setShowSupportModal(true)} 
                        />
                        <ActionCard 
                          icon={<History className="text-primary" />} 
                          title="Execution Log" 
                          label="Trade Audit" 
                          onClick={() => setProfileView('history')} 
                        />
                     </div>
                  </section>

                  <section className="xl:col-span-4">
                     <div className="bg-[#0F1116]/40 sm:backdrop-blur-2xl border border-white/5 rounded-[2rem] p-6 lg:p-8 h-full shadow-2xl flex flex-col">
                        <div className="flex items-center justify-between mb-8">
                           <h3 className="text-[10px] lg:text-[11px] font-black uppercase tracking-[0.2em] text-muted-foreground flex items-center gap-2">
                              <Activity className="h-3.5 w-3.5 text-primary" /> Audit Log
                           </h3>
                           <button className="text-[9px] lg:text-[10px] font-black text-primary hover:underline uppercase tracking-widest">View All</button>
                        </div>
                        
                        <ActivityTimeline />

                        <div className="mt-10 pt-8">
                           <div className="bg-primary/5 border border-primary/10 rounded-2xl p-5 space-y-4">
                              <div className="flex items-center gap-3">
                                 <ShieldCheck className="h-5 w-5 text-primary" />
                                 <h4 className="text-[10px] font-black uppercase tracking-widest">Protocol Intelligence</h4>
                              </div>
                              <p className="text-[9px] font-bold text-muted-foreground uppercase leading-relaxed opacity-70">
                                 Account activity is monitored by AI to ensure institutional-grade security.
                              </p>
                              <Button 
                                variant="outline" 
                                className="w-full h-10 bg-white/5 border-white/5 text-[9px] font-black uppercase tracking-widest hover:bg-white/10"
                                onClick={() => window.open('https://iextradeinfo.netlify.app/', '_blank')}
                              >
                                 Read Protocols
                              </Button>
                           </div>
                        </div>
                     </div>
                  </section>
               </div>

            </div>
          </div>
        </main>
      </div>

      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
      
      {showPayoutModal && <PayoutModal onClose={() => setShowPayoutModal(false)} onDeposit={() => { setShowPayoutModal(false); onDeposit?.(); }} />}
      {showSupportModal && <SupportModal onClose={() => setShowSupportModal(false)} />}
    </div>
  );
}

function NavButton({ icon, label, active, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-4 w-full p-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all group",
        active ? "bg-primary text-white shadow-xl shadow-primary/20" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
      )}
    >
      <div className={cn("transition-transform group-hover:scale-110", active && "text-white")}>
        {React.cloneElement(icon, { className: "h-4 w-4" })}
      </div>
      {label}
    </button>
  );
}

function ProfileField({ label, value, locked, onChange, placeholder }: any) {
  return (
    <div className="space-y-2 group">
      <div className="flex items-center justify-between px-1">
         <Label className="text-[9px] lg:text-[10px] uppercase font-black tracking-[0.2em] text-muted-foreground group-focus-within:text-primary transition-colors">
            {label}
         </Label>
         {locked && <Lock className="h-3 w-3 text-muted-foreground opacity-30" />}
      </div>
      <Input 
        value={value} 
        onChange={e => onChange?.(e.target.value)}
        readOnly={locked}
        disabled={locked}
        placeholder={placeholder}
        className={cn(
          "h-12 lg:h-14 rounded-2xl font-bold transition-all px-4 lg:px-5",
          locked 
            ? "bg-white/[0.01] border-white/5 opacity-40 cursor-not-allowed" 
            : "bg-white/[0.03] border-white/10 focus:border-primary focus:bg-white/[0.05] focus:ring-0"
        )}
      />
    </div>
  );
}

function ActionCard({ icon, title, label, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className="bg-[#0F1116]/60 sm:backdrop-blur-2xl border border-white/5 p-5 lg:p-6 rounded-[2rem] flex flex-col gap-4 text-left group hover:border-primary/30 transition-all hover:-translate-y-1 shadow-xl active:scale-95"
    >
      <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-white/5 flex items-center justify-center transition-all group-hover:bg-primary/20">
         {React.cloneElement(icon, { className: "h-4 w-4 lg:h-5 lg:w-5" })}
      </div>
      <div>
         <h4 className="text-[9px] lg:text-[10px] font-black uppercase tracking-widest text-muted-foreground opacity-60 mb-1">{title}</h4>
         <p className="text-[10px] lg:text-xs font-black uppercase tracking-widest flex items-center justify-between">
            {label} <ChevronRight className="h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-primary" />
         </p>
      </div>
    </button>
  );
}
