
"use client"

import React from 'react';
import { 
  LogIn, 
  Wallet, 
  ArrowDownToLine, 
  User, 
  TrendingUp, 
  ShieldCheck,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { cn } from '@/lib/utils';

const ACTIVITIES = [
  { id: 1, type: 'login', label: 'Terminal Handshake', desc: 'Secure session established from browser node', date: '2 mins ago', status: 'success' },
  { id: 2, type: 'deposit', label: 'Liquidity Injected', desc: 'Audit node confirmed $250.00 funding', date: '4 hours ago', status: 'success' },
  { id: 3, type: 'trade', label: 'Execution Audit', desc: 'SOLUSDT position closed: +$42.15', date: 'Yesterday', status: 'success' },
  { id: 4, type: 'profile', label: 'Identity Synchronized', desc: 'Nickname updated in distributed profile', date: '2 days ago', status: 'info' },
  { id: 5, type: 'withdraw', label: 'Payout Request', desc: 'Institutional review initiated for $1,200', date: '3 days ago', status: 'pending' },
];

export default function ActivityTimeline() {
  return (
    <div className="flex-1 relative">
       {/* Continuous Timeline Line */}
       <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-primary/50 via-white/5 to-transparent" />

       <div className="space-y-8 relative z-10">
          {ACTIVITIES.map((act) => (
             <div key={act.id} className="flex gap-6 group">
                <div className={cn(
                  "w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center border-4 border-[#07080B] shadow-2xl relative z-20 transition-all group-hover:scale-110",
                  act.status === 'success' ? "bg-emerald-500/20 text-emerald-500" : act.status === 'pending' ? "bg-amber-500/20 text-amber-500" : "bg-primary/20 text-primary"
                )}>
                   {getIcon(act.type)}
                </div>

                <div className="flex-1 pt-1 space-y-1">
                   <div className="flex items-center justify-between">
                      <h4 className="text-[11px] font-black uppercase tracking-widest text-foreground group-hover:text-primary transition-colors">{act.label}</h4>
                      <span className="text-[8px] font-black uppercase tracking-tighter text-muted-foreground opacity-40">{act.date}</span>
                   </div>
                   <p className="text-[10px] text-muted-foreground font-bold leading-relaxed opacity-60">{act.desc}</p>
                   {act.status === 'pending' && (
                     <div className="flex items-center gap-1.5 mt-2">
                        <Clock className="h-2.5 w-2.5 text-amber-500 animate-pulse" />
                        <span className="text-[7px] font-black uppercase text-amber-500 tracking-[0.2em]">Awaiting Desk Verification</span>
                     </div>
                   )}
                </div>
             </div>
          ))}
       </div>
    </div>
  );
}

function getIcon(type: string) {
  switch (type) {
    case 'login': return <LogIn className="h-5 w-5" />;
    case 'deposit': return <Wallet className="h-5 w-5" />;
    case 'withdraw': return <ArrowDownToLine className="h-5 w-5" />;
    case 'profile': return <User className="h-5 w-5" />;
    case 'trade': return <TrendingUp className="h-5 w-5" />;
    default: return <ShieldCheck className="h-5 w-5" />;
  }
}

