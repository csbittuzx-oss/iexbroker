"use client"

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import ProfileView from './ProfileView';

interface ProfileModalProps {
  onClose: () => void;
  onDeposit: () => void;
}

export default function ProfileModal({ onClose, onDeposit }: ProfileModalProps) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-full h-[100dvh] md:max-w-none md:h-screen md:w-screen md:left-0 md:top-0 md:translate-x-0 md:translate-y-0 md:rounded-none p-0 flex flex-col gap-0 border-none bg-[#07080B] overflow-hidden">
        <DialogHeader className="sr-only">
          <DialogTitle>Institutional Portfolio Terminal</DialogTitle>
          <DialogDescription>Advanced multi-node trading and account management dashboard.</DialogDescription>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden">
          <ProfileView onDeposit={onDeposit} onClose={onClose} />
        </div>
      </DialogContent>
    </Dialog>
  );
}
