"use client"

import React, { useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowLeftRight, Clock, CheckCircle2, Loader2, Hash, XCircle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';

interface TransactionHistoryViewProps {
  onBack: () => void;
}

const PAYMENT_METHODS = [
  { id: 'upi', name: 'UPI', icon: "https://i.ibb.co/wrjCHgYR/Picsart-26-05-10-23-39-52-299.png" },
  { id: 'usdt_bep20', name: 'USDT BEP20', icon: "https://i.ibb.co/wNpkHHW6/Picsart-26-05-10-23-24-23-354.png" },
  { id: 'usdt_trc20', name: 'USDT TRC20', icon: "https://i.ibb.co/GvBv51zg/Picsart-26-05-10-23-29-11-142.png" },
  { id: 'usdt_erc20', name: 'USDT ERC20', icon: "https://i.ibb.co/5h7q5nph/Picsart-26-05-10-23-25-09-803.png" },
  { id: 'usdt_polygon', name: 'USDT Polygon', icon: "https://i.ibb.co/QFXNnsZ1/Picsart-26-05-10-23-30-52-996.png" },
  { id: 'usdc_erc20', name: 'USDC ERC20', icon: "https://i.ibb.co/G3dNDBTt/Rendering-32-06-155.png" },
  { id: 'btc', name: 'Bitcoin', icon: "https://i.ibb.co/9H328k1V/Picsart-26-05-10-23-35-12-591.png" },
  { id: 'eth', name: 'Ethereum', icon: "https://i.ibb.co/jZ59hMHy/Picsart-26-05-10-23-36-02-512.png" },
  { id: 'bank', name: 'Bank Account', icon: "https://i.ibb.co/0RGn7FBD/Picsart-26-05-13-11-28-29-340.png" }
];

export default function TransactionHistoryView({ onBack }: TransactionHistoryViewProps) {
  const { user } = useStore();
  const db = useFirestore();

  const depositsQuery = useMemo(() => {
    if (!user?.email) return null;
    return query(
      collection(db, 'deposits'),
      where('userEmail', '==', user.email)
    );
  }, [user?.email, db]);

  const withdrawalsQuery = useMemo(() => {
    if (!user?.email) return null;
    return query(
      collection(db, 'withdrawals'),
      where('userEmail', '==', user.email)
    );
  }, [user?.email, db]);

  const { data: deposits, loading: depositsLoading } = useCollection(depositsQuery);
  const { data: withdrawals, loading: withdrawalsLoading } = useCollection(withdrawalsQuery);

  const allTransactions = useMemo(() => {
    const deps = (deposits || []).map(d => ({ ...d, type: 'deposit' as const }));
    const withs = (withdrawals || []).map(w => ({ ...w, type: 'withdrawal' as const }));
    
    return [...deps, ...withs].sort((a, b) => {
      return new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime();
    });
  }, [deposits, withdrawals]);

  const getMethodIcon = (methodName: string) => {
    return PAYMENT_METHODS.find(m => m.name === methodName)?.icon || PAYMENT_METHODS[1].icon;
  };

  const isLoading = depositsLoading || withdrawalsLoading;

  return (
    <div className="flex flex-col h-full animate-in slide-in-from-right duration-500 bg-[#0B0B0F]">
      <div className="flex items-center justify-between mb-4 lg:mb-6 pb-3 border-b border-white/5 px-4 lg:px-6 pt-4">
        <div className="flex items-center gap-3 lg:gap-4">
          <Button variant="ghost" size="sm" onClick={onBack} className="gap-1.5 lg:gap-2 font-black uppercase tracking-widest text-[8px] lg:text-[9px] h-8 hover:bg-white/5">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </Button>
          <div className="h-5 w-px bg-white/10" />
          <div className="flex items-center gap-2 text-primary">
            <ArrowLeftRight className="h-3.5 w-3.5 lg:h-4 lg:w-4" />
            <h3 className="text-[10px] lg:text-[11px] font-black uppercase tracking-[0.2em]">Transaction Log</h3>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
          <span className="text-[8px] font-black uppercase tracking-widest text-emerald-500">Live Audit Syncing</span>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="space-y-3 max-w-6xl mx-auto px-4 lg:px-6 pb-20">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-32 gap-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Synchronizing Records...</p>
            </div>
          ) : allTransactions.length > 0 ? (
            allTransactions.map((tx: any) => (
              <div 
                key={tx.id} 
                className="bg-[#14141A] border border-white/5 rounded-2xl p-4 hover:border-primary/40 hover:bg-white/[0.03] transition-all group"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center gap-4 min-w-[200px] lg:min-w-[240px]">
                    <div className="relative">
                      <div className="w-10 h-10 lg:w-12 lg:h-12 bg-white/5 rounded-2xl flex items-center justify-center p-2 lg:p-2.5">
                        <Image src={getMethodIcon(tx.method)} alt={tx.method} width={32} height={32} className="object-contain" />
                      </div>
                      <div className={cn(
                        "absolute -bottom-1 -right-1 w-4 h-4 lg:w-5 lg:h-5 rounded-full border-2 border-[#0B0B0F] flex items-center justify-center",
                        tx.status === 'approved' && "bg-emerald-500",
                        tx.status === 'pending' && "bg-amber-500",
                        tx.status === 'rejected' && "bg-rose-500"
                      )}>
                        {tx.status === 'approved' && <CheckCircle2 className="h-2.5 w-2.5 lg:h-3 lg:w-3 text-white" />}
                        {tx.status === 'pending' && <Loader2 className="h-2.5 w-2.5 lg:h-3 lg:w-3 text-white animate-spin" />}
                        {tx.status === 'rejected' && <XCircle className="h-2.5 w-2.5 lg:h-3 lg:w-3 text-white" />}
                      </div>
                    </div>
                    <div>
                      <h4 className="text-xs lg:text-sm font-black tracking-tight group-hover:text-primary transition-colors uppercase truncate max-w-[120px] lg:max-w-none">{tx.method}</h4>
                      <p className="text-[8px] lg:text-[10px] text-muted-foreground font-bold uppercase tracking-widest">{tx.type}</p>
                    </div>
                  </div>

                  <div className="flex-1 grid grid-cols-2 gap-2 lg:gap-4 border-t md:border-t-0 md:border-l border-dashed border-white/10 pt-4 md:pt-0 md:pl-4 lg:px-8">
                    <div className="flex flex-col justify-center">
                      <div className="flex items-center gap-1.5 lg:gap-2 mb-0.5">
                        <Hash className="h-2.5 w-2.5 lg:h-3 lg:w-3 text-muted-foreground opacity-50" />
                        <span className="text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground tracking-widest">Ref ID</span>
                      </div>
                      <span className="text-[9px] lg:text-[11px] font-mono font-bold text-foreground tracking-tight truncate max-w-[100px] lg:max-w-[120px]">{tx.txid || tx.id.substring(0,12).toUpperCase()}</span>
                    </div>
                    <div className="flex flex-col justify-center">
                      <div className="flex items-center gap-1.5 lg:gap-2 mb-0.5">
                        <Clock className="h-2.5 w-2.5 lg:h-3 lg:w-3 text-muted-foreground opacity-50" />
                        <span className="text-[7px] lg:text-[8px] font-black uppercase text-muted-foreground tracking-widest">Time</span>
                      </div>
                      <span className="text-[8px] lg:text-[9px] font-bold text-muted-foreground uppercase">
                        {new Date(tx.date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0 min-w-[100px] lg:min-w-[120px] border-t md:border-t-0 md:border-l pt-4 md:pt-0 md:pl-4 lg:pl-8 border-dashed border-white/10 flex md:flex-col items-center md:items-end justify-between md:justify-center">
                    <div className={cn(
                      "text-base lg:text-xl font-mono font-black",
                      tx.type === 'deposit' ? "text-emerald-400" : "text-rose-400"
                    )}>
                      {tx.type === 'deposit' ? '+' : '-'}${tx.amount.toLocaleString()}
                    </div>
                    <div className={cn(
                      "text-[8px] lg:text-[9px] font-black uppercase tracking-widest",
                      tx.status === 'approved' && "text-emerald-500",
                      tx.status === 'pending' && "text-amber-500",
                      tx.status === 'rejected' && "text-rose-500"
                    )}>
                      {tx.status}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-24 border-2 border-dashed rounded-[2rem] bg-white/[0.01] border-white/5">
              <div className="p-4 bg-white/5 rounded-full mb-4">
                <ArrowLeftRight className="h-8 w-8 text-muted-foreground/30" />
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">No Transactions Audited</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
