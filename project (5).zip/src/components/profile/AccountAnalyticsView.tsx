
"use client"

import React, { useMemo, useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { 
  ArrowLeft, 
  BarChart3, 
  TrendingUp, 
  Activity, 
  Target, 
  Zap, 
  PieChart,
  LineChart,
  Search,
  Layers,
  ChevronDown,
  CalendarDays,
  ShieldCheck,
  ZapIcon,
  Bell,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  Area, 
  AreaChart, 
  XAxis, 
  YAxis, 
  CartesianGrid,
  ResponsiveContainer,
  Pie,
  PieChart as RechartsPieChart,
  Cell,
  Tooltip
} from 'recharts';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';

interface AccountAnalyticsViewProps {
  onBack: () => void;
}

const COLORS = ['#35CB01', '#DB4635', '#3E42DF'];

export default function AccountAnalyticsView({ onBack }: AccountAnalyticsViewProps) {
  const { trades, user, currency, balance } = useStore();
  const [timeRange, setTimeRange] = useState<'weekly' | 'monthly'>('weekly');
  const [searchQuery, setSearchQuery] = useState('');
  const [chartMode, setChartFilter] = useState<'profit' | 'equity' | 'volume'>('profit');
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const metrics = useMemo(() => {
    const closedTrades = trades.filter(t => t.outcome !== 'pending');
    const total = closedTrades.length;
    const wins = closedTrades.filter(t => t.outcome === 'profit');
    const losses = closedTrades.filter(t => t.outcome === 'loss');
    
    const grossProfit = wins.reduce((acc, t) => acc + t.profitAmount, 0);
    const grossLoss = Math.abs(losses.reduce((acc, t) => acc + t.profitAmount, 0));
    const netProfit = grossProfit - grossLoss;
    
    const profitFactor = grossLoss === 0 ? (grossProfit > 0 ? 10 : 0) : (grossProfit / grossLoss);
    const winRate = total > 0 ? (wins.length / total) * 100 : 0;
    const avgTrade = total > 0 ? netProfit / total : 0;

    return {
      total,
      netProfit,
      winRate,
      profitFactor,
      avgTrade,
      distribution: [
        { name: 'Wins', value: wins.length },
        { name: 'Losses', value: losses.length },
        { name: 'Neutral', value: Math.max(0, total - (wins.length + losses.length)) }
      ]
    };
  }, [trades]);

  const chartData = useMemo(() => {
    const points = timeRange === 'weekly' ? 7 : 30;
    const now = new Date();
    const result = [];
    let cumulativeProfit = 0;

    for (let i = points - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];
      const dayLabel = points === 7 
        ? d.toLocaleDateString('en-US', { weekday: 'short' }) 
        : d.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });

      const dayTrades = trades.filter(t => t.date.startsWith(dayStr) && t.outcome !== 'pending');
      const dayProfit = dayTrades.reduce((acc, t) => acc + t.profitAmount, 0);
      const dayVolume = dayTrades.reduce((acc, t) => acc + t.tradeAmount, 0);
      
      cumulativeProfit += dayProfit;

      result.push({
        name: dayLabel,
        profit: Number(cumulativeProfit.toFixed(2)),
        equity: Number((1000 + cumulativeProfit).toFixed(2)),
        volume: dayVolume
      });
    }
    return result;
  }, [trades, timeRange]);

  const filteredTrades = trades
    .filter(t => t.pairName.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  if (!isMounted) return null;

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  return (
    <div className="flex flex-col h-full bg-[#07080B] text-foreground overflow-hidden relative font-body selection:bg-primary/30 w-full">
      {/* Decorative Orbs - Reduced animation complexity on mobile */}
      <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] bg-primary/10 rounded-full blur-[160px] pointer-events-none sm:animate-pulse" />
      
      {/* COMPACT STICKY HEADER */}
      <header className="sticky top-0 z-50 h-14 lg:h-20 shrink-0 border-b border-white/5 bg-[#07080B]/90 sm:backdrop-blur-3xl flex items-center justify-between px-[14px] lg:px-10 w-full">
        <div className="flex items-center gap-3 lg:gap-8 min-w-0">
          <Button 
            variant="ghost" 
            onClick={onBack} 
            className="h-9 px-2 lg:px-5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl flex items-center justify-center transition-all group shrink-0"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="hidden sm:inline ml-2 text-[10px] font-black uppercase tracking-[0.2em]">Exit</span>
          </Button>
          
          <div className="flex flex-col min-w-0">
            <h2 className="text-[11px] lg:text-2xl font-black uppercase tracking-tight truncate">Execution Analytics</h2>
          </div>
        </div>

        <div className="flex items-center gap-2 lg:gap-6 shrink-0">
           <button className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-all relative">
             <Bell className="h-4 w-4 text-muted-foreground" />
             <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-primary rounded-full" />
           </button>
           <div className="w-8 h-8 lg:w-11 lg:h-11 rounded-full border-2 border-primary/20 bg-primary/10 overflow-hidden relative shadow-2xl">
              {user?.profilePic ? (
                <Image src={user.profilePic} alt="Trader" fill className="object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-primary font-black uppercase text-[10px]">
                  {user?.nickname?.[0] || 'T'}
                </div>
              )}
           </div>
        </div>
      </header>

      {/* PERFORMANCE OPTIMIZED NATIVE SCROLL LAYER */}
      <div className="flex-1 overflow-y-auto no-scrollbar overscroll-contain will-change-transform">
        <div className="p-[14px] lg:p-10 space-y-6 lg:space-y-12 max-w-[1920px] mx-auto pb-[env(safe-area-inset-bottom)+100px] w-full">
          
          <div className="flex flex-col gap-6 w-full">
             <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-1">
                   <div className="flex items-center gap-2 text-primary">
                     <CalendarDays className="h-3.5 w-3.5" />
                     <span className="text-[9px] font-black uppercase tracking-widest opacity-50">Operational Period</span>
                   </div>
                   <h3 className="text-2xl lg:text-5xl font-black uppercase tracking-tighter leading-tight">Institutional Ledger</h3>
                </div>
                
                <Tabs value={timeRange} onValueChange={(v: any) => setTimeRange(v)} className="bg-white/5 p-1 rounded-2xl border border-white/5 w-full md:w-fit shrink-0">
                  <TabsList className="bg-transparent gap-1 h-10 lg:h-14 w-full md:w-auto">
                    <TabsTrigger value="weekly" className="flex-1 md:flex-none h-full px-6 lg:px-12 text-[10px] lg:text-[11px] font-black uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all">Weekly</TabsTrigger>
                    <TabsTrigger value="monthly" className="flex-1 md:flex-none h-full px-6 lg:px-12 text-[10px] lg:text-[11px] font-black uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white rounded-xl transition-all">Monthly</TabsTrigger>
                  </TabsList>
                </Tabs>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3 lg:gap-6 w-full">
                <StatCard 
                  label="Net Profit Matrix" 
                  value={`${currencySymbol}${metrics.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}`} 
                  trend={metrics.netProfit >= 0 ? '+12.4%' : '-3.1%'} 
                  type={metrics.netProfit >= 0 ? 'success' : 'danger'} 
                  icon={<TrendingUp />} 
                />
                <StatCard 
                  label="Available Equity" 
                  value={`${currencySymbol}${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`} 
                  trend="Operational" 
                  type="primary" 
                  icon={<Zap />} 
                />
                <StatCard label="Win Prob." value={`${metrics.winRate.toFixed(1)}%`} trend="Target" type="primary" icon={<Target />} />
                <StatCard label="Total Vol." value={metrics.total.toString()} trend="Active" type="info" icon={<Activity />} />
                <StatCard label="Risk Fact." value={metrics.profitFactor.toFixed(2)} trend="Audit" type="info" icon={<Layers />} />
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-12 gap-6 lg:gap-10 w-full overflow-hidden">
             
             {/* EQUITY GROWTH CURVE */}
             <div className="md:col-span-2 xl:col-span-8 bg-[#0F1116]/70 sm:backdrop-blur-3xl border border-white/5 rounded-[20px] lg:rounded-[3rem] p-5 lg:p-12 shadow-2xl overflow-hidden group w-full min-w-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-6">
                   <div className="flex items-center gap-4">
                      <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20 shadow-xl"><LineChart className="h-5 w-5 lg:h-6 lg:w-6" /></div>
                      <div>
                         <h4 className="text-xs lg:text-lg font-black uppercase tracking-widest">Equity Path</h4>
                      </div>
                   </div>
                   
                   <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/5 overflow-x-auto no-scrollbar">
                      {['profit', 'equity', 'volume'].map((mode) => (
                        <button 
                          key={mode}
                          onClick={() => setChartFilter(mode as any)}
                          className={cn(
                            "px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all whitespace-nowrap",
                            chartMode === mode ? "bg-primary text-white shadow-lg" : "text-muted-foreground hover:text-white"
                          )}
                        >
                          {mode}
                        </button>
                      ))}
                   </div>
                </div>

                <div className="h-[240px] lg:h-[450px] w-full min-w-0">
                   <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData} margin={{ top: 10, right: 0, left: -30, bottom: 0 }}>
                         <defs>
                            <linearGradient id="colorCurve" x1="0" y1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                               <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                            </linearGradient>
                         </defs>
                         <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="rgba(255,255,255,0.03)" />
                         <XAxis 
                           dataKey="name" 
                           axisLine={false} 
                           tickLine={false} 
                           tick={{ fontSize: 8, fontWeight: 900, fill: 'rgba(255,255,255,0.3)' }} 
                           interval={timeRange === 'monthly' ? 6 : 0}
                         />
                         <YAxis 
                           axisLine={false} 
                           tickLine={false} 
                           tick={{ fontSize: 8, fontWeight: 900, fill: 'rgba(255,255,255,0.3)' }} 
                         />
                         <Tooltip 
                            contentStyle={{ backgroundColor: '#14141A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '16px' }}
                            itemStyle={{ color: '#fff', fontSize: '10px', fontWeight: '900', textTransform: 'uppercase' }}
                         />
                         <Area 
                            type="monotone" 
                            dataKey={chartMode} 
                            stroke="hsl(var(--primary))" 
                            strokeWidth={3} 
                            fillOpacity={1} 
                            fill="url(#colorCurve)" 
                            isAnimationActive={false}
                         />
                      </AreaChart>
                   </ResponsiveContainer>
                </div>
             </div>

             {/* EXECUTION DELTA */}
             <div className="xl:col-span-4 w-full min-w-0">
                <div className="bg-[#0F1116]/70 sm:backdrop-blur-3xl border border-white/5 rounded-[20px] lg:rounded-[3rem] p-6 lg:p-12 h-full shadow-2xl flex flex-col items-center relative overflow-hidden group w-full">
                   <div className="flex items-center gap-4 mb-8 w-full relative z-10">
                      <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20 shadow-xl"><PieChart className="h-5 w-5 lg:h-6 lg:w-6" /></div>
                      <h4 className="text-xs lg:text-lg font-black uppercase tracking-widest">Execution Delta</h4>
                   </div>
                   
                   <div className="flex-1 flex flex-col items-center justify-center w-full relative z-10 min-w-0">
                      <div className="w-full aspect-square relative mx-auto max-w-[240px] lg:max-w-none">
                         <ResponsiveContainer width="100%" height="100%">
                            <RechartsPieChart>
                               <Pie
                                  data={metrics.distribution}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius="60%"
                                  outerRadius="80%"
                                  paddingAngle={8}
                                  dataKey="value"
                                  stroke="none"
                                  isAnimationActive={false}
                               >
                                  {metrics.distribution.map((entry, index) => (
                                     <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                  ))}
                                </Pie>
                            </RechartsPieChart>
                         </ResponsiveContainer>
                         <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span className="text-2xl lg:text-6xl font-mono font-black text-white tracking-tighter">{metrics.winRate.toFixed(0)}%</span>
                            <span className="text-[7px] lg:text-[11px] font-black uppercase text-muted-foreground tracking-[0.3em] mt-1">Accuracy</span>
                         </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mt-8 w-full">
                         {metrics.distribution.map((item, i) => (
                            <div key={item.name} className="text-center">
                               <div className="flex items-center justify-center gap-1.5 mb-1.5">
                                  <div className="w-1 h-1 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                                  <span className="text-[8px] lg:text-[10px] font-black uppercase tracking-widest opacity-40">{item.name}</span>
                               </div>
                               <p className="text-xs lg:text-2xl font-mono font-black">{item.value}</p>
                            </div>
                         ))}
                      </div>
                   </div>
                </div>
             </div>

             <div className="md:col-span-2 xl:col-span-12 bg-[#0F1116]/70 sm:backdrop-blur-3xl border border-white/5 rounded-[20px] lg:rounded-[4rem] shadow-2xl overflow-hidden flex flex-col w-full min-w-0">
                <div className="p-5 lg:p-14 border-b border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                   <div className="space-y-1">
                      <h4 className="text-xl lg:text-4xl font-black uppercase tracking-tighter">Audit Ledger</h4>
                   </div>
                   <div className="relative w-full sm:w-80 group">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground opacity-30" />
                      <Input 
                        placeholder="Search Identity..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-11 h-12 bg-white/5 border-white/10 rounded-xl text-xs font-black tracking-widest w-full" 
                      />
                   </div>
                </div>

                {/* DESKTOP TABLE */}
                <div className="hidden lg:block overflow-x-auto no-scrollbar w-full">
                   <table className="w-full min-w-[1000px]">
                      <thead>
                         <tr className="border-b border-white/5 bg-black/30">
                            <th className="px-10 py-6 text-left text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em]">Meta Node</th>
                            <th className="px-10 py-6 text-left text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em]">Asset</th>
                            <th className="px-10 py-6 text-center text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em]">Signal</th>
                            <th className="px-10 py-6 text-right text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em]">Principal</th>
                            <th className="px-10 py-6 text-right text-[10px] font-black uppercase text-muted-foreground tracking-[0.2em]">P&L Audit</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-white/[0.03]">
                         {filteredTrades.map((t) => (
                            <tr key={t.id} className="group hover:bg-white/[0.02] transition-all">
                               <td className="px-10 py-6 whitespace-nowrap">
                                  <p className="text-sm font-black uppercase tracking-tight">{new Date(t.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p>
                                  <p className="text-[9px] font-mono text-muted-foreground opacity-40 uppercase font-black">{new Date(t.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</p>
                               </td>
                               <td className="px-10 py-6 whitespace-nowrap">
                                  <span className="text-sm font-black uppercase tracking-tight">{t.pairName}</span>
                               </td>
                               <td className="px-10 py-6 text-center whitespace-nowrap">
                                  <Badge className={cn(
                                    "px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border",
                                    t.entryType === 'UP' ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-rose-500/10 text-rose-500 border-rose-500/20"
                                  )}>{t.entryType}</Badge>
                               </td>
                               <td className="px-10 py-6 text-right whitespace-nowrap font-mono font-black text-base">
                                  ${t.tradeAmount.toLocaleString()}
                               </td>
                               <td className="px-10 py-6 text-right whitespace-nowrap">
                                  <span className={cn("text-xl font-mono font-black tracking-tighter", t.outcome === 'profit' ? "text-emerald-400" : t.outcome === 'pending' ? "text-amber-500" : "text-rose-400")}>
                                     {t.outcome === 'pending' ? 'AUDITING' : `${t.outcome === 'profit' ? '+' : '-'}${Math.abs(t.profitAmount).toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
                                  </span>
                               </td>
                            </tr>
                         ))}
                      </tbody>
                   </table>
                </div>

                {/* MOBILE CARD SYSTEM */}
                <div className="lg:hidden p-4 space-y-3 w-full">
                   {filteredTrades.map((t) => (
                     <div key={t.id} className="bg-white/[0.03] border border-white/5 rounded-2xl p-4 space-y-4 shadow-2xl relative overflow-hidden group w-full">
                        <div className="flex items-center justify-between relative z-10">
                           <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-black text-xs border border-primary/20">{t.pairName[0]}</div>
                              <div>
                                 <p className="text-sm font-black uppercase tracking-tight">{t.pairName}</p>
                                 <p className="text-[8px] font-black uppercase text-muted-foreground opacity-50">{new Date(t.date).toLocaleDateString()} • {new Date(t.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</p>
                              </div>
                           </div>
                           <Badge className={cn(
                             "px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest border",
                             t.entryType === 'UP' ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-rose-500/10 text-rose-500 border-rose-500/20"
                           )}>{t.entryType}</Badge>
                        </div>

                        <div className="flex items-center justify-between border-t border-white/5 pt-4 relative z-10">
                           <div className="space-y-0.5">
                              <span className="text-[7px] font-black uppercase text-muted-foreground opacity-40">Principal</span>
                              <p className="text-sm font-mono font-black">${t.tradeAmount.toLocaleString()}</p>
                           </div>
                           <div className="text-right space-y-0.5">
                              <span className="text-[7px] font-black uppercase text-muted-foreground opacity-40">P&L Audit</span>
                              <p className={cn(
                                "text-base font-mono font-black tracking-tighter",
                                t.outcome === 'profit' ? "text-emerald-400" : t.outcome === 'pending' ? "text-amber-500" : "text-rose-400"
                              )}>
                                {t.outcome === 'pending' ? 'WAITING' : `${t.outcome === 'profit' ? '+' : '-'}${Math.abs(t.profitAmount).toFixed(2)}`}
                              </p>
                           </div>
                        </div>
                     </div>
                   ))}
                </div>
             </div>

             {/* INSTITUTIONAL EDGE NODE */}
             <div className="md:col-span-2 xl:col-span-12 bg-[#0F1116]/70 sm:backdrop-blur-3xl border border-white/5 rounded-[20px] lg:rounded-[3.5rem] p-6 lg:p-16 shadow-2xl relative overflow-hidden group w-full">
                <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none group-hover:scale-105 transition-transform"><ZapIcon className="h-48 lg:h-80 w-48 lg:w-80 text-amber-400" /></div>
                
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 lg:mb-16 gap-4 relative z-10 w-full">
                   <div className="flex items-center gap-4 lg:gap-5">
                      <div className="w-10 h-10 lg:w-14 lg:h-14 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20 shadow-2xl"><ZapIcon className="h-5 w-5 lg:h-7 lg:w-7" /></div>
                      <h4 className="text-base lg:text-3xl font-black uppercase tracking-tight">Institutional Edge</h4>
                   </div>
                   
                   <div className="bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl flex items-center gap-2 shadow-xl shadow-emerald-500/10 self-start">
                      <ShieldCheck className="h-3 w-3 lg:h-5 lg:w-5 text-emerald-400" />
                      <span className="text-[8px] lg:text-[11px] font-black uppercase text-emerald-400 tracking-[0.2em]">Operational Excellence</span>
                   </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24 relative z-10 w-full">
                   <div className="space-y-6 lg:space-y-10 w-full">
                      <div className="space-y-3">
                         <div className="flex justify-between items-center text-[9px] lg:text-[12px] uppercase font-black tracking-[0.3em]">
                           <span className="opacity-40">Risk Management</span>
                           <span className="text-emerald-400 font-mono text-sm lg:text-lg">9.2 / 10</span>
                         </div>
                         <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                           <div className="h-full bg-emerald-500 w-[92%]" />
                         </div>
                      </div>
                      <div className="space-y-3">
                         <div className="flex justify-between items-center text-[9px] lg:text-[12px] uppercase font-black tracking-[0.3em]">
                           <span className="opacity-40">Capital Preservation</span>
                           <span className="text-primary font-mono text-sm lg:text-lg">8.8 / 10</span>
                         </div>
                         <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                           <div className="h-full bg-primary w-[88%]" />
                         </div>
                      </div>
                   </div>

                   <div className="flex flex-col justify-center bg-white/[0.02] p-5 lg:p-12 rounded-2xl border border-white/5 shadow-2xl backdrop-blur-md w-full">
                      <p className="text-[9px] lg:text-base text-muted-foreground font-black uppercase leading-relaxed tracking-[0.1em] opacity-60">
                          AI DIAGNOSTIC: YOUR EXECUTION BIAS SHOWS HIGH-FREQUENCY ACCURACY WITH STRICT DRAW-DOWN CONTROLS. 
                          CAPITAL NODES ARE HIGHLY OPTIMIZED FOR THE CURRENT VOLATILITY REGIME. 
                      </p>
                   </div>
                </div>
             </div>

          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, trend, icon, type, className }: any) {
  return (
    <div className={cn(
      "bg-[#0F1116]/70 sm:backdrop-blur-3xl border border-white/5 rounded-[20px] lg:rounded-[2.5rem] p-5 lg:p-10 group hover:border-primary/40 transition-all shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[140px] lg:min-h-[220px] w-full", 
      className
    )}>
       <div className="absolute top-0 right-0 p-4 lg:p-10 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity pointer-events-none scale-150">
          {React.cloneElement(icon, { className: "h-16 w-16 lg:h-32 lg:w-32" })}
       </div>
       
       <div className="relative z-10 flex flex-col h-full justify-between w-full">
          <div className="flex items-center justify-between w-full">
             <div className={cn(
               "w-8 h-8 lg:w-14 lg:h-14 rounded-xl flex items-center justify-center transition-all group-hover:scale-110 shadow-xl",
               type === 'success' ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" : 
               type === 'danger' ? "bg-rose-500/10 text-rose-500 border border-rose-500/20" : 
               type === 'primary' ? "bg-primary/10 text-primary border border-primary/20" : "bg-white/5 text-muted-foreground border border-white/10"
             )}>
                {React.cloneElement(icon, { className: "h-4 w-4 lg:h-7 lg:w-7" })}
             </div>
             <span className={cn(
               "text-[7px] lg:text-[11px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full border shadow-sm",
               type === 'success' ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" : 
               type === 'danger' ? "bg-rose-500/10 text-rose-500 border border-rose-500/20" : 
               "bg-white/5 text-muted-foreground border border-white/10"
             )}>{trend}</span>
          </div>
          <div className="mt-4 lg:mt-8 w-full">
             <h4 className="text-[7px] lg:text-[12px] font-black uppercase tracking-[0.3em] text-muted-foreground opacity-30 mb-1 lg:mb-2">{label}</h4>
             <p className="font-mono font-black tracking-tighter truncate leading-tight w-full text-lg lg:text-5xl">
               {value}
             </p>
          </div>
       </div>
    </div>
  );
}
