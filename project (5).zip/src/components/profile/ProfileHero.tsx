"use client"

import React from 'react';
import { ShieldCheck, User, TrendingUp, Wallet, ArrowDownToLine, Zap, Globe, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { Button } from '@/components/ui/button';

export default function ProfileHero({ user, balance, currencySymbol, onAvatarClick, onDeposit, onWithdraw }: any) {
  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 lg:gap-10 items-stretch animate-in fade-in zoom-in-95 duration-700">
       
       {/* LEFT: IDENTITY MATRIX */}
       <div className="xl:col-span-5 bg-[#0F1116]/70 backdrop-blur-3xl border border-white/5 rounded-[2.5rem] lg:rounded-[3.5rem] p-8 lg:p-12 relative overflow-hidden group shadow-2xl">
          <div className="absolute top-0 right-0 p-10 opacity-[0.04] scale-125">
             <ShieldCheck className="h-32 w-32 text-primary" />
          </div>

          <div className="relative z-10 flex flex-col gap-8 lg:gap-12">
             <div className="flex flex-col sm:flex-row items-center sm:items-start gap-8 lg:gap-10">
                <div className="relative shrink-0">
                   <div className="w-28 h-28 lg:w-32 lg:h-32 rounded-full p-1.5 bg-gradient-to-br from-primary to-violet-600 shadow-2xl shadow-primary/30 relative overflow-hidden">
                      <div className="w-full h-full rounded-full bg-[#0F1116] flex items-center justify-center overflow-hidden relative">
                         {user.profilePic ? (
                           <Image src={user.profilePic} alt="Identity" fill className="object-cover" />
                         ) : (
                           <User className="h-12 w-12 text-primary/40" />
                         )}
                         <button 
                           onClick={onAvatarClick}
                           className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white"
                         >
                            <span className="text-[9px] font-black uppercase tracking-[0.2em]">Update Node</span>
                         </button>
                      </div>
                   </div>
                   <div className="absolute bottom-1 right-1 w-5 h-5 bg-emerald-500 rounded-full border-4 border-[#0F1116] shadow-2xl animate-pulse" />
                </div>

                <div className="flex-1 text-center sm:text-left space-y-3 lg:space-y-4">
                   <div>
                      <div className="flex items-center justify-center sm:justify-start gap-3 mb-2">
                         <h2 className="text-xl lg:text-3xl font-black uppercase tracking-tight leading-none">{user.nickname}</h2>
                         <span className="px-2.5 py-1 bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase rounded-lg shadow-sm">INSTITUTIONAL</span>
                      </div>
                      <p className="text-[9px] lg:text-[10px] font-mono font-black text-muted-foreground uppercase tracking-[0.3em] opacity-30">UID: {user.uid.substring(0, 16).toUpperCase()}</p>
                   </div>
                   
                   <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
                      <div className="px-3 py-1.5 bg-white/5 rounded-xl border border-white/5 flex items-center gap-2 shadow-sm">
                         <Globe className="h-3 w-3 text-muted-foreground" />
                         <span className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">{user.country || "GLOBAL NODE"}</span>
                      </div>
                      <div className="px-3 py-1.5 bg-emerald-500/10 rounded-xl border border-emerald-500/20 flex items-center gap-2 shadow-sm shadow-emerald-500/5">
                         <Zap className="h-3 w-3 text-emerald-500" />
                         <span className="text-[9px] font-black uppercase tracking-widest text-emerald-500">ACTIVE TRADER</span>
                      </div>
                   </div>
                </div>
             </div>

             {/* Primary Top Action Group */}
             <div className="grid grid-cols-2 gap-4 lg:gap-6">
                <Button 
                  onClick={onDeposit}
                  className="h-14 lg:h-18 bg-primary hover:bg-primary/90 text-white rounded-2xl lg:rounded-[1.5rem] font-black uppercase text-[11px] lg:text-[12px] tracking-[0.3em] shadow-2xl shadow-primary/30 transition-all active:scale-[0.98] border-none"
                >
                  <Plus className="h-4 w-4 lg:h-5 lg:w-5 mr-3" /> DEPOSIT
                </Button>
                <Button 
                  onClick={onWithdraw}
                  variant="outline"
                  className="h-14 lg:h-18 border-white/10 hover:bg-white/5 rounded-2xl lg:rounded-[1.5rem] font-black uppercase text-[11px] lg:text-[12px] tracking-[0.3em] transition-all active:scale-[0.98] backdrop-blur-xl"
                >
                  <ArrowDownToLine className="h-4 w-4 lg:h-5 lg:w-5 mr-3" /> WITHDRAW
                </Button>
             </div>
          </div>
       </div>

       {/* RIGHT: ACCOUNT STATS MATRIX */}
       <div className="xl:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-6">
          <StatCard 
            icon={<Wallet className="text-primary" />} 
            label="Institutional Balance" 
            value={`${currencySymbol}${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`} 
            trend="+12.4%" 
            chartColor="#3E42DF"
            isLarge
          />
          <StatCard 
            icon={<ArrowDownToLine className="text-accent" />} 
            label="Total Available Liquidity" 
            value={`${currencySymbol}${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`} 
            trend="100% RECOVERABLE" 
            chartColor="#8ED6F7"
          />
          <StatCard 
            icon={<ShieldCheck className="text-emerald-400" />} 
            label="Global Account Status" 
            value="OPERATIONAL" 
            trend="NETWORK ACTIVE" 
            chartColor="#35CB01"
            isStatus
          />
          <StatCard 
            icon={<TrendingUp className="text-rose-400" />} 
            label="Risk Management Protocol" 
            value="CONSERVATIVE" 
            trend="LOW DRAWDOWN" 
            chartColor="#DB4635"
            isStatus
          />
       </div>

    </div>
  );
}

function StatCard({ icon, label, value, trend, chartColor, isStatus, isLarge }: any) {
  return (
    <div className="bg-[#0F1116]/70 backdrop-blur-3xl border border-white/5 rounded-[2.5rem] p-8 lg:p-10 flex flex-col justify-between group hover:border-white/20 transition-all hover:bg-[#0F1116]/90 shadow-2xl overflow-hidden relative min-h-[180px]">
       {/* Micro Line Chart Decoration */}
       <div className="absolute bottom-0 left-0 right-0 h-16 opacity-[0.08] pointer-events-none group-hover:opacity-10 transition-opacity">
          <svg className="w-full h-full" viewBox="0 0 100 40" preserveAspectRatio="none">
             <path d="M0 40 C 15 35, 30 38, 45 20, 60 10, 75 25, 100 5 L 100 40 L 0 40 Z" fill={chartColor} />
          </svg>
       </div>

       <div className="space-y-6 relative z-10">
          <div className="flex items-center justify-between">
             <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center group-hover:scale-110 transition-all shadow-xl">
                {React.cloneElement(icon, { className: "h-6 w-6" })}
             </div>
             <span className={cn(
               "text-[9px] font-black uppercase px-3 py-1 rounded-full shadow-sm",
               isStatus ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" : "bg-primary/10 text-primary border border-primary/20"
             )}>
                {trend}
             </span>
          </div>
          <div>
             <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground opacity-30 mb-2">{label}</h4>
             <p className={cn(
               "font-mono font-black tracking-tighter leading-none truncate",
               isLarge ? "text-3xl lg:text-5xl" : "text-2xl lg:text-3xl"
             )}>
               {value}
             </p>
          </div>
       </div>
    </div>
  );
}
