"use client"

import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  ArrowLeft, 
  Copy, 
  Loader2, 
  ShieldCheck,
  Tag,
  Wallet,
  Zap,
  X,
  MessageCircle,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useStore } from '@/store/useStore';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { QRCodeSVG } from 'qrcode.react';
import { useFirestore } from '@/firebase';
import { collection, addDoc, serverTimestamp, query, where, getDocs } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

const PAYMENT_METHODS = [
  { 
    id: 'upi', 
    name: 'UPI', 
    icon: "https://i.ibb.co/wrjCHgYR/Picsart-26-05-10-23-39-52-299.png", 
    min: 30, 
    max: 1000, 
    addr: 'IEX UPI Bot',
    theme: 'bg-[#2D1B5D]',
    network: 'UPI',
    processingTime: 'Upto 48 Hrs'
  },
  { 
    id: 'usdt_bep20', 
    name: 'USDT (BEP-20)', 
    icon: "https://i.ibb.co/wNpkHHW6/Picsart-26-05-10-23-24-23-354.png", 
    min: 30, 
    max: 100000, 
    addr: '0xc86b483b1c7287dab76402a5231fb151efe30bb7',
    theme: 'bg-[#483B1A]',
    network: 'BEP-20',
    recommended: true,
    isFast: true
  },
  { 
    id: 'usdt_trc20', 
    name: 'USDT (TRC-20)', 
    icon: "https://i.ibb.co/GvBv51zg/Picsart-26-05-10-23-29-11-142.png", 
    min: 30, 
    max: 100000, 
    addr: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
    theme: 'bg-[#1A3D2F]',
    network: 'TRC-20'
  },
  { 
    id: 'usdt_erc20', 
    name: 'USDT (ERC-20)', 
    icon: "https://i.ibb.co/5h7q5nph/Picsart-26-05-10-23-25-09-803.png", 
    min: 30, 
    max: 100000, 
    addr: '0xdb794314cc152decc2127bcdcaf1f11b0b33aefc',
    theme: 'bg-[#1B214B]',
    network: 'ERC-20'
  },
  { 
    id: 'usdt_polygon', 
    name: 'USDT (Polygon)', 
    icon: "https://i.ibb.co/QFXNnsZ1/Picsart-26-05-10-23-30-52-996.png", 
    min: 30, 
    max: 100000, 
    addr: '0xdb794314cc152decc2127bcdcaf1f11b0b33aefc',
    theme: 'bg-[#2B1B5D]',
    network: 'POLYGON'
  },
  { 
    id: 'usdc_erc20', 
    name: 'USDC (ERC-20)', 
    icon: "https://i.ibb.co/G3dNDBTt/Picsart-26-05-10-23-32-06-155.png", 
    min: 30, 
    max: 100000, 
    addr: '0xe68136ddc28a259f7bd7125fc6c6f2882cab4edd',
    theme: 'bg-[#1A2E4B]',
    network: 'ERC-20'
  },
  { id: 'btc', name: 'Bitcoin', icon: "https://i.ibb.co/9H328k1V/Picsart-26-05-10-23-35-12-591.png", min: 50, max: 100000, addr: 'bc1qq34zx8xqp0sj20fdl9jnp45kp2vq8f3xsggd5x', theme: 'bg-[#3D2910]', network: 'BTC' },
  { id: 'eth', name: 'Ethereum', icon: "https://i.ibb.co/jZ59hMHy/Picsart-26-05-10-23-36-02-512.png", min: 50, max: 100000, addr: '0xe68136ddc28a259f7bd7125fc6c6f2882cab4edd', theme: 'bg-[#1F1F35]', network: 'ETH' }
];

export default function DepositWorkflow({ onClose, isMobilePage }: { onClose: () => void, isMobilePage: boolean }) {
  const [step, setStep] = useState(1);
  const [selectedMethod, setSelectedMethod] = useState<any>(null);
  const [amount, setAmount] = useState('100');
  const [promoOpen, setPromoOpen] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [isApplyingPromo, setIsApplyingPromo] = useState(false);
  const [txid, setTxid] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(1500);
  const [showUpiPopup, setShowUpiPopup] = useState(false);
  const { toast } = useToast();
  const { user, setHasDeposited } = useStore();
  const db = useFirestore();

  const filteredMethods = useMemo(() => {
    return PAYMENT_METHODS.filter(m => {
      if (m.id === 'upi') return user?.country === 'India';
      return true;
    });
  }, [user?.country]);

  useEffect(() => {
    if (step === 3) {
      const timer = setInterval(() => {
        setTimeLeft(prev => prev > 0 ? prev - 1 : 0);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [step]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleMethodSelect = (method: any) => {
    if (method.id === 'upi') {
      setShowUpiPopup(true);
      return;
    }
    setSelectedMethod(method);
    setStep(2);
  };

  const handleApplyPromo = async () => {
    if (!promoCode.trim()) return;
    setIsApplyingPromo(true);
    try {
      const q = query(collection(db, 'bonus_codes'), where('code', '==', promoCode.trim()), where('isActive', '==', true));
      const snap = await getDocs(q);
      
      if (snap.empty) {
        toast({ variant: "destructive", title: "Invalid Code", description: "This promotional code is invalid or expired." });
      } else {
        const promoDoc = snap.docs[0];
        const promoData = promoDoc.data();
        
        if (promoData.usedCount >= promoData.maxUses) {
          toast({ variant: "destructive", title: "Code Expired", description: "This code has reached its maximum usage limit." });
        } else {
          toast({ title: "Promo Applied", description: `Benefit synchronized with funding node.` });
        }
      }
    } catch (e) {
      toast({ variant: "destructive", title: "Sync Error", description: "Could not verify promotional node." });
    } finally {
      setIsApplyingPromo(false);
    }
  };

  const handleProceedToPay = () => {
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount < selectedMethod.min) {
      toast({ variant: "destructive", title: "Minimum Amount Required", description: `Enter minimum deposit amount: $${selectedMethod.min}.` });
      return;
    }
    setStep(3);
  };

  const handleVerify = () => {
    if (!txid.trim()) {
      toast({ variant: "destructive", title: "Action Required", description: "Please enter your Transaction ID or Reference ID." });
      return;
    }
    setIsVerifying(true);
    
    const depositData = {
      userEmail: user?.email || 'unknown@iex.io',
      amount: Number(amount),
      date: new Date().toISOString(),
      method: selectedMethod.name,
      txid: txid,
      status: 'pending',
      createdAt: serverTimestamp()
    };

    addDoc(collection(db, 'deposits'), depositData)
      .then(() => {
        setIsVerifying(false);
        setStep(4);
        setHasDeposited(true);
        setTimeout(() => {
          toast({ title: "Audit Synchronized", description: `Deposit of $${amount} is under technical review.` });
          onClose();
        }, 7000);
      })
      .catch(async (e) => {
        setIsVerifying(false);
        const permissionError = new FirestorePermissionError({
          path: 'deposits',
          operation: 'create',
          requestResourceData: depositData,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: `${label} Copied` });
  };

  return (
    <div className={cn("bg-background text-foreground relative", isMobilePage ? "min-h-screen pb-20" : "w-full")}>
      {showUpiPopup && (
        <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-[#14141A] border border-white/10 w-full max-w-[340px] rounded-[2rem] p-8 shadow-2xl relative animate-in zoom-in-95 duration-500">
            <button 
              onClick={() => setShowUpiPopup(false)}
              className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 rounded-full text-muted-foreground hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="flex flex-col items-center gap-6 text-center">
              <div className="w-20 h-20 bg-white/5 rounded-[2rem] flex items-center justify-center p-4 shadow-xl border border-white/5">
                <Image src="https://i.ibb.co/wrjCHgYR/Picsart-26-05-10-23-39-52-299.png" width={60} height={60} alt="UPI Bot" className="object-contain" />
              </div>
              
              <div className="space-y-3">
                <h4 className="text-base font-black uppercase tracking-tight text-white">Institutional UPI Node</h4>
                <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest leading-relaxed opacity-70">
                  For deposit by UPI, please proceed to Telegram and execute funding through our verified institutional deposit bot.
                </p>
              </div>

              <div className="w-full flex flex-col gap-3">
                <Button 
                  onClick={() => window.open('http://t.me/Iexupi_bot', '_blank')}
                  className="w-full h-14 bg-[#24A1DE] hover:bg-[#24A1DE]/90 rounded-2xl font-black uppercase text-[11px] tracking-widest gap-2 shadow-lg shadow-[#24A1DE]/20"
                >
                  <MessageCircle className="h-4 w-4" /> Open UPI Deposit Bot
                </Button>
                <Button 
                  variant="ghost" 
                  onClick={() => setShowUpiPopup(false)}
                  className="w-full h-10 text-[9px] font-black uppercase tracking-widest opacity-40 hover:opacity-100"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className={cn("p-5 sm:p-8 space-y-6", isMobilePage ? "pt-10" : "")}>
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="space-y-1">
              <div className="flex items-center gap-3 text-primary">
                <Wallet className="h-5 w-5" />
                <h3 className="text-sm font-black uppercase tracking-[0.2em]">Deposit Methods</h3>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {filteredMethods.map(m => (
                <button 
                  key={m.id}
                  onClick={() => handleMethodSelect(m)}
                  className={cn(
                    "relative overflow-hidden group flex flex-col p-6 rounded-[1.5rem] border border-white/10 transition-all active:scale-[0.98] h-[160px] text-left",
                    m.theme || "bg-[#14141A]"
                  )}
                >
                  {/* Circuit Background Pattern */}
                  <div className="absolute inset-0 opacity-10 pointer-events-none overflow-hidden">
                    <svg className="w-full h-full" viewBox="0 0 400 200">
                      <path d="M0 100 L50 100 L70 50 L120 50 L140 120 L200 120 L220 70 L300 70 L320 150 L400 150" stroke="white" strokeWidth="1" fill="none" />
                      <circle cx="70" cy="50" r="2" fill="white" />
                      <circle cx="140" cy="120" r="2" fill="white" />
                      <circle cx="320" cy="150" r="2" fill="white" />
                    </svg>
                  </div>

                  {/* Top Badges */}
                  <div className="absolute top-4 right-4 flex flex-col items-end gap-2">
                    {m.isFast && (
                      <div className="bg-[#7C3AED] text-white text-[8px] font-black uppercase px-2 py-1 rounded-full flex items-center gap-1 shadow-lg">
                        <Zap className="h-2.5 w-2.5" /> Fast deposit & withdrawal
                      </div>
                    )}
                    {m.network && (
                      <div className="border border-white/30 text-white/70 text-[9px] font-black uppercase px-2.5 py-1 rounded-lg">
                        {m.network}
                      </div>
                    )}
                  </div>

                  {/* Icon & Label */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div className="w-14 h-14 bg-black/20 rounded-2xl flex items-center justify-center p-3 backdrop-blur-md shadow-xl border border-white/5">
                      <Image src={m.icon} width={40} height={40} alt={m.name} className="object-contain" />
                    </div>
                    
                    <div className="space-y-1">
                      <h4 className="text-xl font-black text-white tracking-tight leading-none">{m.name}</h4>
                      <div className="flex items-center justify-between">
                        <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest">Min. ${m.min}</p>
                        {m.recommended && <span className="text-[9px] font-black text-amber-400 uppercase tracking-[0.1em]">RECOMMENDED</span>}
                        {m.processingTime && (
                          <div className="flex flex-col items-end">
                            <span className="text-[7px] font-black text-white/30 uppercase tracking-[0.2em] mb-0.5">Processing Time</span>
                            <span className="text-[9px] font-black bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/30">• {m.processingTime}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-8 animate-in slide-in-from-right duration-500">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setStep(1)} className="h-10 w-10 bg-white/5 rounded-xl">
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex-1 p-3.5 bg-[#14141A] border rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Image src={selectedMethod.icon} width={24} height={24} alt={selectedMethod.name} />
                  <span className="text-xs font-black uppercase tracking-widest">{selectedMethod.name}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setStep(1)} className="text-[9px] font-black uppercase text-primary tracking-widest hover:underline">Change</Button>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2 px-1">
                <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">Investment Amount</Label>
                <div className="relative group">
                  <span className="absolute left-6 top-1/2 -translate-y-1/2 text-muted-foreground font-mono text-3xl opacity-50">$</span>
                  <Input 
                    type="number" 
                    value={amount} 
                    onChange={(e) => setAmount(e.target.value)} 
                    className="h-20 text-4xl font-mono font-black bg-[#14141A] pl-14 rounded-3xl border-2 focus:border-primary transition-all text-center" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-3">
                {['100', '250', '500', '1000'].map(val => (
                  <Button 
                    key={val} 
                    variant="secondary"
                    onClick={() => setAmount(val)}
                    className={cn(
                      "h-12 font-black rounded-xl border border-transparent transition-all",
                      amount === val ? "bg-primary text-white shadow-lg shadow-primary/20 border-primary/50" : "bg-white/5 hover:bg-white/10"
                    )}
                  >
                    ${val}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <button 
                onClick={() => setPromoOpen(!promoOpen)}
                className="flex items-center gap-2 text-[10px] font-black text-primary uppercase tracking-widest hover:underline px-1"
              >
                <Tag className="h-3.5 w-3.5" />
                Apply Institutional Promo
              </button>
              {promoOpen && (
                <div className="flex gap-2">
                  <Input 
                    placeholder="Enter access code" 
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="h-12 bg-[#14141A] rounded-xl text-sm font-bold border-white/10" 
                  />
                  <Button 
                    variant="secondary" 
                    onClick={handleApplyPromo}
                    disabled={isApplyingPromo}
                    className="h-12 rounded-xl font-black uppercase text-[10px] px-4"
                  >
                    {isApplyingPromo ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Apply'}
                  </Button>
                </div>
              )}
            </div>

            <Button onClick={handleProceedToPay} className="w-full h-16 bg-primary hover:bg-primary/90 font-black text-base rounded-2xl shadow-2xl shadow-primary/20 uppercase tracking-widest">Generate Wallet</Button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-in slide-in-from-right duration-500">
            <div className="text-center space-y-2">
              <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-primary">Network Transfer Node</h3>
              <p className="text-[9px] text-muted-foreground uppercase font-bold tracking-widest">Execute transfer within allocated timeframe</p>
            </div>

            <div className="bg-[#14141A] border-2 border-white/5 rounded-[2.5rem] p-6 lg:p-8 flex flex-col items-center gap-8 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-[0.03]">
                 <ShieldCheck className="h-32 w-32" />
               </div>

               <div className="relative group p-6 bg-white rounded-[2rem] shadow-inner flex flex-col items-center gap-4 w-full">
                 <QRCodeSVG value={selectedMethod.addr} size={200} level="H" />
                 <div className="w-full space-y-2">
                    <p className="text-[8px] font-black uppercase text-black/40 text-center tracking-widest">Wallet Destination</p>
                    <div className="bg-black/5 p-3 rounded-xl border border-black/5 flex items-center justify-between gap-3">
                      <span className="text-[10px] font-mono font-bold text-black break-all flex-1 text-center">
                        {selectedMethod.addr}
                      </span>
                      <Button variant="ghost" size="icon" onClick={() => copyToClipboard(selectedMethod.addr, 'Address')} className="h-8 w-8 text-black hover:bg-black/10 shrink-0">
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                 </div>
               </div>

               <div className="w-full space-y-4 relative z-10">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 bg-background/50 rounded-2xl border border-white/5 flex flex-col items-center gap-1">
                       <span className="text-[8px] font-black uppercase text-muted-foreground">Asset</span>
                       <span className="text-xs font-black uppercase">{selectedMethod.name}</span>
                    </div>
                    <div className="p-4 bg-background/50 rounded-2xl border border-white/5 flex flex-col items-center gap-1">
                       <span className="text-[8px] font-black uppercase text-muted-foreground">Amount</span>
                       <span className="text-xs font-mono font-black text-accent">${amount}</span>
                    </div>
                  </div>
               </div>
            </div>

            <div className="flex flex-col items-center gap-2">
               <div className="flex items-center gap-3 text-primary animate-pulse">
                 <Loader2 className="h-4 w-4 animate-spin" />
                 <span className="text-[10px] font-black uppercase tracking-[0.2em]">Awaiting Liquidity</span>
               </div>
               <span className="text-3xl font-mono font-black text-accent tracking-tighter">{formatTime(timeLeft)}</span>
            </div>

            <div className="space-y-4 pt-4 border-t border-dashed border-white/10">
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest px-1">Transaction Identity (TXID)</Label>
                <input 
                  placeholder="Paste Reference Hash" 
                  value={txid}
                  onChange={(e) => setTxid(e.target.value)}
                  className="w-full h-14 bg-[#14141A] font-mono text-sm rounded-xl font-bold border border-white/10 focus:border-primary transition-all outline-none px-4" 
                />
              </div>
              <Button onClick={handleVerify} disabled={isVerifying} className="w-full h-16 bg-emerald-600 hover:bg-emerald-700 font-black text-base rounded-2xl shadow-2xl shadow-emerald-900/20 uppercase tracking-widest">
                {isVerifying ? <Loader2 className="h-6 w-6 animate-spin" /> : 'Confirm Transfer'}
              </Button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col items-center justify-center py-20 gap-10 text-center animate-in zoom-in-95 duration-700">
            <div className="relative">
              <div className="w-32 h-32 bg-primary/10 rounded-full animate-ping absolute inset-0" />
              <div className="w-32 h-32 bg-primary/20 rounded-full flex items-center justify-center border-4 border-primary/30 relative z-10 shadow-2xl">
                <Loader2 className="h-16 w-16 text-primary animate-spin" />
              </div>
            </div>
            <div className="space-y-4">
              <h4 className="text-3xl font-black uppercase tracking-tight">Audit in Progress</h4>
              <p className="text-xs text-muted-foreground px-12 font-bold uppercase leading-relaxed tracking-widest opacity-60">Your capital injection is being verified. Equity will update upon network confirmation.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
