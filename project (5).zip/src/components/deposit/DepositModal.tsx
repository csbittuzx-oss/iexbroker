"use client"

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import DepositWorkflow from './DepositWorkflow';

export default function DepositModal({ onClose }: { onClose: () => void }) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="p-0 overflow-hidden bg-card border shadow-2xl transition-all duration-300 sm:max-w-[420px] w-[95vw] mx-auto flex flex-col">
        <DialogHeader className="sr-only">
          <DialogTitle>Deposit Balance</DialogTitle>
          <DialogDescription>Deposit funds into your account.</DialogDescription>
        </DialogHeader>
        <div className="max-h-[85vh] overflow-y-auto no-scrollbar flex-1">
          <DepositWorkflow onClose={onClose} isMobilePage={false} />
        </div>
      </DialogContent>
    </Dialog>
  );
}
