"use client"

import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import DepositWorkflow from './DepositWorkflow';
import Image from 'next/image';

export default function DepositView({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-background flex flex-col animate-in slide-in-from-right duration-300">
      <header className="h-11 border-b bg-card flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h2 className="text-[11px] font-bold uppercase tracking-widest">Deposit</h2>
        </div>
        <Image 
          src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" 
          alt="Logo" 
          width={80} 
          height={24} 
          className="h-5 w-auto object-contain"
        />
      </header>
      
      <main className="flex-1 overflow-y-auto no-scrollbar">
        <DepositWorkflow onClose={onClose} isMobilePage={true} />
      </main>
    </div>
  );
}
