
"use client"

import React, { useEffect, useState, useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { 
  Trophy, 
  TrendingUp, 
  TrendingDown, 
  User as UserIcon,
  Medal,
  Globe,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useFirestore } from '@/firebase';
import { 
  collection, 
  query, 
  orderBy, 
  limit, 
  onSnapshot, 
  doc, 
  setDoc, 
  getDocs
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

interface LeaderboardItem {
  id: string;
  name: string;
  country: string;
  profit: number;
  rank: number;
  isUser?: boolean;
}

const BOT_NAMES = [
  { name: "Alex Trader", country: "United Kingdom" },
  { name: "CryptoWhale", country: "India" },
  { name: "Elena_V", country: "Russia" },
  { name: "MarcoPolo", country: "Italy" },
  { name: "X-Trading", country: "Germany" },
  { name: "Satoshi_N", country: "Japan" },
  { name: "CoinMaster", country: "Brazil" },
  { name: "BullRun_88", country: "China" },
  { name: "DeepBlue", country: "Spain" },
  { name: "ZenTrader", country: "Vietnam" },
  { name: "Alpha_One", country: "USA" },
  { name: "SwiftTrade", country: "Canada" },
  { name: "NordicBull", country: "Norway" },
  { name: "DesertFox", country: "UAE" },
  { name: "Oceanic", country: "Australia" },
  { name: "PeakProfit", country: "Switzerland" },
  { name: "LionsShare", country: "Singapore" },
  { name: "MapleLeaf", country: "Canada" },
  { name: "GoldDigger", country: "South Africa" },
  { name: "SilkRoad", country: "Turkey" }
];

export default function LeaderboardView() {
  const { user, trades } = useStore();
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const db = useFirestore();

  const userProfit = useMemo(() => {
    return trades.reduce((acc, t) => acc + t.profitAmount, 0);
  }, [trades]);

  useEffect(() => {
    const seedBots = async () => {
      const q = query(collection(db, 'leaderboard'), limit(1));
      try {
        const snapshot = await getDocs(q);
        
        if (snapshot.empty) {
          const minBotProfit = 5934.00;
          const maxBotProfit = 42453.00;
          
          BOT_NAMES.forEach((bot, index) => {
            const profit = maxBotProfit - (index * ((maxBotProfit - minBotProfit) / BOT_NAMES.length));
            const botId = `bot_${index}`;
            const botData = {
              name: bot.name,
              country: bot.country,
              profit: Number(profit.toFixed(2)),
              isBot: true,
              updatedAt: new Date().toISOString()
            };
            
            const docRef = doc(db, 'leaderboard', botId);
            setDoc(docRef, botData)
              .catch(async () => {
                const permissionError = new FirestorePermissionError({
                  path: docRef.path,
                  operation: 'write',
                  requestResourceData: botData,
                } satisfies SecurityRuleContext);
                errorEmitter.emit('permission-error', permissionError);
              });
          });
        }
      } catch (e) {
        const permissionError = new FirestorePermissionError({
          path: 'leaderboard',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      }
    };
    seedBots();
  }, [db]);

  useEffect(() => {
    if (!user) return;

    const updateUserProfit = async () => {
      const userRef = doc(db, 'leaderboard', user.uid);
      const userData = {
        name: user.nickname || `${user.firstName} ${user.lastName}`,
        country: user.country,
        profit: Number(userProfit.toFixed(2)),
        isBot: false,
        updatedAt: new Date().toISOString()
      };

      setDoc(userRef, userData, { merge: true })
        .catch(async () => {
          const permissionError = new FirestorePermissionError({
            path: userRef.path,
            operation: 'write',
            requestResourceData: userData,
          } satisfies SecurityRuleContext);
          errorEmitter.emit('permission-error', permissionError);
        });
    };

    updateUserProfit();
  }, [user, userProfit, db]);

  useEffect(() => {
    const q = query(
      collection(db, 'leaderboard'), 
      orderBy('profit', 'desc'), 
      limit(20)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: LeaderboardItem[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        items.push({
          id: doc.id,
          name: data.name,
          country: data.country,
          profit: data.profit,
          rank: items.length + 1,
          isUser: user ? doc.id === user.uid : false
        } as LeaderboardItem);
      });
      setLeaderboard(items);
      setIsLoading(false);
    }, async (serverError) => {
      const permissionError = new FirestorePermissionError({
        path: 'leaderboard',
        operation: 'list',
      } satisfies SecurityRuleContext);
      errorEmitter.emit('permission-error', permissionError);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user, db]);

  const currentUserData = leaderboard.find(item => item.isUser);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Syncing Rankings...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {currentUserData && (
        <div className="relative overflow-hidden bg-primary/10 border-2 border-primary/20 rounded-2xl p-5 shadow-xl shadow-primary/5">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Trophy className="h-20 w-20" />
          </div>
          
          <div className="relative z-10 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/30">
                  <UserIcon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-black uppercase tracking-tight">{currentUserData.name}</h3>
                  <div className="flex items-center gap-1.5 opacity-60">
                    <Globe className="h-3 w-3" />
                    <span className="text-[10px] font-bold uppercase">{currentUserData.country}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[9px] font-black uppercase text-primary tracking-widest block mb-0.5">Global Rank</span>
                <span className="text-2xl font-black italic">#{currentUserData.rank}</span>
              </div>
            </div>

            <div className="h-px bg-primary/20 w-full" />

            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-widest opacity-70">Total Profit Audit</span>
              <div className={cn(
                "flex items-center gap-1.5 text-lg font-black font-mono",
                userProfit >= 0 ? "text-emerald-400" : "text-rose-400"
              )}>
                {userProfit >= 0 ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
                {userProfit >= 0 ? '+' : ''}${Math.abs(userProfit).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-black uppercase tracking-[0.2em] text-muted-foreground">Global Top 20</h2>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest">Live Network</span>
          </div>
        </div>

        <div className="space-y-2.5">
          {leaderboard.map((item) => (
            <div 
              key={item.id} 
              className={cn(
                "group flex items-center gap-4 p-3.5 border transition-all duration-300 rounded-2xl",
                item.isUser 
                  ? "bg-primary/20 border-primary/50 shadow-lg shadow-primary/10" 
                  : "bg-secondary/10 border-transparent hover:border-primary/30 hover:bg-secondary/20"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm relative shrink-0 transition-transform group-hover:scale-105",
                item.rank === 1 && "bg-gradient-to-br from-yellow-400 to-orange-500 text-white shadow-lg shadow-orange-500/20",
                item.rank === 2 && "bg-gradient-to-br from-slate-300 to-slate-500 text-white shadow-lg shadow-slate-500/20",
                item.rank === 3 && "bg-gradient-to-br from-amber-600 to-amber-800 text-white shadow-lg shadow-amber-800/20",
                item.rank > 3 && "bg-secondary/40 text-muted-foreground"
              )}>
                {item.rank <= 3 && <Medal className="absolute -top-1.5 -left-1.5 h-4 w-4 drop-shadow-md" />}
                {item.rank}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold truncate group-hover:text-primary transition-colors">
                    {item.name} {item.isUser && "(You)"}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[9px] text-muted-foreground uppercase font-bold tracking-tight">
                  <Globe className="h-2.5 w-2.5" />
                  {item.country}
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className={cn(
                  "flex items-center gap-1 justify-end font-mono font-black text-sm",
                  item.profit >= 0 ? "text-emerald-400" : "text-rose-400"
                )}>
                  {item.profit >= 0 ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
                  ${Math.abs(item.profit).toLocaleString()}
                </div>
                <p className="text-[8px] font-black text-muted-foreground uppercase tracking-tighter">Total Profit</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
