"use client"

import React from 'react';
import { X } from 'lucide-react';
import LeaderboardView from './LeaderboardView';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function LeaderboardPanel({ onClose }: { onClose: () => void }) {
  return (
    <div className="flex flex-col h-full bg-card">
      <div className="p-4 border-b flex items-center justify-between shrink-0">
        <h3 className="font-bold uppercase tracking-widest text-sm">Ranks</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <ScrollArea className="flex-1 p-4">
        <LeaderboardView />
      </ScrollArea>
    </div>
  );
}