
"use client"

import React, { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { 
  TrendingUp, 
  User, 
  Plus,
  ArrowUp,
  ArrowDown,
  History,
  Minus
} from 'lucide-react';
import TradingChart from '@/components/trading/TradingChart';
import ProfileView from '@/components/profile/ProfileView';
import SupportView from '@/components/support/SupportView';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import DepositView from '@/components/deposit/DepositView';
import PayoutView from '@/components/payout/PayoutView';
import AssetSelector, { getSynchronizedPayout } from '@/components/trading/AssetSelector';
import DurationSelector from '@/components/trading/DurationSelector';
import HistoryPopup from '@/components/trading/HistoryPopup';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { doc, updateDoc, increment } from 'firebase/firestore';
import { useFirestore } from '@/firebase';

const USD_TO_INR = 83.42;

export default function MobileLayout() {
  const { 
    balance, 
    currency, 
    tradeAmount, 
    setTradeAmount, 
    payoutPercent, 
    setPayoutPercent,
    addTrade, 
    activePair, 
    activeDuration, 
    setBalance, 
    profileView,
    activeTab,
    setActiveTab,
    user
  } = useStore();
  
  const db = useFirestore();
  const [showDeposit, setShowDeposit] = useState(false);
  const [showPayout, setShowPayout] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [mounted, setMounted] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const update = () => {
      const syncVal = getSynchronizedPayout(activePair);
      if (payoutPercent !== syncVal) {
        setPayoutPercent(syncVal);
      }
    };
    update();
    const interval = setInterval(update, 10000);
    return () => clearInterval(interval);
  }, [activePair, payoutPercent, setPayoutPercent]);

  const parseDurationSeconds = (d: string) => {
    const parts = d.split(':').map(Number);
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return parts[0] * 60;
  };

  const handleTrade = (type: 'UP' | 'DOWN') => {
    if (tradeAmount > balance) {
      toast({
        variant: "destructive",
        title: "Balance Alert",
        description: "Insufficient capital for this order.",
      });
      return;
    }
    
    setIsProcessing(true);
    
    setTimeout(() => {
      setIsProcessing(false);
      const durationSec = parseDurationSeconds(activeDuration);
      const entryDate = new Date();
      const expiryDate = new Date(entryDate.getTime() + durationSec * 1000);
      const currentPrice = (window as any).lastPrice || 2500;

      addTrade({
        id: Math.random().toString(36).substring(2, 10).toUpperCase(),
        pairName: activePair,
        openingPrice: currentPrice,
        closingPrice: 0,
        tradeAmount,
        profitAmount: 0,
        outcome: 'pending',
        duration: activeDuration,
        date: entryDate.toISOString(),
        expiryDate: expiryDate.toISOString(),
        entryType: type
      });

      setBalance(prev => prev - tradeAmount);
      if (user?.uid) {
        updateDoc(doc(db, 'users', user.uid), { balance: increment(-tradeAmount) })
          .catch(e => console.error("Mobile order sync failed", e));
      }

      const { dismiss } = toast({
        title: "Order Placed",
        description: "Mobile terminal synced.",
      });
      setTimeout(dismiss, 1000);
    }, 50);
  };

  const returnAmount = tradeAmount * (1 + payoutPercent / 100);
  const displayBalance = currency === 'INR' ? balance * USD_TO_INR : balance;
  const currencySymbol = currency === 'INR' ? '₹' : '$';
  const showHeader = activeTab !== 'profile';

  return (
    <div className="flex flex-col h-[100dvh] bg-background overflow-hidden">
      {showHeader && (
        <header className="h-11 border-b bg-card flex items-center justify-between px-4 shrink-0">
          <div className="flex items-center gap-3">
            <Image src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" alt="Logo" width={70} height={20} className="h-4 w-auto object-contain" priority />
            <div className="flex flex-col border-l border-white/10 pl-3">
              <span className="text-[13px] font-mono font-black leading-none tracking-tight">
                {mounted ? `${currencySymbol}${displayBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '$0.00'}
              </span>
            </div>
          </div>
          <Button size="sm" onClick={() => setShowDeposit(true)} className="h-7 rounded-full bg-primary hover:bg-primary/90 gap-1 px-3 shadow-lg shadow-primary/20 text-[10px] font-bold uppercase tracking-tight">
            <Plus className="h-3 w-3" />
            <span>Deposit</span>
          </Button>
        </header>
      )}

      <main className="flex-1 relative overflow-hidden flex flex-col">
        {activeTab === 'trade' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 relative"><TradingChart /></div>
            <div className="bg-card border-t p-2 space-y-2 shrink-0 pb-1.5">
              <div className="flex items-center justify-center"><AssetSelector variant="minimal" /></div>
              <div className="flex gap-2">
                <div className="flex-1 relative border rounded-lg h-11 flex items-center justify-center group focus-within:border-primary transition-colors bg-secondary/5">
                  <span className="absolute -top-1.5 left-2 bg-card px-1 text-[7px] font-black text-muted-foreground uppercase tracking-widest">Time</span>
                  <DurationSelector variant="minimal" />
                </div>
                <div className="flex-1 relative border rounded-lg h-11 flex items-center px-1.5 focus-within:border-primary transition-colors bg-secondary/5">
                  <span className="absolute -top-1.5 left-2 bg-card px-1 text-[7px] font-black text-muted-foreground uppercase tracking-widest">Investment</span>
                  <div className="flex items-center w-full gap-1">
                    <button onClick={() => setTradeAmount(Math.max(1, tradeAmount - 1))} className="p-0.5 bg-secondary/30 rounded-full text-muted-foreground hover:text-white shrink-0"><Minus className="h-2.5 w-2.5" /></button>
                    <Input type="number" value={tradeAmount} onChange={(e) => setTradeAmount(Number(e.target.value))} className="flex-1 h-7 bg-transparent border-none text-center font-mono font-bold text-sm focus-visible:ring-0 p-0" />
                    <button onClick={() => setTradeAmount(tradeAmount + 1)} className="p-0.5 bg-secondary/30 rounded-full text-muted-foreground hover:text-white shrink-0"><Plus className="h-2.5 w-2.5" /></button>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 px-1">
                <span className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest whitespace-nowrap">Return</span>
                <div className="flex-1 border-b border-dashed border-muted-foreground/20 mb-1"></div>
                <span className="font-mono font-black text-sm tracking-tight text-[#35CB01]">
                  {(mounted ? returnAmount : 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} $
                </span>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => handleTrade('UP')} disabled={isProcessing} className="flex-1 h-11 bg-[#35CB01] hover:bg-[#35CB01]/90 rounded-xl flex items-center justify-between px-4 font-bold text-lg shadow-lg shadow-[#35CB01]/20 border-none">
                  <span className="tracking-tight uppercase font-black text-[10px]">Up</span>
                  <div className="w-7 h-7 bg-white/20 rounded-lg flex items-center justify-center"><ArrowUp className="h-4 w-4" /></div>
                </Button>
                <Button onClick={() => handleTrade('DOWN')} disabled={isProcessing} className="flex-1 h-11 bg-[#DB4635] hover:bg-[#DB4635]/90 rounded-xl flex items-center justify-between px-4 font-bold text-lg shadow-lg shadow-[#DB4635]/20 border-none">
                  <span className="tracking-tight uppercase font-black text-[10px]">Down</span>
                  <div className="w-7 h-7 bg-white/20 rounded-lg flex items-center justify-center"><ArrowDown className="h-4 w-4" /></div>
                </Button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'profile' && <div className="h-full overflow-hidden bg-background no-scrollbar"><ProfileView onDeposit={() => setShowDeposit(true)} onWithdraw={() => setShowPayout(true)} /></div>}
        {activeTab === 'support' && <div className="p-4 h-full overflow-y-auto bg-background no-scrollbar"><SupportView /></div>}
      </main>

      <nav className="h-12 border-t bg-card flex items-center justify-around px-2 shrink-0">
        <NavButton active={activeTab === 'trade'} onClick={() => setActiveTab('trade')} icon={<TrendingUp className="h-4 w-4" />} label="Trade" />
        <NavButton active={false} onClick={() => setShowHistory(true)} icon={<History className="h-4 w-4" />} label="History" />
        <NavButton active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} icon={<User className="h-4 w-4" />} label="Profile" />
      </nav>

      {showDeposit && <DepositView onClose={() => setShowDeposit(false)} />}
      {showPayout && <PayoutView onClose={() => setShowPayout(false)} onDeposit={() => { setShowPayout(false); setShowDeposit(true); }} />}
      
      <Sheet open={showHistory} onOpenChange={setShowHistory}>
        <SheetContent side="bottom" className="p-0 bg-transparent border-none h-[80vh] focus:outline-none overflow-hidden rounded-t-[2rem] [&>button]:hidden">
          <SheetTitle className="sr-only">Trade History</SheetTitle>
          <SheetDescription className="sr-only">View your running and closed trades</SheetDescription>
          <HistoryPopup onClose={() => setShowHistory(false)} />
        </SheetContent>
      </Sheet>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button onClick={onClick} className={cn("flex flex-col items-center justify-center gap-0.5 w-16 h-full transition-all", active ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
      <div className={cn("transition-transform", active && "scale-110")}>{icon}</div>
      <span className="text-[8px] font-bold uppercase tracking-widest">{label}</span>
    </button>
  );
}
