
"use client"

import React from 'react';
import TopBar from './TopBar';
import Sidebar from '@/components/trading/TradeSidebar';
import TradingChart from '@/components/trading/TradingChart';

export default function DesktopLayout() {
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-background">
      <TopBar />
      <div className="flex flex-1 overflow-hidden relative">
        <main className="flex-1 overflow-hidden flex flex-col">
          <div className="flex-1 bg-background relative chart-container">
            <TradingChart />
          </div>
        </main>
        
        <aside className="w-[260px] border-l bg-card flex flex-col overflow-hidden">
          <Sidebar />
        </aside>
      </div>
    </div>
  );
}
