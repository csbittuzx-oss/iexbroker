
"use client"

import React, { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { 
  User, 
  Wallet
} from 'lucide-react';
import ProfileModal from '@/components/profile/ProfileModal';
import DepositModal from '@/components/deposit/DepositModal';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import Image from 'next/image';

const USD_TO_INR = 83.42;

export default function TopBar() {
  const { balance, currency, setProfileView } = useStore();
  const [showProfile, setShowProfile] = useState(false);
  const [showDeposit, setShowDeposit] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleOpenProfile = (view: 'menu' | 'history' | 'transactions' | 'analytics' = 'menu') => {
    setProfileView(view);
    setShowProfile(true);
  };

  const handleOpenDepositFromProfile = () => {
    setShowProfile(false);
    setShowDeposit(true);
  };

  const displayBalance = currency === 'INR' ? balance * USD_TO_INR : balance;
  const currencySymbol = currency === 'INR' ? '₹' : '$';

  return (
    <header className="h-12 border-b bg-card flex items-center justify-between px-4 z-50 shrink-0">
      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2">
          <Image 
            src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" 
            alt="Platform Logo" 
            width={90} 
            height={30} 
            className="h-6 w-auto object-contain"
            priority
          />
        </div>

        <nav className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => handleOpenProfile('menu')}
                  className="rounded-full hover:bg-secondary h-8 w-8"
                >
                  <User className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Profile</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </nav>
      </div>

      <div className="flex items-center space-x-3">
        <div className="hidden md:flex items-center space-x-2 bg-secondary/50 px-3 py-1 rounded-lg border h-9">
          <Wallet className="h-4 w-4 text-accent" />
          <span className="font-mono text-sm font-black tracking-tight">
            {mounted ? `${currencySymbol}${displayBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '$0.00'}
          </span>
        </div>

        <Button 
          onClick={() => setShowDeposit(true)}
          size="sm"
          className="bg-primary hover:bg-primary/90 text-white font-bold h-9 text-[11px] px-5 shadow-lg shadow-primary/10"
        >
          Deposit
        </Button>
      </div>

      {showProfile && (
        <ProfileModal 
          onClose={() => setShowProfile(false)} 
          onDeposit={handleOpenDepositFromProfile} 
        />
      )}
      {showDeposit && <DepositModal onClose={() => setShowDeposit(false)} />}
    </header>
  );
}
