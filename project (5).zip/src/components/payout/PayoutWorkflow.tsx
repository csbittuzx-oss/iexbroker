"use client"

import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useStore } from '@/store/useStore';
import { useToast } from '@/hooks/use-toast';
import { 
  Loader2, 
  ArrowLeft, 
  Wallet, 
  ShieldCheck, 
  Lock, 
  CheckCircle2,
  Clock,
  AlertCircle,
  Zap
} from 'lucide-react';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { useFirestore } from '@/firebase';
import { collection, addDoc, serverTimestamp, query, where, getDocs, updateDoc, doc, increment, limit } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

const WITHDRAW_METHODS = [
  { 
    id: 'bank', 
    name: 'Bank Account', 
    icon: "https://i.ibb.co/0RGn7FBD/Picsart-26-05-13-11-28-29-340.png", 
    min: 50, 
    max: 100000,
    theme: 'bg-[#2D2D2D]',
    network: 'INSTITUTIONAL'
  },
  { 
    id: 'upi', 
    name: 'UPI', 
    icon: "https://i.ibb.co/wrjCHgYR/Picsart-26-05-10-23-39-52-299.png", 
    min: 100, 
    max: 1000,
    theme: 'bg-[#2D1B5D]',
    network: 'UPI'
  },
  { 
    id: 'usdt_bep20', 
    name: 'USDT (BEP-20)', 
    icon: "https://i.ibb.co/wNpkHHW6/Picsart-26-05-10-23-24-23-354.png", 
    min: 50, 
    max: 200000,
    theme: 'bg-[#483B1A]',
    network: 'BEP-20',
    recommended: true,
    isFast: true
  },
  { 
    id: 'usdt_trc20', 
    name: 'USDT (TRC-20)', 
    icon: "https://i.ibb.co/GvBv51zg/Picsart-26-05-10-23-29-11-142.png", 
    min: 50, 
    max: 200000,
    theme: 'bg-[#1A3D2F]',
    network: 'TRC-20'
  },
  { 
    id: 'usdt_erc20', 
    name: 'USDT (ERC-20)', 
    icon: "https://i.ibb.co/5h7q5nph/Picsart-26-05-10-23-25-09-803.png", 
    min: 50, 
    max: 200000,
    theme: 'bg-[#1B214B]',
    network: 'ERC-20'
  },
  { 
    id: 'usdt_polygon', 
    name: 'USDT (Polygon)', 
    icon: "https://i.ibb.co/QFXNnsZ1/Picsart-26-05-10-23-30-52-996.png", 
    min: 50, 
    max: 200000,
    theme: 'bg-[#2B1B5D]',
    network: 'POLYGON'
  },
  { 
    id: 'usdc_erc20', 
    name: 'USDC (ERC-20)', 
    icon: "https://i.ibb.co/G3dNDBTt/Picsart-26-05-10-23-32-06-155.png", 
    min: 50, 
    max: 200000,
    theme: 'bg-[#1A2E4B]',
    network: 'ERC-20'
  },
  { id: 'btc', name: 'Bitcoin', icon: "https://i.ibb.co/9H328k1V/Picsart-26-05-10-23-35-12-591.png", min: 50, max: 200000, theme: 'bg-[#3D2910]', network: 'BTC' },
  { id: 'eth', name: 'Ethereum', icon: "https://i.ibb.co/jZ59hMHy/Picsart-26-05-10-23-36-02-512.png", min: 50, max: 200000, theme: 'bg-[#1F1F35]', network: 'ETH' }
];

export default function PayoutWorkflow({ onClose, onDeposit, isMobilePage }: { onClose: () => void, onDeposit: () => void, isMobilePage: boolean }) {
  const { 
    user, 
    balance,
    wrongPinAttempts, 
    withdrawalBlockUntil, 
    incrementPinAttempts, 
    resetPinAttempts, 
    blockWithdrawal
  } = useStore();
  
  const [step, setStep] = useState(1);
  const [amount, setAmount] = useState('50');
  const [selectedMethod, setSelectedMethod] = useState<any>(null);
  const [address, setAddress] = useState('');
  
  const [upiName, setUpiName] = useState('');
  const [upiPhone, setUpiPhone] = useState('');
  const [bankName, setBankName] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [confirmAccountNumber, setConfirmAccountNumber] = useState('');

  const [pin, setPin] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  
  const { toast } = useToast();
  const db = useFirestore();

  const isBlocked = withdrawalBlockUntil && Date.now() < withdrawalBlockUntil;
  const remainingBlockTime = withdrawalBlockUntil ? Math.ceil((withdrawalBlockUntil - Date.now()) / 60000) : 0;

  const filteredMethods = useMemo(() => {
    return WITHDRAW_METHODS.filter(m => {
      if (m.id === 'upi' || m.id === 'bank') return user?.country === 'India';
      return true;
    });
  }, [user?.country]);

  useEffect(() => {
    if (!user?.email) return;

    const performAuditCheck = async () => {
      try {
        const depQuery = query(
          collection(db, 'deposits'),
          where('userEmail', '==', user.email),
          limit(1)
        );
        const depSnap = await getDocs(depQuery);
        
        if (depSnap.empty) {
          setStep(0); 
          return;
        }

        const withQuery = query(
          collection(db, 'withdrawals'), 
          where('userEmail', '==', user.email),
          where('status', '==', 'pending'),
          limit(1)
        );
        const withSnap = await getDocs(withQuery);
        
        if (!withSnap.empty) {
          setStep(6); 
        } else {
          setStep(1); 
        }
      } catch (e) {
        console.error("Institutional audit node failure:", e);
      } finally {
        setIsInitialLoading(false);
      }
    };

    performAuditCheck();
  }, [user?.email, db]);

  const handleProceedToMethod = () => {
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount < 50) {
      toast({ variant: "destructive", title: "Minimum withdrawal is $50" });
      return;
    }
    if (numAmount > balance) {
      toast({ variant: "destructive", title: "Insufficient Balance" });
      return;
    }
    setStep(2);
  };

  const handleMethodSelect = (method: any) => {
    const numAmount = Number(amount);
    if (numAmount < method.min) {
      toast({ variant: "destructive", title: `Minimum for ${method.name} is $${method.min}` });
      return;
    }
    if (numAmount > method.max) {
      toast({ variant: "destructive", title: `Maximum for ${method.name} is $${method.max}` });
      return;
    }
    setSelectedMethod(method);
    setStep(3);
  };

  const handleConfirmPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isBlocked || isProcessing) return;

    if (pin !== user?.withdrawalPin) {
      incrementPinAttempts();
      const newAttempts = wrongPinAttempts + 1;
      
      if (newAttempts >= 10) {
        const blockUntil = Date.now() + 2 * 60 * 60 * 1000;
        blockWithdrawal(blockUntil);
        toast({ variant: "destructive", title: "Account Locked" });
      } else {
        toast({ variant: "destructive", title: "Incorrect PIN" });
      }
      return;
    }

    setIsProcessing(true);

    let finalAddress = address;
    if (selectedMethod.id === 'bank') {
      finalAddress = `Bank: ${bankName} | Holder: ${upiName} | A/C: ${accountNumber} | IFSC: ${ifscCode} | Phone: ${upiPhone}`;
    } else if (selectedMethod.id === 'upi') {
      finalAddress = `UPI ID: ${address} | Holder: ${upiName} | Phone: ${upiPhone}`;
    }
    
    const withdrawalData = {
      userEmail: user?.email || 'unknown@iex.io',
      amount: Number(amount),
      date: new Date().toISOString(),
      method: selectedMethod.name,
      address: finalAddress,
      status: 'pending',
      createdAt: serverTimestamp()
    };

    try {
      await addDoc(collection(db, 'withdrawals'), withdrawalData);
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, { balance: increment(-Number(amount)) });
      resetPinAttempts();
      setIsProcessing(false);
      setStep(5);
      setTimeout(() => onClose(), 7000);
    } catch (e: any) {
      setIsProcessing(false);
      toast({ variant: "destructive", title: "Sync Failure" });
    }
  };

  if (isInitialLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Synchronizing Audit...</p>
      </div>
    );
  }

  return (
    <div className={cn("p-6 space-y-6", isMobilePage ? "pb-12" : "")}>
      {step === 0 && (
        <div className="py-12 text-center space-y-6 animate-in fade-in zoom-in-95 duration-300">
          <div className="w-20 h-20 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto text-rose-500">
            <Lock className="h-10 w-10" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-black uppercase tracking-tight">Withdrawal Locked</h3>
            <p className="text-xs text-muted-foreground leading-relaxed uppercase font-bold px-4">
              You must make your first deposit to unlock withdrawal features.
            </p>
          </div>
          <Button onClick={onDeposit} className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl font-black text-base uppercase">
            Deposit to Unlock
          </Button>
        </div>
      )}

      {step === 6 && (
        <div className="py-12 text-center space-y-6 animate-in fade-in zoom-in-95 duration-300">
          <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto text-amber-500">
            <Clock className="h-10 w-10 animate-pulse" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-black uppercase tracking-tight">Audit in Progress</h3>
            <p className="text-xs text-muted-foreground leading-relaxed uppercase font-bold px-6">
              You already have a pending withdrawal request. Please wait for resolution.
            </p>
          </div>
          <Button onClick={onClose} variant="secondary" className="w-full h-14 rounded-2xl font-black text-base uppercase">
            Close Terminal
          </Button>
        </div>
      )}

      {step === 1 && (
        <div className="space-y-6 animate-in slide-in-from-right duration-300">
          <div className="relative h-48 rounded-[2.5rem] bg-[#14141A] border border-white/10 p-7 text-white shadow-2xl flex flex-col justify-between overflow-hidden group">
            <div className="absolute top-0 right-0 w-40 h-40 bg-primary/10 rounded-full blur-[80px] -mr-10 -mt-10 transition-all group-hover:bg-primary/20" />
            
            <div className="flex justify-between items-start z-10">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-black">Capital Node</p>
                </div>
                <h4 className="text-4xl font-mono font-black tracking-tighter">${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</h4>
              </div>
              <div className="bg-white/5 p-2 rounded-xl border border-white/5">
                <Image src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" alt="Logo" width={70} height={22} className="h-4 w-auto brightness-125" />
              </div>
            </div>

            <div className="flex justify-between items-end z-10 pt-4">
              <div className="space-y-1">
                <p className="text-[8px] text-muted-foreground uppercase tracking-widest font-bold opacity-50">Authorized Holder</p>
                <p className="text-[11px] font-black uppercase tracking-widest">{user?.nickname || 'Institutional Trader'}</p>
              </div>
              <div className="text-right">
                <p className="text-[8px] text-muted-foreground uppercase tracking-widest font-bold opacity-50 mb-1">Network ID</p>
                <div className="px-3 py-1.5 bg-black/40 rounded-lg border border-white/5">
                  <p className="text-[10px] font-mono tracking-widest text-primary font-bold">
                    {user?.uid?.substring(0, 8).toUpperCase()}...{user?.uid?.substring(user.uid.length - 4).toUpperCase()}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <Label className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">Withdrawal Amount</Label>
            <div className="relative">
              <span className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-foreground font-mono text-2xl">$</span>
              <Input 
                type="number" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)} 
                className="h-16 text-3xl font-mono font-black bg-secondary/10 pl-11 rounded-2xl border-2 focus:border-primary transition-all" 
              />
            </div>
          </div>

          <Button onClick={handleProceedToMethod} className="w-full h-14 bg-primary rounded-2xl font-black text-base shadow-lg shadow-primary/20 uppercase tracking-widest">Select Method</Button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6 animate-in slide-in-from-right duration-300">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => setStep(1)} className="h-8 w-8">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h3 className="text-sm font-black uppercase tracking-widest">Select Method</h3>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {filteredMethods.map(m => (
              <button 
                key={m.id}
                onClick={() => handleMethodSelect(m)}
                className={cn(
                  "relative overflow-hidden group flex flex-col p-6 rounded-[1.5rem] border border-white/10 transition-all active:scale-[0.98] h-[160px] text-left",
                  m.theme || "bg-[#14141A]"
                )}
              >
                {/* Circuit Pattern */}
                <div className="absolute inset-0 opacity-10 pointer-events-none overflow-hidden">
                  <svg className="w-full h-full" viewBox="0 0 400 200">
                    <path d="M0 100 L50 100 L70 50 L120 50 L140 120 L200 120 L220 70 L300 70 L320 150 L400 150" stroke="white" strokeWidth="1" fill="none" />
                  </svg>
                </div>

                <div className="absolute top-4 right-4 flex flex-col items-end gap-2">
                  {m.isFast && (
                    <div className="bg-[#7C3AED] text-white text-[8px] font-black uppercase px-2 py-1 rounded-full flex items-center gap-1">
                      <Zap className="h-2.5 w-2.5" /> Fast withdrawal
                    </div>
                  )}
                  {m.network && (
                    <div className="border border-white/30 text-white/70 text-[9px] font-black uppercase px-2.5 py-1 rounded-lg">
                      {m.network}
                    </div>
                  )}
                </div>

                <div className="flex-1 flex flex-col justify-between">
                  <div className="w-14 h-14 bg-black/20 rounded-2xl flex items-center justify-center p-3 backdrop-blur-md shadow-xl border border-white/5">
                    <Image src={m.icon} width={40} height={40} alt={m.name} className="object-contain" />
                  </div>
                  
                  <div className="space-y-1">
                    <h4 className="text-xl font-black text-white tracking-tight leading-none">{m.name}</h4>
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest">Min. ${m.min}</p>
                      {m.recommended && <span className="text-[9px] font-black text-amber-400 uppercase tracking-[0.1em]">RECOMMENDED</span>}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6 animate-in slide-in-from-right duration-300">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => setStep(2)} className="h-8 w-8">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex-1 p-3 bg-secondary/20 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image src={selectedMethod.icon} width={20} height={20} alt={selectedMethod.name} />
                <span className="text-[10px] font-black uppercase">{selectedMethod.name}</span>
              </div>
              <span className="text-[11px] font-mono font-bold text-primary">${amount}</span>
            </div>
          </div>

          <div className="space-y-4">
            {selectedMethod.id === 'bank' ? (
              <div className="space-y-3">
                <Input value={upiName} onChange={e => setUpiName(e.target.value)} placeholder="Account Holder Name" className="h-11 bg-secondary/10" />
                <Input value={bankName} onChange={e => setBankName(e.target.value)} placeholder="Bank Name" className="h-11 bg-secondary/10" />
                <div className="grid grid-cols-2 gap-3">
                  <Input value={ifscCode} onChange={e => setIfscCode(e.target.value.toUpperCase())} placeholder="IFSC Code" className="h-11 bg-secondary/10" />
                  <Input value={upiPhone} onChange={e => setUpiPhone(e.target.value)} placeholder="Phone Number" className="h-11 bg-secondary/10" />
                </div>
                <Input type="password" value={accountNumber} onChange={e => setAccountNumber(e.target.value)} placeholder="Account Number" className="h-11 bg-secondary/10" />
                <Input value={confirmAccountNumber} onChange={e => setConfirmAccountNumber(e.target.value)} placeholder="Confirm Account Number" className="h-11 bg-secondary/10" />
              </div>
            ) : selectedMethod.id === 'upi' ? (
              <>
                <Input value={upiName} onChange={e => setUpiName(e.target.value)} placeholder="Holder Name" className="h-12 bg-secondary/10" />
                <Input value={address} onChange={e => setAddress(e.target.value)} placeholder="user@upi" className="h-12 bg-secondary/10" />
                <Input value={upiPhone} onChange={e => setUpiPhone(e.target.value)} placeholder="Phone Number" className="h-12 bg-secondary/10" />
              </>
            ) : (
              <Input value={address} onChange={e => setAddress(e.target.value)} placeholder="Wallet Address" className="h-12 bg-secondary/10 font-mono" />
            )}
          </div>

          <Button onClick={() => setStep(4)} className="w-full h-14 bg-primary rounded-2xl font-black uppercase tracking-widest">Confirm Details</Button>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-6 animate-in zoom-in-95 duration-300">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto text-primary mb-4">
              <ShieldCheck className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-black uppercase tracking-tight">Security Check</h3>
            <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Enter 6-digit withdrawal PIN</p>
          </div>

          <form onSubmit={handleConfirmPin} className="space-y-6">
            <Input 
              type="password" 
              maxLength={6} 
              value={pin} 
              onChange={e => setPin(e.target.value)}
              placeholder="••••••" 
              className="h-16 text-center text-3xl tracking-[0.5em] font-black bg-secondary/10 rounded-2xl border-2"
            />
            <Button type="submit" disabled={pin.length < 6 || isProcessing || isBlocked} className="w-full h-14 bg-emerald-600 hover:bg-emerald-700 rounded-2xl font-black uppercase">
              {isProcessing ? <Loader2 className="h-6 w-6 animate-spin" /> : 'Confirm Payout'}
            </Button>
          </form>
        </div>
      )}

      {step === 5 && (
        <div className="text-center space-y-8 animate-in zoom-in-95 duration-500 py-10">
          <div className="relative mx-auto w-32 h-32">
            <div className="absolute inset-0 bg-emerald-500/10 rounded-full animate-ping" />
            <div className="relative z-10 w-32 h-32 bg-emerald-500/20 rounded-full flex items-center justify-center border-4 border-emerald-500/30">
              <CheckCircle2 className="h-16 w-16 text-emerald-400" />
            </div>
          </div>
          <h3 className="text-2xl font-black uppercase tracking-tight text-emerald-400">Processing</h3>
          <p className="text-[10px] text-muted-foreground uppercase font-medium px-4">Our financial department is verifying your request.</p>
        </div>
      )}
    </div>
  );
}
