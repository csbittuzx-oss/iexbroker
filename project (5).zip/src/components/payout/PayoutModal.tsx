"use client"

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import PayoutWorkflow from './PayoutWorkflow';

export default function PayoutModal({ onClose, onDeposit }: { onClose: () => void, onDeposit: () => void }) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-[420px] w-[95vw] p-0 overflow-hidden bg-card border shadow-2xl rounded-3xl">
        <DialogHeader className="sr-only">
          <DialogTitle>Payout Request</DialogTitle>
          <DialogDescription>Process your withdrawal request.</DialogDescription>
        </DialogHeader>
        <div className="max-h-[85vh] overflow-y-auto no-scrollbar">
          <PayoutWorkflow onClose={onClose} onDeposit={onDeposit} isMobilePage={false} />
        </div>
      </DialogContent>
    </Dialog>
  );
}
