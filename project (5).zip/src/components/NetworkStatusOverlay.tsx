
"use client"

import React, { useState, useEffect } from 'react';
import { WifiOff, Loader2 } from 'lucide-react';
import { useStore } from '@/store/useStore';

/**
 * Global Network Status Overlay.
 * Monitors browser connectivity and displays a high-priority 
 * reconnection notice when the internet handshake is lost.
 */
export default function NetworkStatusOverlay() {
  const [isOffline, setIsOffline] = useState(false);
  const setIsOnlineStore = useStore(state => state.setIsOnline);

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      setIsOnlineStore(true);
    };
    const handleOffline = () => {
      setIsOffline(true);
      setIsOnlineStore(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check on mount
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      setIsOffline(true);
      setIsOnlineStore(false);
    } else {
      setIsOnlineStore(true);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setIsOnlineStore]);

  if (!isOffline) return null;

  return (
    <div className="fixed inset-0 z-[10000] bg-[#0B0B0F]/90 backdrop-blur-md flex flex-col items-center justify-center animate-in fade-in duration-300">
      <div className="flex flex-col items-center gap-6 p-10 bg-[#14141A] border border-white/5 rounded-[2.5rem] shadow-2xl max-w-[320px] w-full text-center">
        <div className="w-20 h-20 bg-rose-500/10 rounded-full flex items-center justify-center text-rose-500 mb-2">
          <WifiOff className="h-10 w-10" />
        </div>
        
        <div className="space-y-2">
          <h3 className="text-xl font-black uppercase tracking-tight text-white">No Connection</h3>
          <p className="text-[11px] text-muted-foreground uppercase font-bold tracking-widest leading-relaxed opacity-60">
            Institutional link interrupted. Please check your internet settings.
          </p>
        </div>

        <div className="flex items-center gap-3 text-primary pt-4">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em] animate-pulse">Trying to reconnect...</span>
        </div>
      </div>
    </div>
  );
}
