'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';

/**
 * Centrally listens for specialized Firebase errors and throws them
 * to be caught by the Next.js dev overlay.
 */
export function FirebaseErrorListener() {
  useEffect(() => {
    const unsubscribe = errorEmitter.on('permission-error', (error) => {
      // Re-throw the error so it hits the global error boundary/overlay
      // This provides the rich JSON context needed for debugging security rules
      throw error;
    });
    return unsubscribe;
  }, []);

  return null;
}
