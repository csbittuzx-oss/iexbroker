"use client"

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import SupportView from './SupportView';
import { MessageSquare } from 'lucide-react';

interface SupportModalProps {
  onClose: () => void;
}

export default function SupportModal({ onClose }: SupportModalProps) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-[500px] w-[95vw] p-0 overflow-hidden bg-[#0F0F14] border-white/5 shadow-2xl rounded-3xl">
        <DialogHeader className="p-6 border-b border-white/5 bg-[#14141A] flex-row items-center gap-4 space-y-0">
          <div className="p-2 bg-primary/10 rounded-lg">
            <MessageSquare className="h-5 w-5 text-primary" />
          </div>
          <DialogTitle className="text-sm font-black uppercase tracking-[0.2em]">Contact Support</DialogTitle>
          <DialogDescription className="sr-only">
            Professional technical desk for operational assistance.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[80vh] overflow-y-auto no-scrollbar">
          <SupportView />
        </div>
      </DialogContent>
    </Dialog>
  );
}
