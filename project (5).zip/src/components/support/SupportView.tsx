
"use client"

import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Send, 
  Clock, 
  AlertCircle, 
  Loader2, 
  History,
  Plus,
  ArrowLeft,
  MessageSquare,
  ShieldCheck
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useFirestore } from '@/firebase';
import { collection, addDoc, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

export default function SupportView() {
  const { user } = useStore();
  const db = useFirestore();
  const [tickets, setTickets] = useState<any[]>([]);
  const [view, setView] = useState<'list' | 'create'>('list');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (!user?.email || !db) return;
    
    // Use client-side sorting if index isn't ready, but status is critical
    const q = query(
      collection(db, 'supportTickets'), 
      where('email', '==', user.email)
    );
    
    const unsub = onSnapshot(q, 
      (snap) => {
        const list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        // Sort newest first
        list.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setTickets(list);
      },
      async (serverError) => {
        const permissionError = new FirestorePermissionError({
          path: 'supportTickets',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      }
    );
    return unsub;
  }, [user?.email, db]);

  const activeTicket = useMemo(() => {
    return tickets.find(t => t.status === 'pending');
  }, [tickets]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (activeTicket) {
      toast({
        variant: "destructive",
        title: "Active Request Pending",
        description: "Institutional protocol allows only one active ticket. Please wait for the current audit to resolve."
      });
      return;
    }

    if (!message.trim()) return;

    setIsLoading(true);
    
    const data = {
      email: user?.email || 'unknown@iex.io',
      message: message.trim(),
      status: 'pending',
      date: new Date().toISOString()
    };

    addDoc(collection(db, 'supportTickets'), data)
      .then(() => {
        toast({
          title: "Audit Synchronized",
          description: `Technical desk has received your request. Estimated review: 5-15 mins.`,
        });
        setView('list');
        setMessage('');
      })
      .catch(async (error) => {
        const permissionError = new FirestorePermissionError({
          path: 'supportTickets',
          operation: 'create',
          requestResourceData: data,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <div className="p-6 space-y-6 bg-[#0F0F14]">
      {view === 'list' ? (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="flex items-center justify-between">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Technical Audit Log</h3>
            <Button 
              size="sm" 
              onClick={() => setView('create')} 
              disabled={!!activeTicket}
              className={cn(
                "rounded-xl h-9 px-4 gap-2 text-[10px] font-black uppercase tracking-widest transition-all",
                activeTicket ? "bg-white/5 text-muted-foreground border-white/5" : "bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20"
              )}
            >
              <Plus className="h-3.5 w-3.5" /> New Ticket
            </Button>
          </div>

          {activeTicket && (
            <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-2xl flex items-start gap-3 animate-pulse">
              <AlertCircle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="text-[10px] font-black uppercase text-amber-200">Institutional Review in Progress</p>
                <p className="text-[9px] text-muted-foreground uppercase font-bold leading-relaxed opacity-70">
                  New technical narratives are locked until your pending audit (ID: #{activeTicket.id.substring(0,6)}) is formally resolved by the desk.
                </p>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {tickets.length > 0 ? (
              tickets.map((ticket) => (
                <div 
                  key={ticket.id} 
                  className="bg-[#14141A] border border-white/5 rounded-2xl p-5 space-y-4 hover:border-white/10 transition-colors group relative overflow-hidden"
                >
                  <div className="absolute right-0 top-0 p-4 opacity-[0.02]">
                    <ShieldCheck className="h-12 w-12" />
                  </div>

                  <div className="flex justify-between items-start relative z-10">
                    <div className="space-y-1">
                      <span className="text-[8px] font-black text-muted-foreground uppercase tracking-widest">Audit ID: #{ticket.id.substring(0,8).toUpperCase()}</span>
                      <h4 className="text-xs font-bold leading-relaxed">{ticket.message}</h4>
                    </div>
                    <span className={cn(
                      "px-2 py-0.5 text-[8px] font-black uppercase rounded border shrink-0 ml-4",
                      ticket.status === 'pending' 
                        ? "bg-amber-500/10 text-amber-500 border-amber-500/20" 
                        : "bg-emerald-500/10 text-emerald-500 border-emerald-500/20 shadow-lg shadow-emerald-500/5"
                    )}>
                      {ticket.status === 'pending' ? 'Awaiting Desk' : 'Resolved'}
                    </span>
                  </div>

                  {ticket.adminReply && (
                    <div className="p-4 bg-primary/5 rounded-xl border-l-2 border-primary space-y-1.5 animate-in slide-in-from-left duration-500">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-3 w-3 text-primary" />
                        <p className="text-[8px] font-black uppercase text-primary tracking-widest">Administrative Resolution</p>
                      </div>
                      <p className="text-[10px] font-bold leading-relaxed italic">"{ticket.adminReply}"</p>
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-[8px] text-muted-foreground font-black uppercase tracking-tighter opacity-50">
                    <Clock className="h-2.5 w-2.5" /> {new Date(ticket.date).toLocaleDateString()} AT {new Date(ticket.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-16 text-center border-2 border-dashed rounded-[2rem] border-white/5 flex flex-col items-center gap-4 bg-white/[0.01]">
                <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center">
                  <History className="h-6 w-6 text-muted-foreground/30" />
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Audit Log Empty</p>
                  <p className="text-[9px] text-muted-foreground uppercase font-bold opacity-40">Initiate a narrative to contact technical desk</p>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <form onSubmit={handleSend} className="space-y-6 animate-in slide-in-from-right duration-300">
          <button 
            type="button" 
            onClick={() => setView('list')}
            className="flex items-center gap-2 text-[9px] font-black text-primary uppercase tracking-widest hover:underline px-1"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back to History
          </button>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[9px] uppercase font-black text-muted-foreground tracking-widest ml-1">Account Identity</Label>
              <Input 
                type="email" 
                value={user?.email || ''} 
                readOnly
                disabled
                className="bg-white/[0.02] border-white/5 h-12 rounded-xl text-xs font-bold opacity-40 cursor-not-allowed" 
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[9px] uppercase font-black text-muted-foreground tracking-widest ml-1">Technical Narrative</Label>
              <Textarea 
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Detail your operational query for desk review..." 
                required 
                className="bg-white/5 border-white/10 min-h-[160px] rounded-xl text-sm font-bold focus:border-primary transition-all p-4 resize-none" 
              />
            </div>
          </div>

          <div className="bg-primary/5 border border-primary/10 rounded-2xl p-4 flex items-center gap-3">
             <ShieldCheck className="h-4 w-4 text-primary shrink-0" />
             <p className="text-[9px] font-bold text-muted-foreground uppercase leading-tight opacity-70">
               Requests are logged on an institutional audit node. Response times vary by market volatility.
             </p>
          </div>

          <Button type="submit" className="w-full h-14 bg-primary hover:bg-primary/90 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] shadow-xl shadow-primary/20" disabled={isLoading || !message.trim()}>
            {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <><Send className="h-3.5 w-3.5 mr-2" /> Dispatch Request</>}
          </Button>
        </form>
      )}
    </div>
  );
}
