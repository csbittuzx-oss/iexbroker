"use client"

import React, { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { useRouter } from 'next/navigation';
import { 
  Users, 
  Wallet, 
  ArrowDownCircle, 
  MessageSquare, 
  Search,
  CheckCircle2,
  XCircle,
  Loader2,
  Lock,
  Unlock,
  Terminal,
  Plus,
  Ticket,
  Trash2
} from 'lucide-react';
import { useFirestore, useAuth } from '@/firebase';
import { 
  collection, 
  query, 
  onSnapshot, 
  doc, 
  updateDoc, 
  orderBy, 
  increment, 
  addDoc,
  deleteDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

export default function AdminPage() {
  const { user, isLoggedIn, clearSession } = useStore();
  const router = useRouter();
  const db = useFirestore();
  const auth = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('users');
  const [users, setUsers] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [bonusCodes, setBonusCodes] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // New Bonus Code State
  const [newCode, setNewCode] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [newMaxUses, setNewMaxUses] = useState('');

  useEffect(() => {
    if (!isLoggedIn || !user?.isAdmin) {
      router.replace('/auth');
      return;
    }

    const unsubUsers = onSnapshot(
      collection(db, 'users'), 
      (snap) => {
        setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setIsLoading(false);
      },
      async (error) => {
        const permissionError = new FirestorePermissionError({
          path: 'users',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
        setIsLoading(false);
      }
    );

    const unsubDeps = onSnapshot(
      query(collection(db, 'deposits'), orderBy('date', 'desc')), 
      (snap) => {
        setDeposits(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      },
      async (error) => {
        const permissionError = new FirestorePermissionError({
          path: 'deposits',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      }
    );

    const unsubWiths = onSnapshot(
      query(collection(db, 'withdrawals'), orderBy('date', 'desc')), 
      (snap) => {
        setWithdrawals(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      },
      async (error) => {
        const permissionError = new FirestorePermissionError({
          path: 'withdrawals',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      }
    );

    const unsubTickets = onSnapshot(
      query(collection(db, 'supportTickets'), orderBy('date', 'desc')), 
      (snap) => {
        setTickets(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      },
      async (error) => {
        const permissionError = new FirestorePermissionError({
          path: 'supportTickets',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      }
    );

    const unsubBonus = onSnapshot(
      collection(db, 'bonus_codes'), 
      (snap) => {
        setBonusCodes(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      },
      async (error) => {
        const permissionError = new FirestorePermissionError({
          path: 'bonus_codes',
          operation: 'list',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      }
    );

    return () => {
      unsubUsers();
      unsubDeps();
      unsubWiths();
      unsubTickets();
      unsubBonus();
    };
  }, [isLoggedIn, user, router, db]);

  const handleExitTerminal = () => {
    auth.signOut().finally(() => {
      clearSession();
      router.replace('/auth');
    });
  };

  const handleUpdateStatus = (coll: string, id: string, status: string, amount: number, userEmail: string) => {
    if (!userEmail) {
      toast({ variant: "destructive", title: "Sync Node Busy", description: "Identity context missing from record." });
      return;
    }

    const ref = doc(db, coll, id);
    
    updateDoc(ref, { status })
      .then(() => {
        const targetUser = users.find(u => u.email?.toLowerCase() === userEmail.toLowerCase());
        
        if (targetUser) {
          const userRef = doc(db, 'users', targetUser.id);
          let balanceChange = 0;
          let toastMsg = "";

          if (coll === 'deposits' && status === 'approved') {
            balanceChange = amount;
            toastMsg = `Equity of $${amount} injected.`;
          } 
          else if (coll === 'withdrawals' && status === 'rejected') {
            balanceChange = amount;
            toastMsg = `Liquidity of $${amount} refunded to trader.`;
          }

          if (balanceChange !== 0) {
            updateDoc(userRef, { balance: increment(balanceChange) })
              .then(() => {
                toast({ title: "Liquidity Synced", description: toastMsg });
              })
              .catch(async (e) => {
                const permissionError = new FirestorePermissionError({
                  path: `users/${targetUser.id}`,
                  operation: 'update',
                  requestResourceData: { balance: increment(balanceChange) },
                } satisfies SecurityRuleContext);
                errorEmitter.emit('permission-error', permissionError);
              });
          }
        }
        toast({ title: "Audit Updated", description: `Transaction marked as ${status}.` });
      })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: `${coll}/${id}`,
          operation: 'update',
          requestResourceData: { status },
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const handleUserAction = (userId: string, action: 'ban' | 'unban' | 'addBalance', value?: number) => {
    const userRef = doc(db, 'users', userId);
    let updateData: any = {};
    
    if (action === 'ban') updateData = { status: 'banned' };
    if (action === 'unban') updateData = { status: 'active' };
    
    if (action === 'addBalance' && value !== undefined) {
      updateDoc(userRef, { balance: increment(value) })
        .then(() => {
          toast({ title: "Capital Injected", description: "Manual balance adjustment successful." });
        })
        .catch(async (e) => {
          const permissionError = new FirestorePermissionError({
            path: `users/${userId}`,
            operation: 'update',
            requestResourceData: { balance: increment(value) },
          } satisfies SecurityRuleContext);
          errorEmitter.emit('permission-error', permissionError);
        });
      return;
    }

    updateDoc(userRef, updateData)
      .then(() => {
        toast({ title: "User Updated", description: "Trader profile synchronization complete." });
      })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: `users/${userId}`,
          operation: 'update',
          requestResourceData: updateData,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const handleTicketReply = (ticketId: string, reply: string) => {
    const ticketRef = doc(db, 'supportTickets', ticketId);
    const updateData = { 
      adminReply: reply,
      status: 'resolved' 
    };

    updateDoc(ticketRef, updateData)
      .then(() => {
        toast({ title: "Reply Sent", description: "Technical desk updated instantly." });
      })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: `supportTickets/${ticketId}`,
          operation: 'update',
          requestResourceData: updateData,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const handleCreateBonus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode.trim() || !newAmount || !newMaxUses) return;

    const data = {
      code: newCode.trim().toUpperCase(),
      amount: Number(newAmount),
      maxUses: Number(newMaxUses),
      usedCount: 0,
      isActive: true,
      createdAt: serverTimestamp()
    };

    addDoc(collection(db, 'bonus_codes'), data)
      .then(() => {
        toast({ title: "Bonus Created", description: `Code ${data.code} is now live.` });
        setNewCode('');
        setNewAmount('');
        setNewMaxUses('');
      })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: 'bonus_codes',
          operation: 'create',
          requestResourceData: data,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const handleToggleBonus = (id: string, current: boolean) => {
    updateDoc(doc(db, 'bonus_codes', id), { isActive: !current })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: `bonus_codes/${id}`,
          operation: 'update',
          requestResourceData: { isActive: !current },
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const handleDeleteBonus = (id: string) => {
    deleteDoc(doc(db, 'bonus_codes', id))
      .then(() => {
        toast({ title: "Bonus Expunged", description: "Promotional node deleted." });
      })
      .catch(async (e) => {
        const permissionError = new FirestorePermissionError({
          path: `bonus_codes/${id}`,
          operation: 'delete',
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  if (isLoading) return (
    <div className="h-[100dvh] w-screen bg-[#0B0B0F] flex flex-col">
       <header className="h-16 border-b border-white/5 bg-[#0F0F14] flex items-center justify-between px-8">
          <div className="w-32 h-6 bg-white/5 rounded-lg shimmer" />
          <div className="w-48 h-8 bg-white/5 rounded-xl shimmer" />
       </header>
       <div className="flex-1 flex gap-0">
          <aside className="w-64 border-r border-white/5 bg-[#0F0F14] p-6 space-y-4">
             {[1,2,3,4,5].map(i => <div key={i} className="h-12 w-full bg-white/5 rounded-xl shimmer" />)}
          </aside>
          <main className="flex-1 p-8 space-y-6">
             <div className="flex justify-between">
                <div className="h-8 w-64 bg-white/5 rounded-lg shimmer" />
                <div className="h-10 w-64 bg-white/5 rounded-xl shimmer" />
             </div>
             <div className="space-y-4">
                {[1,2,3,4].map(i => <div key={i} className="h-24 w-full bg-white/5 rounded-2xl shimmer" />)}
             </div>
          </main>
       </div>
    </div>
  );

  const filteredUsers = users.filter(u => u.email?.toLowerCase().includes(searchQuery.toLowerCase()) || u.nickname?.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredDeps = deposits.filter(t => t.userEmail?.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredWiths = withdrawals.filter(t => t.userEmail?.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen bg-[#0B0B0F] text-foreground flex flex-col">
      <header className="h-16 border-b border-white/5 bg-[#0F0F14] flex items-center justify-between px-8 shrink-0">
        <div className="flex items-center gap-6">
          <Image src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" alt="Logo" width={100} height={30} className="h-6 w-auto" />
          <div className="h-5 w-px bg-white/10" />
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-primary" />
            <h1 className="text-xs font-black uppercase tracking-[0.3em] text-primary">Command Center</h1>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="border-primary/50 text-primary font-black uppercase text-[10px]">Matrix Status: Active</Badge>
          <Button variant="ghost" size="sm" onClick={handleExitTerminal} className="text-[10px] font-black uppercase tracking-widest hover:bg-white/5">Exit Terminal</Button>
        </div>
      </header>

      <main className="flex-1 overflow-hidden flex gap-0">
        <aside className="w-64 border-r border-white/5 bg-[#0F0F14] p-6 flex flex-col gap-2">
          <NavBtn active={activeTab === 'users'} icon={<Users />} label="Traders" onClick={() => setActiveTab('users')} />
          <NavBtn active={activeTab === 'deposits'} icon={<Wallet />} label="Deposits" onClick={() => setActiveTab('deposits')} />
          <NavBtn active={activeTab === 'withdrawals'} icon={<ArrowDownCircle />} label="Withdrawals" onClick={() => setActiveTab('withdrawals')} />
          <NavBtn active={activeTab === 'support'} icon={<MessageSquare />} label="Support Desk" onClick={() => setActiveTab('support')} />
          <NavBtn active={activeTab === 'bonus'} icon={<Ticket />} label="Bonus Codes" onClick={() => setActiveTab('bonus')} />
          
          <div className="mt-auto p-4 bg-primary/5 rounded-2xl border border-primary/10">
            <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest mb-1">Total Liquidity</p>
            <p className="text-xl font-mono font-black text-primary">${users.reduce((acc, u) => acc + (u.balance || 0), 0).toLocaleString()}</p>
          </div>
        </aside>

        <section className="flex-1 bg-[#0B0B0F] p-8 overflow-hidden flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black uppercase tracking-tight">
              {activeTab === 'bonus' ? 'Promotional' : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Administration
            </h2>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <input 
                placeholder="Search Matrix..." 
                className="w-full pl-9 h-10 bg-white/5 border border-white/10 rounded-xl text-xs font-bold outline-none focus:border-primary/50" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <ScrollArea className="flex-1">
            {activeTab === 'users' && (
              <div className="grid grid-cols-1 gap-4">
                {filteredUsers.length > 0 ? filteredUsers.map(u => (
                  <div key={u.id} className="bg-[#14141A] border border-white/5 p-5 rounded-2xl flex items-center justify-between group hover:border-primary/30 transition-all">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center font-black text-primary border border-white/5">{u.nickname?.[0]}</div>
                      <div>
                        <h4 className="text-sm font-black uppercase">{u.nickname} <span className="text-[10px] text-muted-foreground ml-2">({u.email})</span></h4>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-[9px] font-bold text-muted-foreground uppercase">{u.country}</span>
                          <span className={cn("text-[9px] font-black uppercase px-1.5 rounded", u.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500')}>
                            {u.status}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-8">
                       <div className="text-right">
                         <p className="text-[8px] font-black text-muted-foreground uppercase tracking-widest">Equity</p>
                         <p className="text-lg font-mono font-black text-primary">${(u.balance || 0).toLocaleString()}</p>
                       </div>
                       <div className="flex items-center gap-2">
                         <Button size="sm" variant="secondary" onClick={() => handleUserAction(u.id, 'addBalance', 100)} className="h-9 px-3 bg-white/5 border-white/5 hover:bg-emerald-500/10 hover:text-emerald-500 text-[10px] font-black uppercase">+$100</Button>
                         {u.status === 'active' ? (
                           <Button size="icon" variant="ghost" onClick={() => handleUserAction(u.id, 'ban')} className="text-rose-500 hover:bg-rose-500/10"><Lock className="h-4 w-4" /></Button>
                         ) : (
                           <Button size="icon" variant="ghost" onClick={() => handleUserAction(u.id, 'unban')} className="text-emerald-500 hover:bg-emerald-500/10"><Unlock className="h-4 w-4" /></Button>
                         )}
                       </div>
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-20 opacity-30 uppercase font-black tracking-widest text-[10px]">No users found</div>
                )}
              </div>
            )}

            {(activeTab === 'deposits' || activeTab === 'withdrawals') && (
              <div className="space-y-3">
                {(activeTab === 'deposits' ? filteredDeps : filteredWiths).length > 0 ? (activeTab === 'deposits' ? filteredDeps : filteredWiths).map(t => (
                  <div key={t.id} className="bg-[#14141A] border border-white/5 p-4 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={cn("p-2 rounded-xl bg-white/5", t.status === 'pending' ? 'text-amber-400' : t.status === 'approved' ? 'text-emerald-400' : 'text-rose-400')}>
                        {t.status === 'pending' ? <Loader2 className="h-5 w-5 animate-spin" /> : t.status === 'approved' ? <CheckCircle2 className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase text-muted-foreground">{t.userEmail}</p>
                        <p className="text-xs font-bold uppercase">{t.method} <span className="text-[8px] opacity-40 ml-2">TX: {t.txid || t.id.substring(0,8)}</span></p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-[8px] font-black uppercase text-muted-foreground">Amount</p>
                        <p className="text-base font-mono font-black text-white">${t.amount?.toLocaleString()}</p>
                      </div>
                      {t.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 h-9 font-black uppercase text-[10px]" onClick={() => handleUpdateStatus(activeTab === 'deposits' ? 'deposits' : 'withdrawals', t.id, 'approved', t.amount, t.userEmail)}>Approve</Button>
                          <Button size="sm" variant="destructive" className="h-9 font-black uppercase text-[10px]" onClick={() => handleUpdateStatus(activeTab === 'deposits' ? 'deposits' : 'withdrawals', t.id, 'rejected', t.amount, t.userEmail)}>Reject</Button>
                        </div>
                      )}
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-20 opacity-30 uppercase font-black tracking-widest text-[10px]">No records found</div>
                )}
              </div>
            )}

            {activeTab === 'support' && (
              <div className="space-y-4">
                {tickets.length > 0 ? tickets.map(t => (
                  <div key={t.id} className="bg-[#14141A] border border-white/5 p-5 rounded-2xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary"><MessageSquare className="h-5 w-5" /></div>
                        <div>
                          <p className="text-[10px] font-black uppercase text-muted-foreground">{t.email}</p>
                          <p className="text-[9px] font-bold text-muted-foreground">{new Date(t.date).toLocaleString()}</p>
                        </div>
                      </div>
                      <Badge className={t.status === 'pending' ? 'bg-amber-500/10 text-amber-500' : 'bg-emerald-500/10 text-emerald-500'}>{t.status}</Badge>
                    </div>
                    <div className="p-4 bg-black/20 rounded-xl border border-white/5">
                      <p className="text-xs font-medium leading-relaxed italic">"{t.message}"</p>
                    </div>
                    {t.status === 'pending' ? (
                      <div className="flex gap-2">
                        <Input placeholder="Type administrative response..." className="bg-white/5 border-white/10 h-11" onKeyDown={(e) => {
                          if (e.key === 'Enter') handleTicketReply(t.id, (e.target as HTMLInputElement).value);
                        }} />
                        <Button className="h-11 px-6 font-black uppercase text-[10px]" onClick={(e) => {
                          const input = (e.currentTarget.previousElementSibling as HTMLInputElement);
                          handleTicketReply(t.id, input.value);
                        }}>Send Reply</Button>
                      </div>
                    ) : (
                      <div className="p-3 bg-primary/5 rounded-xl border-l-2 border-primary">
                        <p className="text-[8px] font-black uppercase text-primary mb-1">Reply Log</p>
                        <p className="text-[10px] font-bold">"{t.adminReply}"</p>
                      </div>
                    )}
                  </div>
                )) : (
                  <div className="text-center py-20 opacity-30 uppercase font-black tracking-widest text-[10px]">No tickets found</div>
                )}
              </div>
            )}

            {activeTab === 'bonus' && (
              <div className="space-y-8">
                <form onSubmit={handleCreateBonus} className="bg-[#14141A] border border-white/5 p-6 rounded-2xl grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                   <div className="space-y-2">
                     <Label className="text-[10px] font-black uppercase text-muted-foreground">Code</Label>
                     <Input placeholder="PROMO2026" value={newCode} onChange={e => setNewCode(e.target.value)} className="bg-white/5 border-white/10" />
                   </div>
                   <div className="space-y-2">
                     <Label className="text-[10px] font-black uppercase text-muted-foreground">Amount ($)</Label>
                     <Input type="number" placeholder="50" value={newAmount} onChange={e => setNewAmount(e.target.value)} className="bg-white/5 border-white/10" />
                   </div>
                   <div className="space-y-2">
                     <Label className="text-[10px] font-black uppercase text-muted-foreground">Max Uses</Label>
                     <Input type="number" placeholder="100" value={newMaxUses} onChange={e => setNewMaxUses(e.target.value)} className="bg-white/5 border-white/10" />
                   </div>
                   <Button type="submit" className="h-10 font-black uppercase text-[10px] gap-2"><Plus className="h-4 w-4" /> Create Node</Button>
                </form>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bonusCodes.map(bc => (
                    <div key={bc.id} className="bg-[#14141A] border border-white/5 p-5 rounded-2xl flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary"><Ticket className="h-5 w-5" /></div>
                        <div>
                          <h4 className="text-sm font-black uppercase tracking-widest">{bc.code}</h4>
                          <p className="text-[10px] font-bold text-muted-foreground uppercase mt-0.5">Benefit: ${bc.amount} | Uses: {bc.usedCount}/{bc.maxUses}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleToggleBonus(bc.id, bc.isActive)}
                          className={cn("text-[10px] font-black uppercase tracking-widest", bc.isActive ? "text-emerald-500" : "text-rose-500")}
                        >
                          {bc.isActive ? 'Active' : 'Paused'}
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => handleDeleteBonus(bc.id)} className="text-muted-foreground hover:text-rose-500">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {bonusCodes.length === 0 && (
                    <div className="col-span-2 text-center py-10 opacity-30 uppercase font-black tracking-widest text-[10px]">No bonus codes found</div>
                  )}
                </div>
              </div>
            )}
          </ScrollArea>
        </section>
      </main>
    </div>
  );
}

function NavBtn({ active, icon, label, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 px-4 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all w-full",
        active ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
      )}
    >
      {React.cloneElement(icon, { className: "h-4 w-4" })}
      {label}
    </button>
  );
}
