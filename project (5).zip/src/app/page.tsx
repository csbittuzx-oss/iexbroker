
"use client"

import React, { useEffect, useState, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { useRouter } from 'next/navigation';
import DesktopLayout from '@/components/layout/DesktopLayout';
import MobileLayout from '@/components/layout/MobileLayout';
import { Loader2 } from 'lucide-react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { useAuth, useFirestore } from '@/firebase';
import { doc, onSnapshot, Unsubscribe } from 'firebase/firestore';
import Image from 'next/image';

export default function HomePage() {
  const { user, isLoggedIn, setLoggedIn, setUser, clearSession, _hasHydrated } = useStore();
  const router = useRouter();
  const [isMounted, setIsMounted] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isVerifying, setIsVerifying] = useState(true);
  const [fbUser, setFbUser] = useState<User | null>(null);
  
  const auth = useAuth();
  const db = useFirestore();

  // 1. Initial Setup: Hydration and Resize Listener
  useEffect(() => {
    setIsMounted(true);
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // 2. Auth State Observer
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      const currentState = useStore.getState();
      
      // Handle Master Admin Bypass
      if (!firebaseUser && currentState.user?.uid === 'master-admin-bypass') {
        setLoggedIn(true);
        setIsVerifying(false);
        return;
      }

      setFbUser(firebaseUser);
      
      if (!firebaseUser) {
        if (currentState.user?.uid !== 'master-admin-bypass') {
          clearSession();
        }
        setIsVerifying(false);
      }
    });

    return () => unsubscribeAuth();
  }, [auth, clearSession, setLoggedIn]);

  // 3. Profile Synchronizer with Ban Detection
  useEffect(() => {
    if (!fbUser) return;

    const currentState = useStore.getState();
    // If the user changed, clear old session data
    if (currentState.user && currentState.user.uid !== fbUser.uid && currentState.user.uid !== 'master-admin-bypass') {
      clearSession();
    }

    const userRef = doc(db, 'users', fbUser.uid);
    let unsub: Unsubscribe | null = null;

    try {
      unsub = onSnapshot(userRef, (snap) => {
        if (snap.exists()) {
          const data = snap.data();

          // CRITICAL: Check for restricted status
          if (data.status === 'banned') {
            auth.signOut().finally(() => {
              clearSession();
              router.replace('/auth?status=restricted');
            });
            return;
          }

          setUser({
            uid: fbUser.uid,
            email: fbUser.email || '',
            nickname: data.nickname || 'Trader',
            firstName: data.firstName || '',
            lastName: data.lastName || '',
            birthday: data.birthday || '',
            country: data.country || '',
            withdrawalPin: data.withdrawalPin || '',
            isAdmin: data.isAdmin || (fbUser.email === 'iextrade.official@gmail.com'),
            balance: data.balance ?? 0,
            status: data.status || 'active',
            namesEdited: data.namesEdited || false,
            profilePic: data.profilePic || ''
          } as any);
          setLoggedIn(true);
        } else {
          setLoggedIn(true);
        }
        setIsVerifying(false);
      }, (error) => {
        console.warn("Institutional sync node busy. Retrying sync...");
        setIsVerifying(false);
      });
    } catch (err) {
      console.error("Critical Profile Sync Failure:", err);
      setIsVerifying(false);
    }

    return () => {
      if (unsub) {
        try { unsub(); } catch (e) {}
      }
    };
  }, [fbUser, db, setUser, setLoggedIn, clearSession, router, auth]);

  // 4. Redirection Logic: Managed after state is stable
  useEffect(() => {
    if (isMounted && !isVerifying && _hasHydrated) {
      if (!isLoggedIn) {
        router.replace('/auth');
      } else if (user?.isAdmin) {
        router.replace('/admin');
      }
    }
  }, [isLoggedIn, user, router, isMounted, _hasHydrated, isVerifying]);

  if (!isMounted || !_hasHydrated || isVerifying) {
    return (
      <div className="h-[100dvh] w-screen flex flex-col items-center justify-center bg-[#0B0B0F] overflow-hidden">
        <div className="w-full max-w-[320px] flex flex-col items-center gap-8 animate-in fade-in duration-700">
          <div className="relative">
            <div className="absolute inset-0 blur-3xl bg-primary/10 rounded-full animate-pulse" />
            <Image 
              src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" 
              alt="Logo" 
              width={180} 
              height={50} 
              className="relative brightness-110"
              priority
            />
          </div>

          <div className="w-full space-y-4 pt-10">
            <div className="h-3 w-full bg-white/[0.03] rounded-full shimmer" />
            <div className="h-3 w-[85%] bg-white/[0.03] rounded-full shimmer" />
            <div className="h-3 w-[92%] bg-white/[0.03] rounded-full shimmer" />
          </div>

          <div className="flex flex-col items-center gap-3 text-primary/40 pt-10">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="text-[9px] font-black uppercase tracking-[0.4em] animate-pulse">Initializing Interface</span>
          </div>
        </div>
      </div>
    );
  }

  if (!isLoggedIn || user?.isAdmin) return null;

  return isMobile ? <MobileLayout /> : <DesktopLayout />;
}
