import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  /**
   * Deterministic Synchronized Payout API Node.
   * Returns consistent values (75% - 92%) for authorized pairs 
   * globally based on 30-minute UTC time buckets.
   */
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get('symbol') || 'BTCUSDT';
  
  const now = new Date();
  const bucket = Math.floor((now.getUTCHours() * 60 + now.getUTCMinutes()) / 30);
  
  // Deterministic grouping based on symbol
  let hash = 0;
  for (let i = 0; i < symbol.length; i++) {
    hash = ((hash << 5) - hash) + symbol.charCodeAt(i);
  }
  const groupId = Math.abs(hash) % 8;
  
  // Deterministic seed ensures all devices sync perfectly
  const seed = (bucket * 0.1337) + (groupId * 0.5432);
  const getPayout = (s: number) => 75 + (Math.abs(Math.sin(s * 42.42)) * 17);
  
  return NextResponse.json({
    symbol,
    payout: Math.floor(getPayout(seed)),
    bucketId: bucket,
    groupId,
    nextUpdateIn: 30 - (now.getUTCMinutes() % 30)
  });
}
