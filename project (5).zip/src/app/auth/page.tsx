
"use client"

import React, { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useRouter, useSearchParams } from 'next/navigation';
import { Loader2, ShieldCheck, Mail, Lock, User, Globe, ArrowRight, AlertTriangle, Send } from 'lucide-react';
import Image from 'next/image';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail
} from 'firebase/auth';
import { useAuth, useFirestore } from '@/firebase';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const COUNTRIES = [
  "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Australia", "Austria", 
  "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", 
  "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", 
  "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", 
  "China", "Colombia", "Comoros", "Congo", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", 
  "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", 
  "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", 
  "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guyana", "Haiti", "Honduras", "Hungary", 
  "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", 
  "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", 
  "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", 
  "Malta", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", 
  "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", 
  "Niger", "Nigeria", "North Korea", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", "Panama", 
  "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", 
  "Rwanda", "Samoa", "San Marino", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", 
  "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", 
  "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", 
  "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", 
  "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu", 
  "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
];

export default function AuthPage() {
  const [mounted, setMounted] = useState(false);
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [showBannedDialog, setShowBannedDialog] = useState(false);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    nickname: '',
    country: '',
    pin: ''
  });

  const { setLoggedIn, setUser, clearSession, user, isLoggedIn, _hasHydrated } = useStore();
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();
  const auth = useAuth();
  const db = useFirestore();

  useEffect(() => {
    setMounted(true);
    if (searchParams.get('status') === 'restricted') {
      setShowBannedDialog(true);
    }
  }, [searchParams]);

  useEffect(() => {
    if (mounted && _hasHydrated && isLoggedIn && user) {
      const path = user.isAdmin ? '/admin' : '/';
      router.replace(path);
    }
  }, [isLoggedIn, mounted, _hasHydrated, router, user]);

  const updateForm = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const syncUserProfile = async (uid: string, initialData?: any) => {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    
    if (snap.exists()) {
      const data = snap.data();
      return {
        uid,
        email: data.email,
        nickname: data.nickname || 'Trader',
        firstName: data.firstName || '',
        lastName: data.lastName || '',
        birthday: data.birthday || '',
        country: data.country || 'Global',
        withdrawalPin: data.withdrawalPin || '000000',
        balance: data.balance ?? 0,
        status: data.status || 'active',
        isAdmin: data.isAdmin || (data.email === 'iextrade.official@gmail.com'),
        namesEdited: data.namesEdited || false
      };
    } else if (initialData) {
      const profile = {
        uid,
        ...initialData,
        balance: 0,
        status: 'active',
        createdAt: serverTimestamp(),
        isAdmin: initialData.email === 'iextrade.official@gmail.com',
        firstName: '',
        lastName: '',
        namesEdited: false
      };
      await setDoc(userRef, profile);
      return profile;
    }
    return null;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setIsLoading(true);

    const { email, password } = formData;

    if (email === 'iextrade.official@gmail.com' && password === 'Demo0099') {
      clearSession();
      const adminProfile = {
        uid: 'master-admin-bypass',
        email: 'iextrade.official@gmail.com',
        nickname: 'Super Admin',
        isAdmin: true,
        status: 'active',
        balance: 0,
        country: 'Global',
        namesEdited: true
      };
      setUser(adminProfile as any);
      setLoggedIn(true);
      toast({ title: "Admin Login", description: "Admin terminal unlocked." });
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const profile = await syncUserProfile(userCredential.user.uid);
      
      if (profile) {
        if (profile.status === 'banned') {
          setIsLoading(false);
          setLoggedIn(false);
          await auth.signOut();
          setShowBannedDialog(true);
          return;
        }
        setUser(profile as any);
        setLoggedIn(true);
        toast({ title: "Welcome back", description: "Connecting to trading terminal..." });
      }
    } catch (error: any) {
      setIsLoading(false);
      let message = "Invalid email or password.";
      toast({ variant: "destructive", title: "Login Failed", description: message });
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    const { email, password, nickname, country, pin } = formData;

    if (pin.length !== 6 || isNaN(Number(pin))) {
      toast({ variant: "destructive", title: "Error", description: "Withdrawal PIN must be 6 digits." });
      return;
    }

    setIsLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const profile = await syncUserProfile(userCredential.user.uid, {
        email,
        nickname: nickname || email.split('@')[0],
        country,
        withdrawalPin: pin
      });
      if (profile) {
        setUser(profile as any);
        setLoggedIn(true);
        toast({ title: "Success", description: "Account created successfully." });
      }
    } catch (error: any) {
      setIsLoading(false);
      let message = "Account creation failed.";
      if (error.code === 'auth/email-already-in-use') message = "This email is already in use.";
      toast({ variant: "destructive", title: "Registration Error", description: message });
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email) return;
    setIsLoading(true);
    try {
      await sendPasswordResetEmail(auth, formData.email);
      setIsLoading(false);
      toast({ title: "Email Sent", description: "Check your email for reset instructions." });
      setMode('login');
    } catch (e) {
      setIsLoading(false);
      toast({ variant: "destructive", title: "Error", description: "Failed to send reset link." });
    }
  };

  const modeSwitch = (newMode: 'login' | 'register' | 'forgot') => {
    setMode(newMode);
    setIsLoading(false);
  };

  if (!mounted || !_hasHydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B0B0F]">
        <Loader2 className="h-8 w-8 animate-spin text-primary opacity-20" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0B0B0F] px-4 py-12 overflow-x-hidden relative">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-[120px]" />
      </div>

      <div className="w-full max-w-[440px] z-10">
        <div className="mb-10 flex flex-col items-center animate-in fade-in slide-in-from-top-4 duration-700">
          <Image 
            src="https://i.ibb.co/Kp4R4fKF/Picsart-26-05-08-19-16-34-822.png" 
            alt="IEX Logo" 
            width={180} 
            height={50} 
            className="h-10 w-auto mb-2"
            priority
          />
          <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/20 rounded-full">
            <ShieldCheck className="h-3 w-3 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Secure Access</span>
          </div>
        </div>

        <div className="bg-[#0F0F14]/80 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl animate-in zoom-in-95 duration-500">
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-6 animate-in slide-in-from-right duration-500">
              <div className="space-y-5">
                <AuthInput 
                  label="Email" 
                  icon={<Mail />} 
                  type="email" 
                  value={formData.email} 
                  onChange={(v) => updateForm('email', v)} 
                  placeholder="name@example.com" 
                  required 
                />
                <AuthInput 
                  label="Password" 
                  icon={<Lock />} 
                  type="password" 
                  value={formData.password} 
                  onChange={(v) => updateForm('password', v)} 
                  placeholder="••••••••" 
                  required 
                />
              </div>

              <div className="flex items-center justify-end px-1">
                <button 
                  type="button" 
                  onClick={() => modeSwitch('forgot')} 
                  className="text-[10px] font-black text-primary uppercase tracking-widest hover:text-white transition-colors"
                >
                  Forgot Password?
                </button>
              </div>

              <Button type="submit" disabled={isLoading} className="w-full h-14 bg-primary hover:bg-primary/90 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-primary/20 transition-all active:scale-[0.98]">
                {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <span className="flex items-center gap-2">Sign In <ArrowRight className="h-4 w-4" /></span>}
              </Button>

              <div className="text-center pt-2">
                <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">
                  New User? <button type="button" onClick={() => modeSwitch('register')} className="text-primary hover:underline">Create Account</button>
                </p>
              </div>
            </form>
          )}

          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-5 animate-in slide-in-from-left duration-500">
              <AuthInput label="Email" icon={<Mail />} type="email" value={formData.email} onChange={(v) => updateForm('email', v)} placeholder="name@example.com" required />
              <AuthInput label="Nickname" icon={<User />} type="text" value={formData.nickname} onChange={(v) => updateForm('nickname', v)} placeholder="ApexTrader" required />
              
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-black tracking-[0.1em] text-muted-foreground ml-1">Select Country</Label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground z-10"><Globe className="h-4 w-4" /></div>
                  <Select value={formData.country} onValueChange={(v) => updateForm('country', v)} required>
                    <SelectTrigger className="h-12 bg-white/[0.03] border-white/5 rounded-xl pl-11 font-bold text-xs focus:ring-primary/20">
                      <SelectValue placeholder="Select Country" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px] bg-[#0F0F14] border-white/10">
                      {COUNTRIES.map(c => <SelectItem key={c} value={c} className="text-xs font-bold">{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <AuthInput label="Password" icon={<Lock />} type="password" value={formData.password} onChange={(v) => updateForm('password', v)} placeholder="Min 6 chars" required />
                <AuthInput label="Withdrawal PIN" icon={<ShieldCheck />} type="text" maxLength={6} value={formData.pin} onChange={(v) => updateForm('pin', v)} placeholder="6-digits" required />
              </div>

              <div className="flex items-start space-x-3 px-1">
                <Checkbox id="terms" required className="mt-1 bg-white/5 border-white/10" />
                <Label htmlFor="terms" className="text-[9px] text-muted-foreground uppercase font-black leading-tight opacity-60">
                  I agree to the terms and verify I am of legal age.
                </Label>
              </div>

              <Button type="submit" disabled={isLoading} className="w-full h-14 bg-primary hover:bg-primary/90 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-primary/20 mt-2 transition-all">
                {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Create Account'}
              </Button>
              
              <button type="button" onClick={() => modeSwitch('login')} className="w-full text-center text-[10px] font-black text-muted-foreground uppercase hover:text-white transition-colors tracking-widest">
                Return to Login
              </button>
            </form>
          )}

          {mode === 'forgot' && (
            <form onSubmit={handleForgot} className="space-y-8 animate-in zoom-in-95 duration-500">
              <div className="text-center space-y-2">
                <h3 className="text-sm font-black uppercase tracking-[0.2em] text-white">Forgot Password</h3>
                <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest opacity-60 px-4">Enter your email to receive a reset link.</p>
              </div>
              <AuthInput label="Email" icon={<Mail />} type="email" value={formData.email} onChange={(v) => updateForm('email', v)} placeholder="name@example.com" required />
              <Button type="submit" disabled={isLoading || !formData.email} className="w-full h-14 bg-primary rounded-2xl font-black uppercase tracking-widest transition-all">
                {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Send Reset Link'}
              </Button>
              <button type="button" onClick={() => modeSwitch('login')} className="w-full text-center text-[10px] font-black text-primary uppercase hover:underline tracking-widest">
                Back to Login
              </button>
            </form>
          )}
        </div>
      </div>

      <AlertDialog open={showBannedDialog} onOpenChange={setShowBannedDialog}>
        <AlertDialogContent className="bg-[#0F0F14] border-white/5 rounded-[2rem] p-8 max-w-[400px]">
          <AlertDialogHeader className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 bg-rose-500/10 rounded-2xl flex items-center justify-center text-rose-500 mb-2">
              <AlertTriangle className="h-8 w-8" />
            </div>
            <AlertDialogTitle className="text-xl font-black uppercase tracking-tight text-center">Account Banned</AlertDialogTitle>
            <AlertDialogDescription className="text-[11px] text-muted-foreground uppercase font-bold text-center leading-relaxed">
              Your account has been restricted. Please contact our support for help.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="mt-6 flex flex-col gap-3">
             <Button 
               className="h-14 w-full bg-primary hover:bg-primary/90 font-black uppercase tracking-widest rounded-2xl gap-3"
               onClick={() => window.open('https://t.me/IEX_support', '_blank')}
             >
               <Send className="h-4 w-4" /> Contact Telegram Support
             </Button>
             <AlertDialogAction className="h-12 w-full bg-white/5 hover:bg-white/10 text-white font-black uppercase tracking-widest rounded-xl border-none">
               Dismiss
             </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function AuthInput({ label, icon, type, value, onChange, placeholder, required, maxLength }: any) {
  return (
    <div className="space-y-2 group">
      <Label className="text-[10px] uppercase font-black tracking-[0.1em] text-muted-foreground ml-1 transition-colors group-focus-within:text-primary">
        {label}
      </Label>
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary">
          {React.cloneElement(icon as React.ReactElement, { className: "h-4 w-4" })}
        </div>
        <Input 
          type={type} 
          value={value} 
          maxLength={maxLength}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder} 
          required={required}
          className="h-12 bg-white/[0.03] border-white/5 rounded-xl pl-11 font-bold text-xs focus-visible:ring-primary/20 focus-visible:border-primary/30 transition-all placeholder:text-white/10"
        />
      </div>
    </div>
  );
}
