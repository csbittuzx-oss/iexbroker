'use server';
/**
 * @fileOverview An AI assistant flow for analyzing completed trades.
 *
 * - analyzeTradePerformance - A function that analyzes a completed trade.
 * - AnalyzeTradePerformanceInput - The input type for the analyzeTradePerformance function.
 * - AnalyzeTradePerformanceOutput - The return type for the analyzeTradePerformance function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AnalyzeTradePerformanceInputSchema = z.object({
  pairName: z.string().describe('The trading pair (e.g., SOLUSDT).'),
  openingPrice: z.number().describe('The price at which the trade was opened.'),
  closingPrice: z.number().describe('The price at which the trade was closed.'),
  tradeAmount: z.number().describe('The amount of currency traded.'),
  profitAmount: z.number().describe('The profit or loss amount from the trade.'),
  tradeDuration: z.string().describe('The duration of the trade (e.g., "01:00:00").'),
  tradeDate: z.string().describe('The date and time when the trade was completed (e.g., "YYYY-MM-DD HH:MM:SS").'),
  tradeOutcome: z.enum(['profit', 'loss', 'breakeven']).describe('The outcome of the trade.'),
});
export type AnalyzeTradePerformanceInput = z.infer<typeof AnalyzeTradePerformanceInputSchema>;

const AnalyzeTradePerformanceOutputSchema = z.object({
  marketConditionsSummary: z.string().describe('A concise summary of market conditions during the trade, including volatility, trend, and significant events.'),
  actionableInsights: z.array(z.string()).describe('A list of actionable insights derived from the trade performance, focusing on what worked or what went wrong.'),
  strategyRefinements: z.array(z.string()).describe('A list of recommendations for refining the trading strategy based on this trade, such as entry/exit points, risk management, or position sizing.'),
});
export type AnalyzeTradePerformanceOutput = z.infer<typeof AnalyzeTradePerformanceOutputSchema>;

export async function analyzeTradePerformance(input: AnalyzeTradePerformanceInput): Promise<AnalyzeTradePerformanceOutput> {
  return analyzeTradePerformanceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeTradePerformancePrompt',
  input: { schema: AnalyzeTradePerformanceInputSchema },
  output: { schema: AnalyzeTradePerformanceOutputSchema },
  prompt: `You are an expert financial analyst and trading assistant. Your task is to analyze a completed trade and provide a comprehensive summary of market conditions, actionable insights, and recommendations for strategy refinement.

Here are the details of the completed trade:
- Trading Pair: {{{pairName}}}
- Opening Price: {{{openingPrice}}}
- Closing Price: {{{closingPrice}}}
- Trade Amount: {{{tradeAmount}}}
- Profit/Loss: {{{profitAmount}}}
- Trade Duration: {{{tradeDuration}}}
- Trade Date: {{{tradeDate}}}
- Trade Outcome: {{{tradeOutcome}}}

Based on these details, provide:
1. A concise summary of the market conditions during this trade, considering factors like trend, volatility, and any implied market sentiment.
2. Actionable insights specifically tailored to this trade, highlighting key successes or areas for improvement.
3. Specific recommendations for refining the trading strategy that the trader can apply in future similar scenarios.`,
});

const analyzeTradePerformanceFlow = ai.defineFlow(
  {
    name: 'analyzeTradePerformanceFlow',
    inputSchema: AnalyzeTradePerformanceInputSchema,
    outputSchema: AnalyzeTradePerformanceOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
