import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-trade-performance.ts';