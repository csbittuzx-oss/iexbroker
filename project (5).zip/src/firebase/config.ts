
'use client';

/**
 * Institutional Firebase configuration.
 * Synchronization Node: [v1.0.68]
 * Authorized Project: iextrades-e5682
 * Sync Trigger: Bonus Code Module Restoration & Admin UI Integrity Fix
 * Trigger Hash: f2e9a8b7c6d5e4f3a2b1c0d9e8f7a6b5
 */
export const firebaseConfig = {
  apiKey: "AIzaSyBGJnZAketN8AukLVBl5TcbdH-czYq5Ws0",
  authDomain: "iextrades-e5682.firebaseapp.com",
  databaseURL: "https://iextrades-e5682-default-rtdb.firebaseio.com",
  projectId: "iextrades-e5682",
  storageBucket: "iextrades-e5682.firebasestorage.app",
  messagingSenderId: "139831583023",
  appId: "1:139831583023:android:656c28252fc25676b201da"
};
