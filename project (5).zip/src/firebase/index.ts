
'use client';

import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';
import { firebaseConfig } from './config';

let appInstance: FirebaseApp | undefined;
let authInstance: Auth | undefined;
let dbInstance: Firestore | undefined;

/**
 * Institutional Firebase Service Node.
 * Implements a strict singleton pattern to prevent Firestore Internal Assertion Failure (ID: ca9).
 * Ensures a single, verified instance of Firestore and Auth is used across the platform.
 */
export function initializeFirebase(): {
  app: FirebaseApp;
  auth: Auth;
  db: Firestore;
} {
  if (typeof window === 'undefined') {
    return { app: {} as FirebaseApp, auth: {} as Auth, db: {} as Firestore };
  }

  if (!appInstance) {
    const apps = getApps();
    appInstance = apps.length > 0 ? apps[0] : initializeApp(firebaseConfig);
  }

  if (!authInstance) {
    authInstance = getAuth(appInstance);
  }

  if (!dbInstance) {
    dbInstance = getFirestore(appInstance);
  }

  return { app: appInstance, auth: authInstance, db: dbInstance };
}

export * from './provider';
export * from './auth/use-user';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
