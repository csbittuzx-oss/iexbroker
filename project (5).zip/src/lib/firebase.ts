
'use client';

import { initializeFirebase } from '@/firebase';

/**
 * Unified Firebase Service Node Bridge.
 * Refactored to avoid top-level side effects that trigger Firestore ID: ca9.
 */
export function getFirebase() {
  return initializeFirebase();
}

// Legacy exports refactored to use safe getters
export const getAuthInstance = () => initializeFirebase().auth;
export const getFirestoreInstance = () => initializeFirebase().db;

const bridge = {
  get app() { return initializeFirebase().app; },
  get auth() { return initializeFirebase().auth; },
  get db() { return initializeFirebase().db; }
};

export default bridge;
